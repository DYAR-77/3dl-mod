package com.n3dl.cosmetics;

import com.mojang.blaze3d.platform.NativeImage;
import com.n3dl.core.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerSkin;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Loads capes (static or animated) and outfits (full skins) from the config folder and
 * swaps them into the local player's skin. Only you see them.
 *
 * Cape files: PNG (64x32, or HD 128x64 ...). Animated: a PNG strip with frames stacked
 * vertically (64 x 32N) or a GIF. Elytra uses the same texture.
 * Outfit files: PNG 64x64 skin. Put "slim" in the file name for slim (Alex) arms.
 */
public final class CosmeticsManager {
    private CosmeticsManager() {
    }

    public static final class Tex {
        public final List<Identifier> frames = new ArrayList<>();
        public int width, height; // size of ONE frame
        public boolean slim;

        public Identifier current(int ms) {
            if (frames.size() == 1) return frames.get(0);
            int i = (int) ((System.currentTimeMillis() / Math.max(20, ms)) % frames.size());
            return frames.get(i);
        }
    }

    private static final Map<String, Tex> CAPES = new HashMap<>();
    private static final Map<String, Tex> OUTFITS = new HashMap<>();
    private static final List<String> FAILED = new ArrayList<>();
    private static int counter = 0;

    public static Path capesDir() {
        return sub("capes");
    }

    public static Path outfitsDir() {
        return sub("outfits");
    }

    private static Path sub(String n) {
        Path p = Config.dir().resolve(n);
        try {
            Files.createDirectories(p);
        } catch (Exception ignored) {
        }
        return p;
    }

    /** Copies the default capes / outfits that ship inside the jar the first time. */
    public static void init() {
        copyDefaults("capes", capesDir());
        copyDefaults("outfits", outfitsDir());
    }

    private static void copyDefaults(String folder, Path target) {
        try {
            Path marker = target.resolve(".defaults_v2");
            if (Files.exists(marker)) return;
            try (InputStream idx = CosmeticsManager.class.getResourceAsStream("/assets/n3dl/defaults/" + folder + "/index.txt")) {
                if (idx != null) {
                    for (String line : new String(idx.readAllBytes()).split("\\R")) {
                        String name = line.trim();
                        if (name.isEmpty()) continue;
                        try (InputStream in = CosmeticsManager.class.getResourceAsStream("/assets/n3dl/defaults/" + folder + "/" + name)) {
                            if (in != null && !Files.exists(target.resolve(name))) Files.copy(in, target.resolve(name));
                        }
                    }
                }
            }
            Files.writeString(marker, "done");
        } catch (Exception e) {
            System.err.println("[3DL ABO ZAHRA] Could not copy default " + folder + ": " + e);
        }
    }

    public static List<String> list(Path dir, boolean allowGif) {
        List<String> l = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir)) {
            s.map(p -> p.getFileName().toString())
                    .filter(n -> {
                        String x = n.toLowerCase();
                        return x.endsWith(".png") || (allowGif && (x.endsWith(".gif") || x.endsWith(".jpg") || x.endsWith(".jpeg") || x.endsWith(".bmp")));
                    })
                    .sorted()
                    .forEach(l::add);
        } catch (Exception ignored) {
        }
        return l;
    }

    public static void reload() {
        CAPES.clear();
        OUTFITS.clear();
        FAILED.clear();
    }

    public static Tex preview(String capeName) {
        return capeName == null || capeName.isEmpty() ? null : get(CAPES, capesDir(), capeName, true);
    }

    public static Tex previewOutfit(String name) {
        return name == null || name.isEmpty() ? null : get(OUTFITS, outfitsDir(), name, false);
    }

    // ------------------------------------------------------------------ apply

    /** Cape of another 3DL ABO ZAHRA user (file already downloaded by the sync client), or null. */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static PlayerSkin applyRemote(PlayerSkin base, String capeFileName) {
        if (base == null || !Config.get().enabled) return null;
        Path f = com.n3dl.net.SyncClient.capeFile(capeFileName);
        if (f == null) return null;
        if (!Files.isRegularFile(f)) {
            com.n3dl.net.SyncClient.requestCape(capeFileName);
            return null;
        }
        Tex cape = get(CAPES, f.getParent(), f.getFileName().toString(), true);
        if (cape == null) return null;
        try {
            Optional<ClientAsset.ResourceTexture> capeOpt = Optional.of(new ClientAsset.ResourceTexture(cape.current(Config.get().capeFrameMs)));
            Optional model = Optional.empty();
            return base.with(PlayerSkin.Patch.create(Optional.empty(), capeOpt, capeOpt, model));
        } catch (Throwable t) {
            return null;
        }
    }

    /** Returns a modified skin, or null when nothing should change. Called on the render thread. */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static PlayerSkin apply(PlayerSkin base) {
        Config c = Config.get();
        if (!c.enabled || base == null) return null;
        Tex cape = c.cape.isEmpty() ? null : get(CAPES, capesDir(), c.cape, true);
        Tex outfit = c.outfit.isEmpty() ? null : get(OUTFITS, outfitsDir(), c.outfit, false);
        if (cape == null && outfit == null) return null;
        try {
            Optional<ClientAsset.ResourceTexture> body = outfit == null ? Optional.empty()
                    : Optional.of(new ClientAsset.ResourceTexture(outfit.current(100)));
            Optional<ClientAsset.ResourceTexture> capeOpt = cape == null ? Optional.empty()
                    : Optional.of(new ClientAsset.ResourceTexture(cape.current(c.capeFrameMs)));
            Optional<ClientAsset.ResourceTexture> elytraOpt = (cape == null || !c.capeElytra) ? Optional.empty() : capeOpt;
            Optional model = Optional.empty();
            if (outfit != null) {
                Object[] kinds = base.model().getClass().getEnumConstants();
                if (kinds != null) {
                    String want = outfit.slim ? "slim" : "wide";
                    for (Object k : kinds) {
                        if (((Enum<?>) k).name().equalsIgnoreCase(want)) model = Optional.of(k);
                    }
                }
            }
            return base.with(PlayerSkin.Patch.create(body, capeOpt, elytraOpt, model));
        } catch (Throwable t) {
            System.err.println("[3DL ABO ZAHRA] Could not apply cosmetics: " + t);
            return null;
        }
    }

    // ------------------------------------------------------------------ importing

    /** Copies any picture / GIF into the capes folder and returns its new file name (null on failure). */
    public static String importCape(Path src) {
        return importInto(src, capesDir());
    }

    public static String importOutfit(Path src) {
        return importInto(src, outfitsDir());
    }

    private static String importInto(Path src, Path dir) {
        try {
            String name = src.getFileName().toString().replaceAll("[^A-Za-z0-9._ -]", "_");
            Path dst = dir.resolve(name);
            if (src.toAbsolutePath().normalize().equals(dst.toAbsolutePath().normalize())) return name;
            int i = 1;
            while (Files.exists(dst)) {
                int dot = name.lastIndexOf('.');
                String stem = dot < 0 ? name : name.substring(0, dot), ext = dot < 0 ? "" : name.substring(dot);
                dst = dir.resolve(stem + "_" + (i++) + ext);
            }
            Files.copy(src, dst);
            reload();
            return dst.getFileName().toString();
        } catch (Exception e) {
            System.err.println("[3DL ABO ZAHRA] Import failed: " + e);
            return null;
        }
    }

    // ------------------------------------------------------------------ loading

    private static Tex get(Map<String, Tex> cache, Path dir, String name, boolean cape) {
        Tex t = cache.get(name);
        if (t != null) return t;
        String key = (cape ? "c:" : "o:") + name;
        if (FAILED.contains(key)) return null;
        try {
            Path f = dir.resolve(name).normalize();
            if (!f.startsWith(dir.normalize()) || !Files.isRegularFile(f)) throw new IllegalStateException("missing");
            t = cape ? loadCape(f) : loadOutfit(f);
            cache.put(name, t);
            return t;
        } catch (Throwable e) {
            System.err.println("[3DL ABO ZAHRA] Could not load " + name + ": " + e);
            FAILED.add(key);
            return null;
        }
    }

    private static Tex loadCape(Path f) throws Exception {
        List<BufferedImage> frames = new ArrayList<>();
        String n = f.getFileName().toString().toLowerCase();
        String fit = Config.get().capeFit;
        if (n.endsWith(".gif")) {
            List<BufferedImage> gif = readGif(f);
            if (!gif.isEmpty() && ImageUtil.isCapeShaped(gif.get(0).getWidth(), gif.get(0).getHeight())) {
                frames.addAll(gif);
            } else {
                int step = Math.max(1, (int) Math.ceil(gif.size() / 100.0));
                for (int i = 0; i < gif.size(); i += step) frames.add(ImageUtil.pictureToCape(gif.get(i), fit, 4));
            }
        } else {
            BufferedImage img = ImageIO.read(f.toFile());
            if (img == null) throw new IllegalStateException("not an image");
            int w = img.getWidth(), h = img.getHeight();
            if (ImageUtil.isCapeShaped(w, h) || (w == 22 && h == 17)) {
                frames.add(img);
            } else if (ImageUtil.isCapeStrip(w, h)) {
                int fh = w / 2;
                for (int i = 0; i < h / fh; i++) frames.add(img.getSubimage(0, i * fh, w, fh));
            } else {
                frames.add(ImageUtil.pictureToCape(img, fit, 8));
            }
        }
        if (frames.isEmpty()) throw new IllegalStateException("no frames");
        Tex t = new Tex();
        t.width = frames.get(0).getWidth();
        t.height = frames.get(0).getHeight();
        for (BufferedImage fr : frames) t.frames.add(register("capes", fr));
        return t;
    }

    private static Tex loadOutfit(Path f) throws Exception {
        BufferedImage img = ImageIO.read(f.toFile());
        if (img == null) throw new IllegalStateException("not an image");
        if (img.getHeight() * 2 == img.getWidth()) { // legacy 64x32 -> 64x64 canvas
            BufferedImage big = new BufferedImage(img.getWidth(), img.getWidth(), BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = big.createGraphics();
            g.drawImage(img, 0, 0, null);
            g.dispose();
            img = big;
        }
        Tex t = new Tex();
        t.width = img.getWidth();
        t.height = img.getHeight();
        t.slim = f.getFileName().toString().toLowerCase().contains("slim");
        t.frames.add(register("outfits", img));
        return t;
    }

    private static List<BufferedImage> readGif(Path f) throws Exception {
        List<BufferedImage> out = new ArrayList<>();
        try (ImageInputStream in = ImageIO.createImageInputStream(f.toFile())) {
            Iterator<ImageReader> it = ImageIO.getImageReadersByFormatName("gif");
            if (!it.hasNext()) return out;
            ImageReader r = it.next();
            r.setInput(in);
            int n = r.getNumImages(true);
            int w = r.getWidth(0), h = r.getHeight(0);
            BufferedImage canvas = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            for (int i = 0; i < n; i++) {
                BufferedImage fr = r.read(i);
                Graphics2D g = canvas.createGraphics();
                g.drawImage(fr, 0, 0, null);
                g.dispose();
                BufferedImage copy = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2 = copy.createGraphics();
                g2.drawImage(canvas, 0, 0, null);
                g2.dispose();
                out.add(copy);
            }
            r.dispose();
        }
        return out;
    }

    /** Registers a dynamic texture at textures/<folder>/n3dl_N.png and returns the id used by ResourceTexture. */
    private static Identifier register(String folder, BufferedImage img) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ImageIO.write(img, "png", bos);
        NativeImage ni = NativeImage.read(new ByteArrayInputStream(bos.toByteArray()));
        String path = folder + "/n3dl_" + (counter++);
        Identifier id = Identifier.fromNamespaceAndPath("n3dl", path);
        Identifier texturePath = Identifier.fromNamespaceAndPath("n3dl", "textures/" + path + ".png");
        Minecraft.getInstance().getTextureManager().register(texturePath, new DynamicTexture(() -> "n3dl_" + path, ni));
        return id;
    }

    /** Texture path (for GUI blit previews) of a frame id returned by register(). */
    public static Identifier texturePath(Identifier id) {
        return Identifier.fromNamespaceAndPath(id.getNamespace(), "textures/" + id.getPath() + ".png");
    }
}
