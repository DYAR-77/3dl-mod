package com.n3dl.cosmetics.model;

import static com.n3dl.cosmetics.model.M.*;

import com.n3dl.cosmetics.model.Cosmetic.Anchor;
import com.n3dl.cosmetics.model.Cosmetic.Slot;
import java.util.List;

/** Headwear. Head box is x -4..4, y -8..0, z -4..4 (front = -z). */
final class HeadDesigns {
    private HeadDesigns() {
    }

    private static void add(List<Cosmetic> out, String id, String en, String ar, int[] pal, Part p) {
        out.add(new Cosmetic(id, en, ar, Slot.HEAD, Anchor.HEAD, pal, p));
    }

    static void register(List<Cosmetic> out) {
        // Crown
        Part crown = Part.group();
        crown.box(-4.6f, -10.6f, -4.6f, 9.2f, 2.2f, 1f, 0).box(-4.6f, -10.6f, 3.6f, 9.2f, 2.2f, 1f, 0)
                .box(-4.6f, -10.6f, -3.6f, 1f, 2.2f, 7.2f, 0).box(3.6f, -10.6f, -3.6f, 1f, 2.2f, 7.2f, 0);
        float[] px = {-4.6f, -1.6f, 1.6f, 3.6f};
        for (float x : px) {
            crown.box(x, -12.8f, -4.6f, 1f, 2.3f, 1f, 0).box(x, -12.8f, 3.6f, 1f, 2.3f, 1f, 0);
        }
        crown.box(-0.6f, -12.4f, -4.6f, 1.2f, 1.8f, 1f, 0).box(-0.6f, -12.4f, 3.6f, 1.2f, 1.8f, 1f, 0);
        crown.glow(true).boxc(-0.7f, -10.2f, -4.75f, 1.4f, 1.4f, 0.4f, 0xE0202A).boxc(-3.2f, -10.2f, -4.75f, 1f, 1f, 0.4f, 0x2AA7FF)
                .boxc(2.2f, -10.2f, -4.75f, 1f, 1f, 0.4f, 0x2AFF7A);
        add(out, "crown", "Gold crown", "تاج ذهبي", new int[]{0xFFC933, 0xFFE27A, 0xE0202A}, crown);

        // Halo
        Part halo = Part.at(0, -13f, 0).anim((t, k, o) -> {
            o[4] = sin(t * 2f) * 0.7f;
            o[1] = t * 40f;
        });
        halo.glow(true);
        for (int i = 0; i < 8; i++) {
            float a = i * 45f;
            Part s = Part.at(0, 0, 0).rot(0, a, 0);
            s.box(-1.7f, -0.3f, 4.2f, 3.4f, 0.6f, 0.9f, 0);
            halo.kid(s);
        }
        add(out, "halo", "Glowing halo", "هالة مضيئة", new int[]{0xFFE97A, 0xFFFFFF, 0xFFC933}, halo);

        // Devil horns
        Part horn = Part.at(2.6f, -8f, -1.2f);
        horn.box(-1f, -2f, -1f, 2f, 2.2f, 2f, 0);
        Part h2 = Part.at(0, -2f, 0).rot(0, 0, -14);
        h2.box(-0.8f, -2f, -0.8f, 1.6f, 2.2f, 1.6f, 0);
        Part h3 = Part.at(0, -2f, 0).rot(0, 0, -20);
        h3.box(-0.5f, -2f, -0.5f, 1f, 2f, 1f, 1);
        h2.kid(h3);
        horn.kid(h2);
        add(out, "devil", "Devil horns", "قرون شيطان", new int[]{0xD81E2A, 0xFF8A5A, 0x2B0A0D}, Part.pair(horn));

        // Cat ears
        Part ear = Part.at(2.7f, -8f, -1.8f).rot(0, 0, 8);
        ear.box(-1.6f, -1.6f, -0.6f, 3.2f, 1.6f, 1.2f, 0).box(-1.2f, -3.0f, -0.6f, 2.4f, 1.4f, 1.2f, 0).box(-0.7f, -4.2f, -0.6f, 1.4f, 1.2f, 1.2f, 0);
        ear.box(-0.9f, -2.4f, -0.75f, 1.8f, 2.2f, 0.4f, 2);
        add(out, "cat_ears", "Cat ears", "أذون قطة", new int[]{0x2E2E38, 0xFFFFFF, 0xFF8FB8}, Part.pair(ear));

        // Bunny ears
        Part bun = Part.at(2.2f, -8f, 0f).rot(0, 0, 6).anim((t, k, o) -> o[2] = sin(t * 2.2f) * 4f + k * 6f);
        bun.box(-1f, -9f, -0.6f, 2f, 9f, 1.2f, 0).box(-0.5f, -8f, -0.7f, 1f, 6.5f, 0.4f, 2);
        add(out, "bunny", "Bunny ears", "أذون أرنب", new int[]{0xFFFFFF, 0xF2F2F2, 0xFFB3CC}, Part.pair(bun));

        // Top hat
        Part top = Part.group();
        top.box(-5.6f, -8.8f, -5.6f, 11.2f, 0.8f, 11.2f, 0).box(-3.6f, -15.5f, -3.6f, 7.2f, 6.8f, 7.2f, 0)
                .box(-3.7f, -10.8f, -3.7f, 7.4f, 1.4f, 7.4f, 2);
        add(out, "tophat", "Top hat", "قبعة رسمية", new int[]{0x1C1C22, 0x33333C, 0xC8283C}, top);

        // Wizard hat
        Part wiz = Part.group();
        wiz.box(-6f, -8.7f, -6f, 12f, 0.7f, 12f, 0);
        float wv = 8.4f, yy = -9.4f;
        for (int i = 0; i < 6; i++) {
            Part l = Part.at(0, yy, 0).rot(0, 0, 0);
            l.box(-wv / 2 + i * 0.0f, -2.4f, -wv / 2, wv, 2.4f, wv, i == 0 ? 2 : (i % 2 == 0 ? 0 : 1));
            wiz.kid(l);
            wv -= 1.3f;
            yy -= 2.2f;
            wiz.rot(0, 0, 0);
        }
        wiz.glow(true).boxc(-1f, -17.5f, -3.4f, 2f, 2f, 0.5f, 0xFFE27A);
        add(out, "wizard", "Wizard hat", "قبعة ساحر", new int[]{0x4B2A9A, 0x6B45C8, 0xFFD34D}, wiz);

        // Viking
        Part vk = Part.group();
        vk.box(-4.7f, -9.2f, -4.7f, 9.4f, 3.4f, 9.4f, 0).box(-4.8f, -6.4f, -4.8f, 9.6f, 1f, 9.6f, 1).box(-0.6f, -7f, -4.9f, 1.2f, 4.5f, 0.8f, 1);
        Part vh = Part.at(4.7f, -8f, 0).rot(0, 0, 25);
        vh.box(-0.6f, -2f, -1.1f, 1.8f, 2.4f, 2.2f, 2);
        Part vh2 = Part.at(1.2f, -2f, 0).rot(0, 0, -35);
        vh2.box(-0.6f, -3f, -0.9f, 1.6f, 3f, 1.8f, 2);
        vh.kid(vh2);
        vk.kid(Part.pair(vh));
        add(out, "viking", "Viking helmet", "خوذة فايكنج", new int[]{0x8A8F99, 0x5A5F69, 0xF1E7C8}, vk);

        // Spartan helmet with red plume
        Part sp = Part.group();
        sp.box(-4.7f, -9.8f, -4.7f, 9.4f, 5.4f, 9.4f, 0).box(-4.9f, -4.6f, -4.9f, 0.9f, 4.4f, 5.5f, 0).box(4f, -4.6f, -4.9f, 0.9f, 4.4f, 5.5f, 0)
                .box(-0.7f, -6.4f, -5f, 1.4f, 4.6f, 0.9f, 0).box(-4.8f, -5.4f, -4.9f, 9.6f, 0.8f, 0.8f, 1);
        float[] ph = {2.5f, 3.6f, 4.4f, 4.8f, 4.8f, 4.4f, 3.6f, 2.8f};
        for (int i = 0; i < ph.length; i++) {
            sp.box(-0.9f, -9.8f - ph[i], -4.6f + i * 1.15f, 1.8f, ph[i], 1.2f, 1);
        }
        add(out, "spartan", "Spartan helmet", "خوذة محارب", new int[]{0xF2B826, 0xD6262F, 0xFFE27A}, sp);

        // Santa hat
        Part st = Part.group();
        st.box(-4.8f, -9f, -4.8f, 9.6f, 1.8f, 9.6f, 1);
        Part c1 = Part.at(0, -9f, 0).rot(0, 0, 0);
        c1.box(-4f, -3f, -4f, 8f, 3f, 8f, 0);
        Part c2 = Part.at(0, -3f, 0).rot(-18, 0, 0);
        c2.box(-3f, -3f, -3f, 6f, 3f, 6f, 0);
        Part c3 = Part.at(0, -3f, 0).rot(-30, 0, 0);
        c3.box(-2f, -3f, -2f, 4f, 3f, 4f, 0).box(-1.5f, -5.2f, -1.5f, 3f, 2.4f, 3f, 1);
        c2.kid(c3);
        c1.kid(c2);
        st.kid(c1);
        add(out, "santa", "Santa hat", "قبعة بابا نويل", new int[]{0xD61F2B, 0xFFFFFF, 0xFFFFFF}, st);

        // Headphones
        Part hp = Part.group();
        hp.box(-4.7f, -9.6f, -0.7f, 9.4f, 1f, 1.4f, 0).box(-5.2f, -9f, -0.7f, 1f, 4.5f, 1.4f, 0).box(4.2f, -9f, -0.7f, 1f, 4.5f, 1.4f, 0)
                .box(-6.6f, -5.6f, -2f, 1.8f, 4.2f, 4f, 1).box(4.8f, -5.6f, -2f, 1.8f, 4.2f, 4f, 1)
                .glow(true).box(-6.75f, -4.8f, -1.2f, 0.4f, 2.6f, 2.4f, 2).box(6.35f, -4.8f, -1.2f, 0.4f, 2.6f, 2.4f, 2);
        add(out, "headphones", "Headphones", "سماعات", new int[]{0x2C2F38, 0x4B4F5C, 0x2EF2FF}, hp);

        // Propeller cap
        Part pc = Part.group();
        pc.box(-4.6f, -10f, -4.6f, 9.2f, 2.2f, 9.2f, 0).box(-4.8f, -8.6f, -7.2f, 9.6f, 0.8f, 3f, 1).box(-0.5f, -11.6f, -0.5f, 1f, 1.8f, 1f, 2);
        Part rot = Part.at(0, -11.8f, 0).anim((t, k, o) -> o[1] = t * 700f);
        rot.box(-5f, -0.3f, -0.8f, 10f, 0.6f, 1.6f, 2).box(-0.8f, -0.3f, -5f, 1.6f, 0.6f, 10f, 1);
        pc.kid(rot);
        add(out, "propeller", "Propeller cap", "كاب مروحة", new int[]{0x2A7BFF, 0xFFD23F, 0xE0202A}, pc);

        // Antlers
        Part an = Part.at(2.6f, -8f, 0).rot(0, 0, 14);
        an.box(-0.6f, -5f, -0.6f, 1.2f, 5f, 1.2f, 0);
        Part b1 = Part.at(0, -5f, 0).rot(0, 0, -22);
        b1.box(-0.5f, -5f, -0.5f, 1f, 5f, 1f, 0);
        Part t1 = Part.at(0, -2.5f, 0).rot(0, 0, 55);
        t1.box(-0.4f, -3f, -0.4f, 0.8f, 3f, 0.8f, 1);
        Part t2 = Part.at(0, -3.2f, 0).rot(-40, 0, -50);
        t2.box(-0.4f, -3f, -0.4f, 0.8f, 3f, 0.8f, 1);
        Part t3 = Part.at(0, -1.5f, 0).rot(0, 0, 55);
        t3.box(-0.4f, -2.6f, -0.4f, 0.8f, 2.6f, 0.8f, 1);
        an.kid(b1);
        an.kid(t1);
        an.kid(t3);
        an.kid(t2);
        add(out, "antlers", "Deer antlers", "قرون غزال", new int[]{0x8A5A32, 0xC79A66, 0xFFFFFF}, Part.pair(an));
    }
}
