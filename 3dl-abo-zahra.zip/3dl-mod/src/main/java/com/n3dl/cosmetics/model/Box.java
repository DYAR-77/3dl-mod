package com.n3dl.cosmetics.model;

/** One cuboid in model pixels (1 px = 1/16 block). role 0..2 = palette colour, -1 = fixed rgb. */
public final class Box {
    public final float x, y, z, w, h, d;
    public final int role;
    public final int rgb;
    public final boolean glow;
    public final float alpha;
    /** Brightness multiplier (shading). 1 = normal. */
    public final float tone;

    public Box(float x, float y, float z, float w, float h, float d, int role, int rgb, boolean glow, float alpha) {
        this(x, y, z, w, h, d, role, rgb, glow, alpha, 1f);
    }

    public Box(float x, float y, float z, float w, float h, float d, int role, int rgb, boolean glow, float alpha, float tone) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
        this.h = h;
        this.d = d;
        this.role = role;
        this.rgb = rgb;
        this.glow = glow;
        this.alpha = alpha;
        this.tone = tone;
    }

    Box mirrored() {
        return new Box(-(x + w), y, z, w, h, d, role, rgb, glow, alpha, tone);
    }
}
