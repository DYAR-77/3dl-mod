package com.n3dl.cosmetics;

import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.n3dl.core.Config;
import com.n3dl.cosmetics.model.Cosmetic.Slot;
import com.n3dl.cosmetics.model.Phys;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.model.HumanoidModel;
import com.mojang.math.Axis;
import net.minecraft.world.phys.Vec3;

/** Draws only the walking pet (no aura, no shoulder companion) for the local player while in first person (the player model itself is hidden then). */
public final class FirstPerson {
    private FirstPerson() {
    }

    private static MultiBufferSource.BufferSource bs;

    public static void render(WorldRenderContext ctx) {
        try {
            Minecraft mc = Minecraft.getInstance();
            Config cfg = Config.get();
            if (mc.player == null || mc.level == null || !cfg.cosEnabled || !cfg.cosFirstPerson) return;
            if (!mc.options.getCameraType().isFirstPerson()) return;
            PoseStack ms = ctx.matrices();
            if (ms == null) return;
            HumanoidModel<?> hm = CosmeticsRender.lastModel;
            if (hm == null) {
                EntityRenderer<?, ?> r = mc.getEntityRenderDispatcher().getRenderer(mc.player);
                if (r instanceof LivingEntityRenderer<?, ?, ?> lr && lr.getModel() instanceof HumanoidModel<?> h) hm = h;
            }
            if (hm == null) return;
            float partial = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
            var p = mc.player;
            double px = p.xOld + (p.getX() - p.xOld) * partial;
            double py = p.yOld + (p.getY() - p.yOld) * partial;
            double pz = p.zOld + (p.getZ() - p.zOld) * partial;
            Vec3 cam = ctx.worldState().cameraRenderState.pos;
            float bodyYaw = p.yBodyRotO + (p.yBodyRot - p.yBodyRotO) * partial;
            Phys ph = Phys.of(p.getId());
            ph.update(p.getX(), p.getY(), p.getZ(), bodyYaw, p.onGround(), p.isCrouching(), p.isFallFlying());
            Phys.cur = ph;
            Config.CosSlot[] all = CosmeticsRender.localSlots();
            Config.CosSlot[] only = new Config.CosSlot[all.length];
            only[Slot.PET.ordinal()] = all[Slot.PET.ordinal()];
            if (bs == null) bs = MultiBufferSource.immediate(new ByteBufferBuilder(262144));
            ms.pushPose();
            // same pose a living-entity renderer hands to its layers
            ms.translate(px - cam.x, py - cam.y, pz - cam.z);
            ms.mulPose(Axis.YP.rotationDegrees(180f - bodyYaw));
            ms.scale(-1f, -1f, 1f);
            ms.translate(0f, -1.501f, 0f);
            CosmeticsRender.fpBuf = bs;
            float age = p.tickCount + partial;
            CosmeticsRender.renderAll(ms, null, hm, 15728880, age, bodyYaw, px, py, pz,
                    p.walkAnimation.speed(partial), partial, only, true);
            CosmeticsRender.fpBuf = null;
            ms.popPose();
            bs.endBatch();
        } catch (Throwable t) {
            // never break the frame
        }
    }
}
