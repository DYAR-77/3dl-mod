package com.n3dl.cosmetics.model;

/** Helpers that build rounder shapes out of boxes. */
final class Shapes {
    private Shapes() {
    }

    /**
     * Rounded ellipsoid: stacked slices, each made of two crossing boxes (an octagon-like cross section).
     * tTop / tBottom = brightness at the top and bottom (gives soft shading).
     */
    static Part blob(Part p, float cx, float cy, float cz, float rx, float ry, float rz, int role, int n, float tTop, float tBottom) {
        return blobImpl(p, cx, cy, cz, rx, ry, rz, role, -1, n, tTop, tBottom);
    }

    static Part blobc(Part p, float cx, float cy, float cz, float rx, float ry, float rz, int rgb, int n, float tTop, float tBottom) {
        return blobImpl(p, cx, cy, cz, rx, ry, rz, -1, rgb, n, tTop, tBottom);
    }

    private static Part blobImpl(Part p, float cx, float cy, float cz, float rx, float ry, float rz, int role, int rgb, int n, float tTop, float tBottom) {
        for (int i = 0; i < n; i++) {
            float u = (i + 0.5f) / n * 2f - 1f;
            float f = (float) Math.sqrt(Math.max(0.05, 1 - u * u));
            float h = 2 * ry / n;
            float y0 = cy - ry + i * h;
            float w = Math.max(0.3f, 2 * rx * f), d = Math.max(0.3f, 2 * rz * f);
            p.tone(M.lerp(tTop, tBottom, n == 1 ? 0.5f : i / (float) (n - 1)));
            if (rgb < 0) {
                p.box(cx - w / 2, y0, cz - d * 0.36f, w, h + 0.02f, d * 0.72f, role);
                p.box(cx - w * 0.36f, y0, cz - d / 2, w * 0.72f, h + 0.02f, d, role);
            } else {
                p.boxc(cx - w / 2, y0, cz - d * 0.36f, w, h + 0.02f, d * 0.72f, rgb);
                p.boxc(cx - w * 0.36f, y0, cz - d / 2, w * 0.72f, h + 0.02f, d, rgb);
            }
        }
        p.tone(1f);
        return p;
    }

    /** Tapered stack (cone-like) going up: base at y0 with half sizes, shrinking to the tip. */
    static Part cone(Part p, float cx, float y0, float cz, float baseHalf, float height, float tipHalf, int n, int role, float tBase, float tTip) {
        float h = height / n;
        for (int i = 0; i < n; i++) {
            float u = n == 1 ? 0 : i / (float) (n - 1);
            float half = M.lerp(baseHalf, tipHalf, u);
            p.tone(M.lerp(tBase, tTip, u));
            p.box(cx - half, y0 - (i + 1) * h, cz - half, half * 2, h + 0.02f, half * 2, role);
        }
        p.tone(1f);
        return p;
    }

    /** Small black eye with a white glint. */
    static Part eye(Part p, float x, float y, float z, float s) {
        p.boxc(x - s / 2, y - s / 2, z, s, s, 0.5f, 0x15151C);
        p.glow(true).boxc(x - s * 0.1f, y - s * 0.45f, z - 0.12f, s * 0.38f, s * 0.38f, 0.3f, 0xFFFFFF).glow(false);
        return p;
    }
}
