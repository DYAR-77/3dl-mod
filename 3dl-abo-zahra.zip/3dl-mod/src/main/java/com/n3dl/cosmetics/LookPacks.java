package com.n3dl.cosmetics;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.repository.PackRepository;

import java.lang.reflect.Method;

/**
 * Built-in optional resource packs that change how pickaxes, swords, axes... look.
 * Registered through Fabric API (looked up by reflection so the mod keeps loading even if the
 * API class is moved in a later Fabric API version).
 */
public final class LookPacks {
    private LookPacks() {
    }

    public static final String NEON = "neon_tools";

    public static void register() {
        ModContainer me = FabricLoader.getInstance().getModContainer("n3dl").orElse(null);
        if (me == null) return;
        Identifier id = Identifier.fromNamespaceAndPath("n3dl", NEON);
        // Newer Fabric API
        try {
            Class<?> loader = Class.forName("net.fabricmc.fabric.api.resource.v1.ResourceLoader");
            Class<?> act = Class.forName("net.fabricmc.fabric.api.resource.v1.pack.PackActivationType");
            Object normal = enumConst(act, "NORMAL");
            for (Method m : loader.getMethods()) {
                if (m.getName().equals("registerBuiltinPack") && java.lang.reflect.Modifier.isStatic(m.getModifiers())
                        && m.getParameterCount() == 4) {
                    m.invoke(null, id, me, Component.literal("3DL ABO ZAHRA Neon Tools"), normal);
                    return;
                }
            }
        } catch (Throwable ignored) {
        }
        // Older Fabric API
        try {
            Class<?> helper = Class.forName("net.fabricmc.fabric.api.resource.ResourceManagerHelper");
            Class<?> act = Class.forName("net.fabricmc.fabric.api.resource.ResourcePackActivationType");
            Object normal = enumConst(act, "NORMAL");
            for (Method m : helper.getMethods()) {
                if (m.getName().equals("registerBuiltinResourcePack") && java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                    if (m.getParameterCount() == 4) {
                        m.invoke(null, id, me, Component.literal("3DL ABO ZAHRA Neon Tools"), normal);
                        return;
                    }
                    if (m.getParameterCount() == 3) {
                        m.invoke(null, id, me, normal);
                        return;
                    }
                }
            }
        } catch (Throwable t) {
            System.err.println("[3DL ABO ZAHRA] Could not register built-in look pack: " + t);
        }
    }

    private static Object enumConst(Class<?> cls, String name) {
        for (Object o : cls.getEnumConstants()) {
            if (((Enum<?>) o).name().equals(name)) return o;
        }
        return null;
    }

    private static String findId(PackRepository repo) {
        for (String id : repo.getAvailableIds()) {
            if (id.contains(NEON)) return id;
        }
        return null;
    }

    public static boolean available() {
        return findId(Minecraft.getInstance().getResourcePackRepository()) != null;
    }

    public static boolean isOn() {
        PackRepository repo = Minecraft.getInstance().getResourcePackRepository();
        String id = findId(repo);
        return id != null && repo.getSelectedIds().contains(id);
    }

    public static void set(boolean on) {
        Minecraft mc = Minecraft.getInstance();
        PackRepository repo = mc.getResourcePackRepository();
        String id = findId(repo);
        if (id == null) return;
        if (on) repo.addPack(id);
        else repo.removePack(id);
        mc.options.updateResourcePacks(repo);
        mc.reloadResourcePacks();
    }
}
