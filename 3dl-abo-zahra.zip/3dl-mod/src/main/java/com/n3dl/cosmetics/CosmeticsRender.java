package com.n3dl.cosmetics;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.n3dl.core.Config;
import com.n3dl.cosmetics.model.Box;
import com.n3dl.cosmetics.model.Cosmetic;
import com.n3dl.cosmetics.model.Cosmetic.Slot;
import com.n3dl.cosmetics.model.Designs;
import com.n3dl.cosmetics.model.M;
import com.n3dl.cosmetics.model.Phys;
import com.n3dl.cosmetics.model.Part;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import org.joml.Quaternionf;

/** Draws the 3D cosmetics of the local player. Everything is built from plain boxes with one white texture. */
public final class CosmeticsRender {
    private CosmeticsRender() {
    }

    private static final Identifier WHITE = Identifier.fromNamespaceAndPath("n3dl", "textures/cosmetic/white.png");
    private static boolean texReady;
    private static final Map<String, ModelPart> CUBES = new HashMap<>();
    private static final int FULL = 15728880;

    private static void ensureTexture() {
        if (texReady) return;
        texReady = true;
        try {
            NativeImage ni = new NativeImage(16, 16, false);
            for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) ni.setPixel(x, y, 0xFFFFFFFF);
            Minecraft.getInstance().getTextureManager().register(WHITE, new DynamicTexture(() -> "n3dl_white", ni));
        } catch (Throwable t) {
            texReady = false;
        }
    }

    private static ModelPart cube(float w, float h, float d) {
        String key = w + "x" + h + "x" + d;
        ModelPart p = CUBES.get(key);
        if (p == null) {
            MeshDefinition mesh = new MeshDefinition();
            mesh.getRoot().addOrReplaceChild("p", CubeListBuilder.create().texOffs(0, 0).addBox(0f, 0f, 0f, w, h, d), PartPose.ZERO);
            p = LayerDefinition.create(mesh, 16, 16).bakeRoot().getChild("p");
            CUBES.put(key, p);
        }
        return p;
    }

    /** Context for one frame of drawing. */
    private static final class Ctx {
        PoseStack ps;
        SubmitNodeCollector out;
        MultiBufferSource buf;
        @SuppressWarnings("rawtypes")
        Model model;
        int light;
        float t, k;
        boolean phys = true;
        Config.CosSlot cfg;
        Cosmetic cos;
        float baseScale;
        float[] o = new float[7];
    }

    public static Config.CosSlot cfgOf(Slot s) {
        Config c = Config.get();
        return switch (s) {
            case WINGS -> c.cosWings;
            case HEAD -> c.cosHead;
            case BODY -> c.cosBody;
            case PET -> c.cosPet;
            case COMPANION -> c.cosComp;
            case AURA -> c.cosAura;
        };
    }

    /** Draws every chosen cosmetic. Called from the render layer with the player's pose stack (layer space). */
    public static Config.CosSlot[] localSlots() {
        Slot[] all = Slot.values();
        Config.CosSlot[] r = new Config.CosSlot[all.length];
        for (int i = 0; i < all.length; i++) r[i] = cfgOf(all[i]);
        return r;
    }

    /** When non-null (and out == null) cubes are written to this buffer source instead of the submit collector. */
    static MultiBufferSource fpBuf;
    /** Model of the local player, remembered for the first-person pass. */
    public static HumanoidModel<?> lastModel;

    public static void renderAll(PoseStack ps, SubmitNodeCollector out, HumanoidModel<?> hm, int light, float ageTicks,
                                 float bodyYaw, double ex, double ey, double ez, float walk, float partial,
                                 Config.CosSlot[] cfgs, boolean local) {
        ensureTexture();
        Ctx c = new Ctx();
        c.ps = ps;
        c.out = out;
        c.buf = fpBuf;
        c.phys = Config.get().cosPhysics;
        c.model = hm;
        c.light = light;
        c.t = ageTicks / 20f;
        c.k = M.clamp(walk, 0f, 1f);
        for (Slot s : Slot.values()) {
            Config.CosSlot cfg = cfgs[s.ordinal()];
            if (cfg == null || cfg.id == null || cfg.id.isEmpty()) continue;
            Cosmetic cos = Designs.find(s, cfg.id);
            if (cos == null) continue;
            c.cfg = cfg;
            c.cos = cos;
            c.baseScale = cfg.scale <= 0 ? 1f : cfg.scale;
            ps.pushPose();
            try {
                switch (cos.anchor) {
                    case HEAD -> hm.head.translateAndRotate(ps);
                    case BODY -> hm.body.translateAndRotate(ps);
                    case AURA -> ps.translate(0f, 12f / 16f, 0f);
                    case FLOAT -> {
                        float bob = M.sin(c.t * 2.2f) * 0.06f;
                        float lagX = 0, lagZ = 0, lagY = 0;
                        if (c.phys) {
                            lagX = -M.clamp(Phys.cur.vsLag(0.22f) * 0.03f, -0.25f, 0.25f);
                            lagZ = M.clamp(Phys.cur.vfLag(0.22f) * 0.035f, -0.3f, 0.3f);
                            lagY = M.clamp(Phys.cur.vuLag(0.2f) * 0.02f, -0.2f, 0.2f);
                        }
                        ps.translate(-0.62f + M.cos(c.t * 1.3f) * 0.08f + lagX, -0.35f + bob + lagY, 0.15f + M.sin(c.t * 1.3f) * 0.08f + lagZ);
                        ps.scale(1.4f, 1.4f, 1.4f);
                    }
                    case PET -> {
                        if (!local) {
                            ps.translate(0.9f, 1.5f, 0f);
                            c.k = 0f;
                            break;
                        }
                        double lx = PetState.px + (PetState.x - PetState.px) * partial - ex;
                        double ly = PetState.py + (PetState.y - PetState.py) * partial - ey;
                        double lz = PetState.pz + (PetState.z - PetState.pz) * partial - ez;
                        double yaw = Math.toRadians(bodyYaw);
                        double left = lx * Math.cos(yaw) + lz * Math.sin(yaw);
                        double fwd = -lx * Math.sin(yaw) + lz * Math.cos(yaw);
                        float hop = M.abs(M.sin(c.t * 9f)) * 0.07f * PetState.speed;
                        ps.translate((float) left, 1.5f - (float) ly - hop, (float) -fwd);
                        double ddx = -lx, ddz = -lz;
                        float want = (float) Math.toDegrees(Math.atan2(-ddx, ddz));
                        Phys.cur.look = M.clamp(wrap(want - PetState.yaw), -55f, 55f);
                        float rel = wrap(PetState.pyaw + wrap(PetState.yaw - PetState.pyaw) * partial - bodyYaw);
                        ps.mulPose(new Quaternionf().rotationY((float) Math.toRadians(rel)));
                        c.k = PetState.speed;
                    }
                }
                draw(c, cos.root, 0f, 0f);
            } catch (Throwable t) {
                // never crash the render thread because of a cosmetic
            }
            ps.popPose();
            c.k = M.clamp(walk, 0f, 1f);
        }
    }

    private static float wrap(float a) {
        a %= 360f;
        if (a > 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    private static void draw(Ctx c, Part p, float accY, float accX) {
        PoseStack ps = c.ps;
        float[] o = c.o;
        o[0] = o[1] = o[2] = o[3] = o[4] = o[5] = o[6] = 0;
        if (p.anim != null) p.anim.apply(c.t, c.k, o);
        float sRx = 0, sRz = 0, sRy = 0;
        if (p.swayK != 0 && c.phys) {
            Phys ph = Phys.cur;
            float vf = ph.vfLag(p.swayLag), vs = ph.vsLag(p.swayLag);
            float idle = M.sin(c.t * 1.7f + p.x * 0.3f + p.y * 0.2f) * 2.2f;
            sRx = M.clamp(p.swayK * (vf * 5f + ph.yawVel * 0.0f) + p.swayK * idle * 0.6f, -50f, 50f);
            sRz = M.clamp(p.swayK * (vs * 5f + ph.yawVel * 0.035f) + p.swayK * idle * 0.4f, -50f, 50f);
            if (p.swayYaw) {
                sRy = sRz;
                sRz = 0;
            }
            if (p.mirrored) {
                sRz = -sRz;
                sRy = -sRy;
            }
        }
        if (p.mirrored) {
            o[1] = -o[1];
            o[2] = -o[2];
            o[3] = -o[3];
        }
        ps.pushPose();
        ps.translate((p.x + o[3]) / 16f, (p.y + o[4]) / 16f, (p.z + o[5]) / 16f);
        float rx = M.rad(p.rx + o[0] + sRx), ry = M.rad(p.ry + o[1] + sRy), rz = M.rad(p.rz + o[2] + sRz);
        if (rx != 0 || ry != 0 || rz != 0) ps.mulPose(new Quaternionf().rotationZYX(rz, ry, rx));
        float s = (p.scale + o[6]) * (p == c.cos.root ? c.baseScale : 1f);
        if (s != 1f) ps.scale(s, s, s);
        float ay = accY + p.y, ax = accX + p.x;
        for (Box b : p.boxes) {
            ps.pushPose();
            ps.translate(b.x / 16f, b.y / 16f, b.z / 16f);
            int col = color(c, b, ay + b.y, ax + b.x);
            if (b.tone != 1f) col = M.scale(col, b.tone);
            if (b.alpha < 1f) col = M.scale(col, 0.5f + 0.5f * b.alpha);
            int argb = 0xFF000000 | (col & 0xFFFFFF);
            var rt = c.model.renderType(WHITE);
            if (c.out != null) c.out.submitModelPart(cube(b.w, b.h, b.d), ps, rt, b.glow ? FULL : c.light, 0, null, argb, null);
            else cube(b.w, b.h, b.d).render(ps, c.buf.getBuffer(rt), b.glow ? FULL : c.light, OverlayTexture.NO_OVERLAY, argb);
            ps.popPose();
        }
        for (Part k : p.kids) draw(c, k, ay, ax);
        ps.popPose();
    }

    private static int color(Ctx c, Box b, float posY, float posX) {
        if (b.role < 0) return b.rgb;
        Config.CosSlot cs = c.cfg;
        int[] pal = c.cos.pal;
        switch (cs.mode) {
            case 1: {
                int a = cs.c1;
                return b.role == 0 ? a : b.role == 1 ? M.scale(a, 0.65f) : M.mix(a, 0xFFFFFF, 0.5f);
            }
            case 2: {
                float t = M.clamp((posY + 24f) / 48f, 0f, 1f);
                if (b.role == 1) t = 1f - t;
                if (b.role == 2) return cs.c2;
                return M.mix(cs.c1, cs.c2, t);
            }
            case 3: {
                float h = (c.t * 0.25f + posY * 0.012f + posX * 0.008f + b.role * 0.1f) % 1f;
                if (h < 0) h += 1f;
                return M.hsv(h, 0.75f, 1f);
            }
            default:
                return pal[Math.min(2, b.role)];
        }
    }
}
