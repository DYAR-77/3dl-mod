package com.n3dl.cosmetics.model;

import static com.n3dl.cosmetics.model.M.*;

import com.n3dl.cosmetics.model.Cosmetic.Anchor;
import com.n3dl.cosmetics.model.Cosmetic.Slot;
import java.util.List;

/** Extra, more detailed headwear, auras, floating companions and back items. */
final class PremiumDesigns {
    private PremiumDesigns() {
    }

    private static void add(List<Cosmetic> out, String id, String en, String ar, Slot slot, Anchor an, int[] pal, Part p) {
        out.add(new Cosmetic(id, en, ar, slot, an, pal, p));
    }

    /** A ring of n boxes around the vertical axis (radius r, centre height y). */
    private static void ring(Part parent, int n, float r, float y, float sx, float sy, float sz, int role, boolean glow, float tone) {
        for (int i = 0; i < n; i++) {
            Part s = Part.at(0, 0, 0).rot(0, i * 360f / n, 0);
            s.glow(glow).tone(i % 2 == 0 ? tone : tone * 0.88f).box(r - sx / 2, y - sy / 2, -sz / 2, sx, sy, sz, role);
            parent.kid(s);
        }
    }

    static void register(List<Cosmetic> out) {
        heads(out);
        auras(out);
        companions(out);
        backs(out);
    }

    // ------------------------------------------------------------------ headwear
    private static void heads(List<Cosmetic> out) {
        // Royal crown: band, graduated points, crossing arches, orb and gems
        Part rc = Part.group();
        rc.box(-4.8f, -10.3f, -4.8f, 9.6f, 2.3f, 1.1f, 0).box(-4.8f, -10.3f, 3.7f, 9.6f, 2.3f, 1.1f, 0)
                .box(-4.8f, -10.3f, -3.7f, 1.1f, 2.3f, 7.4f, 0).box(3.7f, -10.3f, -3.7f, 1.1f, 2.3f, 7.4f, 0);
        rc.tone(0.85f).box(-4.9f, -8.6f, -4.9f, 9.8f, 0.55f, 1.2f, 1).box(-4.9f, -8.6f, 3.7f, 9.8f, 0.55f, 1.2f, 1)
                .box(-4.9f, -8.6f, -3.7f, 1.2f, 0.55f, 7.4f, 1).box(3.7f, -8.6f, -3.7f, 1.2f, 0.55f, 7.4f, 1).tone(1f);
        float[] pts = {-4.8f, -1.6f, 1.6f, 4.8f};
        for (float p : pts) {
            float x = p > 0 ? p - 1.1f : p;
            for (float zz : new float[]{-4.8f, 3.7f}) {
                rc.box(x, -11.8f, zz, 1.1f, 1.6f, 1.1f, 0).box(x + 0.15f, -13.2f, zz + 0.15f, 0.8f, 1.5f, 0.8f, 1)
                        .glow(true).boxc(x + 0.25f, -14.2f, zz + 0.25f, 0.6f, 0.6f, 0.6f, 0xFFF1B0).glow(false);
            }
        }
        for (int s = 0; s < 5; s++) {
            float u = s / 4f;
            float x = lerp(-4.2f, -0.55f, u);
            float y = -11.4f - 3.6f * sin(u * PI / 2f);
            rc.box(x, y, -0.5f, 1.5f, 1.0f, 1.0f, 1).box(-x - 1.5f, y, -0.5f, 1.5f, 1.0f, 1.0f, 1);
            rc.box(-0.5f, y, x, 1.0f, 1.0f, 1.5f, 1).box(-0.5f, y, -x - 1.5f, 1.0f, 1.0f, 1.5f, 1);
        }
        rc.glow(true).boxc(-1f, -17.4f, -1f, 2f, 2f, 2f, 0xFFE08A).boxc(-0.45f, -16.2f, -0.45f, 0.9f, 1f, 0.9f, 0xFFFFFF).glow(false);
        rc.glow(true).box(-0.8f, -9.9f, -4.95f, 1.6f, 1.6f, 0.4f, 2).boxc(-3.4f, -9.7f, -4.95f, 1.1f, 1.1f, 0.4f, 0x33B8FF)
                .boxc(2.3f, -9.7f, -4.95f, 1.1f, 1.1f, 0.4f, 0x3DFF8A).box(-0.8f, -9.9f, 4.55f, 1.6f, 1.6f, 0.4f, 2).glow(false);
        add(out, "royal_crown", "Royal crown (legendary)", "تاج ملكي (أسطوري)", Slot.HEAD, Anchor.HEAD,
                new int[]{0xFFC933, 0xFFE9A0, 0xE0202A}, rc);

        // Samurai kabuto: layered dome, neck guard, cheek plates and a gold crest
        Part kb = Part.group();
        kb.box(-4.7f, -9.8f, -4.7f, 9.4f, 1.8f, 9.4f, 0).box(-4.2f, -11.2f, -4.2f, 8.4f, 1.6f, 8.4f, 0)
                .box(-3.5f, -12.4f, -3.5f, 7f, 1.4f, 7f, 0).box(-2.5f, -13.4f, -2.5f, 5f, 1.2f, 5f, 0)
                .tone(1.15f).box(-0.8f, -14.4f, -0.8f, 1.6f, 1.2f, 1.6f, 2).tone(1f);
        kb.box(-5f, -8.5f, -5f, 10f, 0.7f, 10f, 2);
        for (int i = 0; i < 4; i++) {
            kb.tone(i % 2 == 0 ? 1f : 0.82f).box(-4.9f - i * 0.5f, -8f + i * 1.9f, 3.9f + i * 0.35f, 9.8f + i * 1f, 1.8f, 1f, 1);
        }
        kb.tone(1f);
        Part cheek = Part.at(4.7f, -8f, -1.5f);
        cheek.box(-0.5f, 0f, -2.5f, 1f, 4.6f, 5.2f, 0).box(-0.55f, 4.4f, -2.2f, 1.1f, 1f, 4.6f, 2);
        kb.kid(Part.pair(cheek));
        Part blade = Part.at(0.9f, -10.6f, -4.9f).rot(0, 0, 32);
        blade.glow(false).box(-0.5f, -7.2f, -0.3f, 1.1f, 7.4f, 0.6f, 2);
        Part bl2 = Part.at(0, -7.2f, 0).rot(0, 0, -16);
        bl2.box(-0.4f, -3.2f, -0.3f, 0.9f, 3.4f, 0.6f, 2);
        blade.kid(bl2);
        kb.kid(Part.pair(blade));
        kb.glow(true).boxc(-0.6f, -11.4f, -4.9f, 1.2f, 1.2f, 0.5f, 0xFF3B30).glow(false);
        add(out, "kabuto", "Samurai helmet", "خوذة ساموراي", Slot.HEAD, Anchor.HEAD, new int[]{0x2F3A52, 0xB22A2A, 0xFFC933}, kb);

        // Dragon horns: four curved segments, glowing tips
        Part hn = Part.at(2.4f, -8f, -0.8f).rot(-8, 0, 12);
        Part cur = hn;
        float[] len = {3.2f, 3.0f, 2.6f, 2.2f};
        float[] th = {2.4f, 1.9f, 1.4f, 0.9f};
        for (int i = 0; i < 4; i++) {
            Part seg = Part.at(0, i == 0 ? 0 : -len[i - 1], 0).rot(-9, 0, -13);
            seg.tone(1f - 0.07f * i).box(-th[i] / 2, -len[i], -th[i] / 2, th[i], len[i], th[i], i == 3 ? 1 : 0);
            if (i == 3) seg.glow(true).boxc(-0.35f, -len[i] - 0.5f, -0.35f, 0.7f, 0.7f, 0.7f, 0xFF7A2A).glow(false);
            cur.kid(seg);
            cur = seg;
        }
        add(out, "dragon_horns", "Dragon horns", "قرون تنين", Slot.HEAD, Anchor.HEAD, new int[]{0xE9E2D0, 0x3A2B2B, 0xFF7A2A}, Part.pair(hn));

        // Double halo with orbiting sparks
        Part hl = Part.at(0, -13.4f, 0).anim((t, k, o) -> o[4] = sin(t * 2f) * 0.6f);
        Part outer = Part.at(0, 0, 0).anim((t, k, o) -> o[1] = t * 30f);
        ring(outer, 14, 6.2f, 0, 2.6f, 0.6f, 1.0f, 0, true, 1f);
        Part inner = Part.at(0, 0.2f, 0).anim((t, k, o) -> o[1] = -t * 55f);
        ring(inner, 10, 4.4f, 0, 1.6f, 0.4f, 0.7f, 1, true, 1f);
        hl.kid(outer).kid(inner);
        for (int i = 0; i < 4; i++) {
            final int n = i;
            Part sp = Part.at(0, 0, 0).anim((t, k, o) -> {
                float a = t * 2.4f + n * PI / 2f;
                o[3] = cos(a) * 6.2f;
                o[5] = sin(a) * 6.2f;
                o[4] = -1.2f + sin(t * 3f + n) * 0.8f;
            });
            sp.glow(true).box(-0.5f, -0.5f, -0.5f, 1f, 1f, 1f, 2);
            hl.kid(sp);
        }
        add(out, "halo_royal", "Radiant halo", "هالة متوهجة", Slot.HEAD, Anchor.HEAD, new int[]{0xFFE97A, 0xFFFFFF, 0xFFB000}, hl);
    }

    // ------------------------------------------------------------------ auras (origin = middle of the body)
    private static float life(float t, int i, float period) {
        float v = (t / period + M.hash(i * 7 + 3)) % 1f;
        return v < 0 ? v + 1f : v;
    }

    private static void auras(List<Cosmetic> out) {
        // Rune circle on the ground
        Part rc = Part.at(0, 11.8f, 0);
        Part disc = Part.at(0, 0, 0).anim((t, k, o) -> o[1] = t * 28f);
        for (int i = 0; i < 12; i++) {
            Part s = Part.at(0, 0, 0).rot(0, i * 30f, 0);
            s.glow(true).tone(0.9f + 0.1f * (i % 2)).box(11.2f, -0.25f, -0.9f, 1.4f, 0.5f, 1.8f, 0);
            s.box(11.9f, -0.25f, -0.3f, 1.0f, 0.5f, 0.6f, 2);
            if (i % 3 == 0) s.box(10.4f, -0.25f, -0.25f, 0.7f, 0.5f, 0.5f, 1);
            disc.kid(s);
        }
        ring(disc, 36, 9.2f, 0, 1.2f, 0.4f, 0.5f, 1, true, 1f);
        rc.kid(disc);
        Part star = Part.at(0, -0.1f, 0).anim((t, k, o) -> o[1] = -t * 40f);
        for (int i = 0; i < 6; i++) {
            Part ln = Part.at(0, 0, 0).rot(0, i * 60f, 0);
            ln.glow(true).tone(0.9f).box(1.5f, -0.2f, -0.25f, 7.6f, 0.4f, 0.5f, 1);
            star.kid(ln);
        }
        rc.kid(star);
        for (int i = 0; i < 10; i++) {
            final int n = i;
            Part sp = Part.at(0, 0, 0).anim((t, k, o) -> {
                float l = life(t, n, 2.6f);
                float a = M.hash(n * 5 + 1) * 2 * PI + l * 1.2f;
                float r = 3f + M.hash(n * 3 + 2) * 8f;
                o[3] = cos(a) * r;
                o[5] = sin(a) * r;
                o[4] = -l * 24f;
                o[6] = -l * 0.8f;
            });
            sp.glow(true).box(-0.5f, -0.5f, -0.5f, 1f, 1f, 1f, n % 2 == 0 ? 0 : 2);
            rc.kid(sp);
        }
        add(out, "rune_circle", "Rune circle", "دائرة الرونز", Slot.AURA, Anchor.AURA, new int[]{0x8A5CFF, 0x4DD2FF, 0xFFFFFF}, rc);

        // Gyroscope: three tilted rings spinning around you
        Part gy = Part.group();
        for (int r = 0; r < 3; r++) {
            final int n = r;
            Part rg = Part.at(0, 0, 0).anim((t, k, o) -> {
                if (n == 0) o[0] = t * 50f;
                if (n == 1) o[2] = t * 65f;
                if (n == 2) {
                    o[0] = -t * 35f;
                    o[2] = t * 45f;
                }
            });
            ring(rg, 20, 11f + r * 1.6f, 0, 1.5f, 0.6f, 1.0f, r, true, 1f);
            gy.kid(rg);
        }
        add(out, "gyro_rings", "Gyroscope rings", "حلقات تدور", Slot.AURA, Anchor.AURA, new int[]{0x4DD2FF, 0xFF5CE1, 0xFFE27A}, gy);
    }

    // ------------------------------------------------------------------ floating companions
    private static Part flapWing(float len, float wid, int bone, int skin, float phase) {
        Part w = Part.at(1.2f, -1.2f, 0.6f).anim((t, k, o) -> o[2] = -sin(t * 8f + phase) * 34f - 8f);
        w.box(0, -0.35f, -0.35f, len, 0.7f, 0.7f, bone);
        Part tip = Part.at(len, 0, 0).anim((t, k, o) -> o[2] = -sin(t * 8f + phase - 0.8f) * 22f + 6f);
        tip.box(0, -0.3f, -0.3f, len * 0.7f, 0.6f, 0.6f, bone);
        w.kid(tip);
        w.tone(0.9f).box(0.3f, -0.1f, 0.2f, len - 0.2f, 0.25f, wid, skin).tone(1f);
        tip.tone(0.85f).box(0.1f, -0.1f, 0.2f, len * 0.6f, 0.25f, wid * 0.8f, skin).tone(1f);
        return w;
    }

    private static void companions(List<Cosmetic> out) {
        // Baby dragon
        Part dr = Part.group();
        dr.anim((t, k, o) -> {
            o[4] = sin(t * 2f) * 0.9f;
            o[1] = sin(t * 0.8f) * 8f;
        });
        dr.box(-1.6f, -1.4f, -2.2f, 3.2f, 2.8f, 4.4f, 0).tone(1.12f).box(-1.2f, 0.5f, -2.0f, 2.4f, 1.0f, 4.0f, 2).tone(1f);
        for (int i = 0; i < 4; i++) dr.tone(0.85f).box(-0.3f, -1.9f, -1.6f + i * 1.0f, 0.6f, 0.6f, 0.5f, 1).tone(1f);
        Part head = Part.at(0, -0.7f, -2.4f).anim((t, k, o) -> {
            o[0] = sin(t * 1.5f) * 4f;
            o[1] = sin(t * 0.9f) * 10f;
        });
        head.box(-1.5f, -1.3f, -2.4f, 3f, 2.6f, 2.6f, 0).box(-1f, 0f, -4f, 2f, 1.1f, 1.7f, 0)
                .glow(true).boxc(-1.3f, -0.8f, -2.5f, 0.6f, 0.6f, 0.3f, 0xFFE24A).boxc(0.7f, -0.8f, -2.5f, 0.6f, 0.6f, 0.3f, 0xFFE24A).glow(false);
        Part horn = Part.at(0.8f, -1.3f, -0.6f).rot(-25, 0, 14);
        horn.box(-0.3f, -1.5f, -0.3f, 0.6f, 1.6f, 0.6f, 1);
        head.kid(Part.pair(horn));
        dr.kid(head);
        Part tail = Part.at(0, 0.2f, 2.2f);
        Part tc = tail;
        for (int i = 0; i < 5; i++) {
            final int n = i;
            Part sg = Part.at(0, 0, i == 0 ? 0 : 1.7f).anim((t, k, o) -> o[1] = sin(t * 3f - n * 0.7f) * 14f);
            float w = 2.2f - i * 0.38f;
            sg.tone(1f - 0.04f * i).box(-w / 2, -w / 2, 0, w, w, 1.8f, 0);
            tc.kid(sg);
            tc = sg;
        }
        dr.kid(tail);
        dr.kid(Part.pair(flapWing(4.4f, 3.4f, 1, 0, 0f)));
        for (int i = 0; i < 2; i++) {
            Part leg = Part.at(i == 0 ? 1.1f : -1.1f, 1.2f, -1.2f);
            leg.box(-0.4f, 0, -0.4f, 0.8f, 1.2f, 0.8f, 1);
            dr.kid(leg);
        }
        add(out, "baby_dragon", "Baby dragon", "تنين صغير", Slot.COMPANION, Anchor.FLOAT, new int[]{0x35C13A, 0x1B5E20, 0xC9FF9A}, dr);

        // Baby phoenix
        Part ph = Part.group();
        ph.anim((t, k, o) -> {
            o[4] = sin(t * 2.4f) * 1.0f;
            o[1] = sin(t * 0.9f) * 10f;
        });
        ph.glow(true).box(-1.6f, -1.6f, -1.8f, 3.2f, 3.0f, 3.6f, 0).tone(1.15f).box(-1.2f, 0.2f, -1.7f, 2.4f, 1.2f, 3.0f, 1).tone(1f).glow(false);
        Part hd = Part.at(0, -1.9f, -1.2f).anim((t, k, o) -> o[1] = sin(t * 1.3f) * 14f);
        hd.glow(true).box(-1.2f, -1.2f, -1.2f, 2.4f, 2.4f, 2.4f, 0).glow(false);
        hd.box(-0.5f, -0.2f, -2.2f, 1f, 0.6f, 1.1f, 2);
        hd.glow(true).boxc(-1.25f, -0.7f, -1.25f, 0.5f, 0.5f, 0.3f, 0xFFFFFF).boxc(0.75f, -0.7f, -1.25f, 0.5f, 0.5f, 0.3f, 0xFFFFFF).glow(false);
        for (int i = 0; i < 3; i++) {
            Part cr = Part.at(0, -1.2f, -0.4f + i * 0.8f).rot(-15 - i * 8, 0, 0);
            cr.glow(true).box(-0.3f, -1.4f + i * 0.2f, -0.3f, 0.6f, 1.4f, 0.6f, 2).glow(false);
            hd.kid(cr);
        }
        ph.kid(hd);
        for (int i = 0; i < 5; i++) {
            final int n = i;
            Part tf = Part.at((i - 2) * 0.5f, 0.2f, 1.7f).rot(0, (i - 2) * 9f, 0).anim((t, k, o) -> o[0] = sin(t * 4f - n * 0.5f) * 7f);
            tf.glow(true).tone(1f - 0.05f * (n % 2)).box(-0.35f, -0.3f, 0, 0.7f, 0.6f, 3.6f + (n % 3 == 1 ? 1.2f : 0f), n % 2 == 0 ? 0 : 2).glow(false);
            ph.kid(tf);
        }
        Part pw = flapWing(4.6f, 3.0f, 0, 1, 0f);
        pw.glow(true);
        ph.kid(Part.pair(pw));
        add(out, "baby_phoenix", "Baby phoenix", "عنقاء صغيرة", Slot.COMPANION, Anchor.FLOAT, new int[]{0xFF6A1F, 0xFFB000, 0xFFF06A}, ph);
    }

    // ------------------------------------------------------------------ back items (BODY: x -4..4, y 0..12, back = +z)
    private static void backs(List<Cosmetic> out) {
        // Katana on the back
        Part kt = Part.at(0.5f, 6f, 3f).rot(0, 0, 38);
        kt.box(-0.8f, -6f, -0.8f, 1.6f, 22f, 1.6f, 0);
        kt.box(-0.95f, 15.2f, -0.95f, 1.9f, 1.1f, 1.9f, 2);
        kt.box(-0.7f, -12.8f, -0.7f, 1.4f, 6.8f, 1.4f, 1);
        for (int i = 0; i < 4; i++) kt.tone(0.7f).box(-0.78f, -12.4f + i * 1.6f, -0.78f, 1.56f, 0.45f, 1.56f, 0).tone(1f);
        kt.box(-1.9f, -6.7f, -1.2f, 3.8f, 0.7f, 2.4f, 2);
        kt.tone(0.8f).box(-0.9f, 2.2f, -0.9f, 1.8f, 0.5f, 1.8f, 2).tone(1f);
        kt.box(-0.9f, -13.4f, -0.9f, 1.8f, 0.8f, 1.8f, 2);
        kt.sway(0.12f, 0.06f);
        add(out, "katana", "Katana", "كاتانا", Slot.BODY, Anchor.BODY, new int[]{0x20232E, 0xB22A2A, 0xFFC933}, kt);

        // Round shield
        Part sh = Part.at(0, 5.6f, 2.6f).sway(0.1f, 0.05f);
        sh.box(-3.6f, -5f, 0, 7.2f, 10f, 0.8f, 0).box(-5f, -3.6f, 0, 10f, 7.2f, 0.8f, 0).box(-4.4f, -4.4f, 0, 8.8f, 8.8f, 0.8f, 0);
        sh.tone(0.82f).box(-5.2f, -3.4f, 0.75f, 0.9f, 6.8f, 0.4f, 1).box(4.3f, -3.4f, 0.75f, 0.9f, 6.8f, 0.4f, 1)
                .box(-3.4f, -5.2f, 0.75f, 6.8f, 0.9f, 0.4f, 1).box(-3.4f, 4.3f, 0.75f, 6.8f, 0.9f, 0.4f, 1).tone(1f);
        sh.box(-0.8f, -3.8f, 0.8f, 1.6f, 7.6f, 0.45f, 2).box(-3.8f, -0.8f, 0.8f, 7.6f, 1.6f, 0.45f, 2);
        sh.glow(true).boxc(-1.3f, -1.3f, 1.0f, 2.6f, 2.6f, 0.6f, 0xE0202A).glow(false);
        add(out, "knight_shield", "Knight shield", "درع فارس", Slot.BODY, Anchor.BODY, new int[]{0x3A4A7A, 0xC9CED8, 0xFFC933}, sh);

        // Dragon spine
        Part sp = Part.group();
        for (int i = 0; i < 7; i++) {
            final int n = i;
            float sz = 1.2f + 1.5f * sin((i + 0.5f) / 7f * PI);
            Part s = Part.at(0, 0.8f + i * 1.65f, 2.2f).rot(-28, 0, 0).anim((t, k, o) -> o[6] = sin(t * 2f + n * 0.5f) * 0.07f);
            s.box(-sz / 2, -sz * 1.1f, -sz / 2, sz, sz * 1.1f, sz, 0);
            s.tone(1.15f).glow(true).box(-sz * 0.3f, -sz * 2.1f, -sz * 0.3f, sz * 0.6f, sz, sz * 0.6f, 2).glow(false).tone(1f);
            sp.kid(s);
        }
        sp.box(-0.5f, 0.2f, 1.9f, 1f, 11.4f, 0.8f, 1);
        add(out, "dragon_spine", "Dragon spine", "عمود تنين", Slot.BODY, Anchor.BODY, new int[]{0x3A2B2B, 0x241818, 0xFF5A1F}, sp);

        // Crystal cluster
        Part cc = Part.at(0, 6f, 3f);
        cc.box(-3.2f, -4.2f, -0.4f, 6.4f, 8.4f, 1.2f, 1);
        float[][] cr = {{0f, 5.5f, -4f, 0f}, {-2.2f, 4.5f, -7f, -14f}, {2.2f, 4.0f, 8f, 16f}, {-3.6f, 3f, -20f, -30f}, {3.6f, 3f, 22f, 28f}};
        for (int i = 0; i < cr.length; i++) {
            final int n = i;
            Part c = Part.at(cr[i][0], -2.5f, 0.8f).rot(cr[i][2], 0, cr[i][3]);
            float h = (cr[i][1] + 2.5f) * 1.7f;
            c.glow(true).tone(0.92f + 0.08f * (i % 2)).box(-0.9f, -h, -0.9f, 1.8f, h, 1.8f, 0).box(-0.55f, -h - 1.4f, -0.55f, 1.1f, 1.5f, 1.1f, 0)
                    .box(-0.25f, -h - 2.2f, -0.25f, 0.5f, 0.9f, 0.5f, 2).glow(false);
            c.anim((t, k, o) -> o[6] = sin(t * 2.2f + n) * 0.05f);
            cc.kid(c);
        }
        add(out, "crystal_cluster", "Crystal cluster", "تجمع كريستال", Slot.BODY, Anchor.BODY, new int[]{0x6FD3FF, 0x2A4A7A, 0xFFFFFF}, cc);
    }
}
