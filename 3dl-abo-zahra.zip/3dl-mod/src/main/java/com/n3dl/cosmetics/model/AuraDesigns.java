package com.n3dl.cosmetics.model;

import static com.n3dl.cosmetics.model.M.*;

import com.n3dl.cosmetics.model.Cosmetic.Anchor;
import com.n3dl.cosmetics.model.Cosmetic.Slot;
import java.util.List;

/** Auras: effects that surround the player. Origin = middle of the body (y = 12 in model space). */
final class AuraDesigns {
    private AuraDesigns() {
    }

    private static void aura(List<Cosmetic> out, String id, String en, String ar, int[] pal, Part p) {
        out.add(new Cosmetic(id, en, ar, Slot.AURA, Anchor.AURA, pal, p));
    }

    /** A looping value 0..1 for particle i. */
    private static float life(float t, int i, float period) {
        float v = (t / period + M.hash(i * 7 + 3)) % 1f;
        return v < 0 ? v + 1f : v;
    }

    static void register(List<Cosmetic> out) {
        // Orbiting stars
        Part st = Part.group();
        for (int i = 0; i < 6; i++) {
            final int n = i;
            Part s = Part.at(0, 0, 0).anim((t, k, o) -> {
                float a = t * 1.3f + n * (2 * PI / 6);
                o[3] = cos(a) * 11f;
                o[5] = sin(a) * 11f;
                o[4] = sin(t * 2f + n) * 3f - 2f;
                o[1] = t * 180f;
            });
            s.glow(true).box(-1.6f, -0.4f, -0.4f, 3.2f, 0.8f, 0.8f, 0).box(-0.4f, -1.6f, -0.4f, 0.8f, 3.2f, 0.8f, 0).box(-0.6f, -0.6f, -0.6f, 1.2f, 1.2f, 1.2f, 2);
            st.kid(s);
        }
        aura(out, "stars", "Orbiting stars", "نجوم تدور", new int[]{0xFFD34D, 0xFFF3B0, 0xFFFFFF}, st);

        // Flames
        Part fl = Part.group();
        for (int i = 0; i < 14; i++) {
            final int n = i;
            Part p = Part.at(0, 0, 0).anim((t, k, o) -> {
                float l = life(t, n, 1.8f);
                float a = M.hash(n * 5 + 1) * 2 * PI + l * 1.5f;
                float r = 4.5f + M.hash(n * 3 + 2) * 4f;
                o[3] = cos(a) * r;
                o[5] = sin(a) * r;
                o[4] = 12f - l * 26f;
                o[6] = -l * 0.7f;
            });
            p.glow(true).box(-1f, -1f, -1f, 2f, 2f, 2f, n % 3 == 0 ? 1 : 0);
            fl.kid(p);
        }
        aura(out, "flames", "Fire embers", "جمرات نار", new int[]{0xFF5A1F, 0xFFC933, 0xFFF06A}, fl);

        // Snow
        Part sn = Part.group();
        for (int i = 0; i < 16; i++) {
            final int n = i;
            Part p = Part.at(0, 0, 0).anim((t, k, o) -> {
                float l = life(t, n, 4.5f);
                float a = M.hash(n * 5 + 1) * 2 * PI;
                float r = 5f + M.hash(n * 3 + 2) * 9f;
                o[3] = cos(a) * r + sin(t * 2f + n) * 1.2f;
                o[5] = sin(a) * r;
                o[4] = -14f + l * 40f;
            });
            p.glow(true).box(-0.6f, -0.6f, -0.6f, 1.2f, 1.2f, 1.2f, n % 2);
            sn.kid(p);
        }
        aura(out, "snow", "Snowfall", "ثلج متساقط", new int[]{0xFFFFFF, 0xBFE6FF, 0xFFFFFF}, sn);

        // Hearts
        Part ht = Part.group();
        for (int i = 0; i < 7; i++) {
            final int n = i;
            Part p = Part.at(0, 0, 0).anim((t, k, o) -> {
                float l = life(t, n, 3f);
                float a = M.hash(n * 5 + 1) * 2 * PI + l;
                float r = 6f + M.hash(n * 3 + 2) * 4f;
                o[3] = cos(a) * r;
                o[5] = sin(a) * r;
                o[4] = 14f - l * 30f;
                o[6] = -abs(l - 0.5f) * 0.2f;
            });
            p.glow(true).box(-1.6f, -1.2f, -0.4f, 1.4f, 1.4f, 0.8f, 0).box(0.2f, -1.2f, -0.4f, 1.4f, 1.4f, 0.8f, 0)
                    .box(-1.6f, 0.2f, -0.4f, 3.2f, 1.2f, 0.8f, 0).box(-0.8f, 1.4f, -0.4f, 1.6f, 1f, 0.8f, 0).box(-0.4f, 2.4f, -0.4f, 0.8f, 0.6f, 0.8f, 1);
            ht.kid(p);
        }
        aura(out, "hearts", "Floating hearts", "قلوب طايرة", new int[]{0xFF4F8B, 0xFF9BC0, 0xFFFFFF}, ht);

        // Ghosts
        Part gs = Part.group();
        for (int i = 0; i < 4; i++) {
            final int n = i;
            Part g = Part.at(0, 0, 0).anim((t, k, o) -> {
                float a = -t * 1.1f + n * (PI / 2);
                o[3] = cos(a) * 13f;
                o[5] = sin(a) * 13f;
                o[4] = sin(t * 2.4f + n * 1.7f) * 5f - 3f;
                o[1] = M.deg(-a) - 90f;
            });
            g.alpha(0.85f).glow(true).box(-1.8f, -2f, -1.4f, 3.6f, 3.6f, 2.8f, 0).box(-1.8f, 1.6f, -1.4f, 1.2f, 1f, 2.8f, 0).box(0.6f, 1.6f, -1.4f, 1.2f, 1f, 2.8f, 0)
                    .glow(false).alpha(1f).boxc(-1.1f, -0.9f, -1.6f, 0.8f, 1f, 0.4f, 0x101018).boxc(0.3f, -0.9f, -1.6f, 0.8f, 1f, 0.4f, 0x101018);
            gs.kid(g);
        }
        aura(out, "ghosts", "Haunting ghosts", "أشباح تحوم", new int[]{0xF4F6FF, 0xC9D2FF, 0x101018}, gs);

        // Lightning
        Part lg = Part.group();
        for (int i = 0; i < 6; i++) {
            final int n = i;
            Part b = Part.at(0, 0, 0).anim((t, k, o) -> {
                float a = n * (2 * PI / 6) + 0.4f;
                float seg = (float) Math.floor(t * 9f + n * 3f);
                float vis = M.hash((int) seg + n * 11) > 0.45f ? 1f : -1f;
                float jx = (M.hash((int) seg * 3 + n) - 0.5f) * 4f;
                o[3] = cos(a) * (8f + jx);
                o[5] = sin(a) * (8f + jx);
                o[4] = (M.hash((int) seg * 5 + n) - 0.5f) * 16f;
                o[6] = vis < 0 ? -1f : 0f;
            });
            b.glow(true).box(-0.3f, -4f, -0.3f, 0.6f, 3f, 0.6f, 0).box(0.1f, -1.2f, -0.3f, 0.6f, 3f, 0.6f, 1).box(-0.6f, 1.6f, -0.3f, 0.6f, 3f, 0.6f, 0)
                    .box(-0.2f, 4.2f, -0.3f, 0.6f, 2f, 0.6f, 1);
            lg.kid(b);
        }
        aura(out, "lightning", "Electric sparks", "شرارات كهرباء", new int[]{0x6FE8FF, 0xFFF06A, 0xFFFFFF}, lg);

        // Rune circle (on the ground)
        Part rn = Part.at(0, 12f, 0);
        Part ring = Part.at(0, 12f, 0).anim((t, k, o) -> o[1] = t * 45f);
        ring.glow(true);
        for (int i = 0; i < 12; i++) {
            Part s = Part.at(0, 0, 0).rot(0, i * 30f, 0);
            s.box(-2.6f, -0.2f, 13.2f, 5.2f, 0.4f, 0.8f, 0);
            if (i % 2 == 0) s.box(-0.5f, -0.2f, 9.5f, 1f, 0.4f, 3.4f, 1);
            ring.kid(s);
        }
        Part inner = Part.at(0, 12f, 0).anim((t, k, o) -> o[1] = -t * 70f);
        inner.glow(true);
        for (int i = 0; i < 6; i++) {
            Part s = Part.at(0, 0, 0).rot(0, i * 60f, 0);
            s.box(-1.4f, -0.2f, 6.4f, 2.8f, 0.4f, 0.8f, 2).box(-0.4f, -0.2f, 4f, 0.8f, 0.4f, 2.4f, 1);
            inner.kid(s);
        }
        rn.kid(ring).kid(inner);
        aura(out, "runes", "Magic circle", "دائرة سحرية", new int[]{0xB06BFF, 0x6FD3FF, 0xFFFFFF}, Part.at(0, 0, 0).kid(ring).kid(inner));

        // Galaxy
        Part gx = Part.group();
        for (int i = 0; i < 20; i++) {
            final int n = i;
            Part p = Part.at(0, 0, 0).anim((t, k, o) -> {
                float r = 7f + M.hash(n * 3 + 1) * 9f;
                float a = t * (0.5f + M.hash(n * 7 + 2) * 1.2f) + n * 1.7f;
                o[3] = cos(a) * r;
                o[5] = sin(a) * r;
                o[4] = (M.hash(n * 11 + 5) - 0.5f) * 30f;
                o[6] = sin(t * 4f + n) * 0.3f - 0.1f;
            });
            p.glow(true).box(-0.5f, -0.5f, -0.5f, 1f, 1f, 1f, n % 3);
            gx.kid(p);
        }
        aura(out, "galaxy", "Galaxy dust", "غبار مجرة", new int[]{0x8A5CFF, 0x4AA8FF, 0xFFFFFF}, gx);

        // Sakura petals
        Part sk = Part.group();
        for (int i = 0; i < 14; i++) {
            final int n = i;
            Part p = Part.at(0, 0, 0).anim((t, k, o) -> {
                float l = life(t, n, 5f);
                float a = M.hash(n * 5 + 1) * 2 * PI + l * 2f;
                float r = 5f + M.hash(n * 3 + 2) * 9f;
                o[3] = cos(a) * r;
                o[5] = sin(a) * r;
                o[4] = -16f + l * 42f;
                o[0] = t * 120f + n * 30f;
                o[2] = t * 90f + n * 50f;
            });
            p.box(-1f, -0.2f, -0.7f, 2f, 0.4f, 1.4f, n % 2);
            sk.kid(p);
        }
        aura(out, "petals", "Sakura petals", "بتلات ساكورا", new int[]{0xFFB3D1, 0xFF7FAE, 0xFFFFFF}, sk);
    }
}
