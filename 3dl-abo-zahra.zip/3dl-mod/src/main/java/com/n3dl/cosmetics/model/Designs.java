package com.n3dl.cosmetics.model;

import com.n3dl.cosmetics.model.Cosmetic.Slot;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Registry of every 3D cosmetic design and every bundle. */
public final class Designs {
    private Designs() {
    }

    /** A preset that fills several slots at once. Empty id = leave slot empty. */
    public record Bundle(String id, String en, String ar, String wings, String head, String body, String pet, String comp, String aura,
                         String cape, String outfit) {
    }

    private static final List<Cosmetic> ALL = new ArrayList<>();
    private static final List<Bundle> BUNDLES = new ArrayList<>();

    static {
        WingDesigns.register(ALL);
        HeadDesigns.register(ALL);
        BodyDesigns.register(ALL);
        PetDesigns.register(ALL);
        AuraDesigns.register(ALL);
        PremiumDesigns.register(ALL);
        BUNDLES.add(new Bundle("inferno", "Inferno", "الجحيم", "phoenix", "devil", "dragon_tail", "", "wisp", "flames", "fire_animated.png", ""));
        BUNDLES.add(new Bundle("frost", "Frost", "الصقيع", "crystal", "halo", "scarf", "penguin", "ghost", "snow", "ice.png", ""));
        BUNDLES.add(new Bundle("royal", "Royal", "ملكي", "angel", "crown", "pauldrons", "cat", "", "stars", "n3dl_gold.png", ""));
        BUNDLES.add(new Bundle("galaxy", "Galaxy", "المجرة", "fairy", "wizard", "backpack", "", "planet", "galaxy", "galaxy_animated.png", ""));
        BUNDLES.add(new Bundle("cyber", "Cyber", "سايبر", "cyber", "headphones", "jetpack", "", "drone", "lightning", "matrix_animated.png", "robot.png"));
        BUNDLES.add(new Bundle("spartan", "Spartan", "المحارب", "", "spartan", "pauldrons", "dog", "", "flames", "crimson.png", "knight.png"));
        BUNDLES.add(new Bundle("spooky", "Spooky", "مرعب", "demon", "devil", "dragon_tail", "", "mini_bat", "ghosts", "midnight.png", "skeleton.png"));
        BUNDLES.add(new Bundle("sakura", "Sakura", "ساكورا", "butterfly", "cat_ears", "fox_tail", "bunny", "fairy_pet", "petals", "sunset.png", ""));
        BUNDLES.add(new Bundle("explorer", "Explorer", "المستكشف", "", "propeller", "backpack", "fox", "bee", "", "emerald.png", "astronaut.png"));
    }

    public static List<Cosmetic> all() {
        return Collections.unmodifiableList(ALL);
    }

    public static List<Bundle> bundles() {
        return Collections.unmodifiableList(BUNDLES);
    }

    public static List<Cosmetic> of(Slot s) {
        List<Cosmetic> r = new ArrayList<>();
        for (Cosmetic c : ALL) if (c.slot == s) r.add(c);
        return r;
    }

    public static Cosmetic find(Slot s, String id) {
        if (id == null || id.isEmpty()) return null;
        for (Cosmetic c : ALL) if (c.slot == s && c.id.equals(id)) return c;
        return null;
    }

    public static Bundle bundle(String id) {
        for (Bundle b : BUNDLES) if (b.id().equals(id)) return b;
        return null;
    }
}
