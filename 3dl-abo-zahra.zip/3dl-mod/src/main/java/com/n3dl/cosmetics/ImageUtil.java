package com.n3dl.cosmetics;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

/** Turns any picture into a cape texture. */
public final class ImageUtil {
    private ImageUtil() {
    }

    /** A real cape texture is 64x32 (or an exact multiple of it). */
    public static boolean isCapeShaped(int w, int h) {
        return w >= 64 && w % 64 == 0 && h == w / 2;
    }

    /** A vertical strip of cape frames: 64N x 32M with M > 1. */
    public static boolean isCapeStrip(int w, int h) {
        return w >= 64 && w % 64 == 0 && h > w / 2 && h % (w / 2) == 0;
    }

    private static int average(BufferedImage src) {
        long r = 0, g = 0, b = 0, n = 0;
        int step = Math.max(1, Math.min(src.getWidth(), src.getHeight()) / 40);
        for (int y = 0; y < src.getHeight(); y += step) {
            for (int x = 0; x < src.getWidth(); x += step) {
                int p = src.getRGB(x, y);
                if (((p >>> 24) & 255) < 40) continue;
                r += (p >> 16) & 255;
                g += (p >> 8) & 255;
                b += p & 255;
                n++;
            }
        }
        if (n == 0) return 0x303040;
        return (int) (r / n) << 16 | (int) (g / n) << 8 | (int) (b / n);
    }

    private static Graphics2D hq(BufferedImage img) {
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        return g;
    }

    /**
     * Puts a normal picture on the back of a cape.
     * fit: STRETCH (fill, distorted), COVER (fill, crop the edges), CONTAIN (whole picture, bars on the sides).
     * k = detail level: output is 64k x 32k.
     */
    public static BufferedImage pictureToCape(BufferedImage src, String fit, int k) {
        int W = 64 * k, H = 32 * k;
        BufferedImage out = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Color base = new Color(average(src));
        Color dark = new Color(Math.round(base.getRed() * 0.55f), Math.round(base.getGreen() * 0.55f), Math.round(base.getBlue() * 0.55f));
        Graphics2D g = hq(out);
        // whole cape area (22 x 17) in a dark version of the picture colour: sides, top, inside
        g.setColor(dark);
        g.fillRect(0, 0, 22 * k, 17 * k);
        int x = k, y = k, w = 10 * k, h = 16 * k; // the face people see
        g.setColor(base);
        g.fillRect(x, y, w, h);
        int sw = src.getWidth(), sh = src.getHeight();
        if ("STRETCH".equals(fit)) {
            g.drawImage(src, x, y, w, h, null);
        } else if ("CONTAIN".equals(fit)) {
            double s = Math.min(w / (double) sw, h / (double) sh);
            int dw = (int) Math.round(sw * s), dh = (int) Math.round(sh * s);
            g.drawImage(src, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh, null);
        } else {
            double s = Math.max(w / (double) sw, h / (double) sh);
            int cw = (int) Math.round(w / s), ch = (int) Math.round(h / s);
            int cx = Math.max(0, (sw - cw) / 2), cy = Math.max(0, (sh - ch) / 2);
            cw = Math.min(cw, sw - cx);
            ch = Math.min(ch, sh - cy);
            g.drawImage(src.getSubimage(cx, cy, cw, ch), x, y, w, h, null);
        }
        // inside of the cape: same picture, darker
        g.drawImage(out.getSubimage(x, y, w, h), 11 * k + k, y, null);
        g.setColor(new Color(0, 0, 0, 110));
        g.fillRect(11 * k + k, y, w, h);
        g.dispose();
        return out;
    }
}
