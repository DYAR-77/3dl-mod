package com.n3dl.cosmetics.model;

import static com.n3dl.cosmetics.model.M.*;

import com.n3dl.cosmetics.model.Cosmetic.Anchor;
import com.n3dl.cosmetics.model.Cosmetic.Slot;
import java.util.List;

/** Bodywear. Body box is x -4..4, y 0..12, z -2..2 (back = +z). */
final class BodyDesigns {
    private BodyDesigns() {
    }

    private static void add(List<Cosmetic> out, String id, String en, String ar, int[] pal, Part p) {
        out.add(new Cosmetic(id, en, ar, Slot.BODY, Anchor.BODY, pal, p));
    }

    /** Chain of tapering segments that curl and sway. */
    private static Part tail(int n, float len, float w0, float w1, float curl, float sway, int role, int tipRole, boolean spikes) {
        Part root = Part.at(0, 10.5f, 2.2f).rot(-50, 0, 0);
        Part cur = root;
        for (int i = 0; i < n; i++) {
            float u = i / (float) n;
            float w = lerp(w0, w1, u);
            final int idx = i;
            Part seg = Part.at(0, 0, i == 0 ? 0 : len).rot(0, 0, 0);
            seg.anim((t, k, o) -> {
                o[1] = sin(t * 2.2f - idx * 0.5f) * sway * (0.5f + 0.5f * k);
                o[0] = -curl;
            });
            seg.box(-w / 2, -w / 2, 0, w, w, len + 0.2f, i >= n - 2 ? tipRole : role);
            if (spikes && i % 2 == 0 && i < n - 1) seg.box(-0.4f, -w / 2 - 1.3f, 0.5f, 0.8f, 1.4f, 1.2f, 2);
            cur.kid(seg);
            cur = seg;
        }
        return root;
    }

    /** Segmented cloth: every strip hangs from the one above, reacts to your speed and turning, and ripples in the wind. */
    private static Part clothCape(int n, float seg, float width) {
        Part root = Part.at(0, 0.4f, 2.3f).rot(4, 0, 0);
        Part cur = root;
        for (int i = 0; i < n; i++) {
            final int idx = i;
            float w = width + i * 0.35f;
            Part strip = Part.at(0, i == 0 ? 0 : seg, 0);
            strip.sway(0.11f, 0.02f * (i + 1));
            strip.anim((t, k, o) -> {
                o[0] = 2.4f * (0.4f + k) * sin(t * 3.2f - idx * 0.7f);
                o[2] = 1.8f * (0.3f + 0.7f * k) * sin(t * 2.1f + idx * 0.55f);
            });
            int role = i >= n - 1 ? 2 : 0;
            strip.tone(1.04f - 0.05f * (i % 2) - 0.012f * i).box(-w / 2, 0, 0, w, seg + 0.2f, 0.7f, role);
            if (i == n - 2) strip.tone(0.9f).box(-w / 2, seg - 0.4f, 0.05f, w, 0.5f, 0.75f, 2);
            strip.tone(1f);
            cur.kid(strip);
            cur = strip;
        }
        return root;
    }

    static void register(List<Cosmetic> out) {
        // Backpack
        Part bp = Part.group();
        bp.box(-3.6f, 0.8f, 2.2f, 7.2f, 9.4f, 3.4f, 0).box(-3.8f, 0.6f, 2.1f, 7.6f, 3f, 3.6f, 1).box(-2.2f, 6f, 5.5f, 4.4f, 3.2f, 1.2f, 1)
                .box(-3.8f, -0.2f, -2.4f, 1.3f, 8f, 0.5f, 1).box(2.5f, -0.2f, -2.4f, 1.3f, 8f, 0.5f, 1)
                .box(-3.8f, -0.4f, -2.4f, 1.3f, 0.6f, 4.9f, 1).box(2.5f, -0.4f, -2.4f, 1.3f, 0.6f, 4.9f, 1)
                .boxc(-0.8f, 2.4f, 5.7f, 1.6f, 1.6f, 0.5f, 0xFFD34D).boxc(-0.8f, 7f, 6.6f, 1.6f, 1f, 0.4f, 0xFFD34D);
        add(out, "backpack", "Backpack", "حقيبة ظهر", new int[]{0x7A4A2A, 0x5A3418, 0xFFD34D}, bp);

        // Jetpack
        Part jp = Part.group();
        jp.box(-4.2f, 1f, 2.2f, 3.4f, 9f, 3.4f, 0).box(0.8f, 1f, 2.2f, 3.4f, 9f, 3.4f, 0).box(-4.4f, 0.4f, 2.1f, 3.8f, 1.2f, 3.6f, 1)
                .box(0.6f, 0.4f, 2.1f, 3.8f, 1.2f, 3.6f, 1).box(-3.4f, 10f, 3f, 1.8f, 1.2f, 1.8f, 1).box(1.6f, 10f, 3f, 1.8f, 1.2f, 1.8f, 1)
                .box(-0.8f, 3f, 3f, 1.6f, 4f, 1.6f, 1);
        for (int s = -1; s <= 1; s += 2) {
            Part fl = Part.at(s * 2.5f, 11.2f, 3.9f);
            fl.anim((t, k, o) -> o[6] = sin(t * 30f) * 0.15f);
            fl.glow(true).boxc(-0.9f, 0, -0.9f, 1.8f, 3.4f, 1.8f, 0xFF8A1F).boxc(-0.5f, 0, -0.5f, 1f, 4.6f, 1f, 0xFFE27A);
            jp.kid(fl);
        }
        add(out, "jetpack", "Jetpack", "جيت باك", new int[]{0x9AA3B5, 0x3A3F4C, 0xFF8A1F}, jp);

        // Scarf
        Part sc = Part.group();
        sc.box(-4.5f, -0.6f, -2.6f, 9f, 2f, 5.2f, 0).box(-4.55f, 0.3f, -2.65f, 9.1f, 0.5f, 5.3f, 1).box(-4.5f, 1.4f, -2.6f, 3f, 1.6f, 0.9f, 0);
        Part tl = Part.at(2f, 1.2f, 2.7f).anim((t, k, o) -> {
            o[0] = 14f + sin(t * 3f) * 8f + k * 25f;
            o[2] = sin(t * 2.1f) * 5f;
        });
        tl.box(-1.4f, 0, -0.4f, 2.8f, 6f, 0.8f, 0).box(-1.4f, 2.4f, -0.45f, 2.8f, 0.8f, 0.9f, 1);
        Part tl2 = Part.at(0, 6f, 0).anim((t, k, o) -> o[0] = 10f + sin(t * 3f - 1f) * 10f);
        tl2.box(-1.4f, 0, -0.4f, 2.8f, 5f, 0.8f, 0).box(-1.4f, 3f, -0.45f, 2.8f, 0.8f, 0.9f, 1);
        tl.kid(tl2);
        sc.kid(tl);
        add(out, "scarf", "Flowing scarf", "وشاح", new int[]{0xD62F3B, 0xFFFFFF, 0xFFD34D}, sc);

        // Fox tail
        Part fox = tail(5, 3.4f, 4.2f, 3f, -8f, 14f, 0, 1, false);
        fox.box(0, 0, 0, 0.01f, 0.01f, 0.01f, 0);
        add(out, "fox_tail", "Fox tail", "ذيل ثعلب", new int[]{0xE8782A, 0xFFFFFF, 0x3A2A22}, fox);

        // Cat tail
        Part cat = tail(8, 2.2f, 1.8f, 1.5f, 11f, 13f, 0, 1, false);
        add(out, "cat_tail", "Cat tail", "ذيل قطة", new int[]{0x2E2E38, 0xFF8FB8, 0xFFFFFF}, cat);

        // Dragon tail
        Part dr = tail(9, 3f, 3.6f, 0.9f, -4f, 10f, 0, 1, true);
        add(out, "dragon_tail", "Dragon tail", "ذيل تنين", new int[]{0x35C13A, 0xC9FF5A, 0xE8EE5A}, dr);

        // Pauldrons
        Part pd = Part.group();
        for (int s = -1; s <= 1; s += 2) {
            float x = s * 6.2f;
            pd.box(x - 2.6f, -1f, -3f, 5.2f, 1.6f, 6f, 0).box(x - 2.2f, -2.2f, -2.5f, 4.4f, 1.4f, 5f, 0)
                    .box(x - 0.5f + s * 0.0f, -4.4f, -0.6f, 1f, 2.4f, 1.2f, 1).box(x - 2.9f, 0.4f, -3.2f, 5.8f, 0.7f, 6.4f, 1);
        }
        add(out, "pauldrons", "Shoulder armor", "دروع الكتف", new int[]{0x8A8F99, 0xFFC933, 0xFFC933}, pd);

        // Bow tie
        Part bt = Part.group();
        bt.box(-3.3f, 0.2f, -2.6f, 2.6f, 2.4f, 0.8f, 0).box(0.7f, 0.2f, -2.6f, 2.6f, 2.4f, 0.8f, 0).box(-0.8f, 0.5f, -2.8f, 1.6f, 1.8f, 1.1f, 1);
        add(out, "bowtie", "Bow tie", "ربطة عنق فراشة", new int[]{0xD62F3B, 0x8A1620, 0xFFFFFF}, bt);

        // Quiver
        Part qv = Part.at(0, 0, 0);
        Part qb = Part.at(0, 6f, 2.8f).rot(0, 0, 20);
        qb.box(-1.8f, -6.5f, 0, 3.6f, 12f, 3.2f, 0).box(-1.9f, -6.6f, -0.1f, 3.8f, 1.2f, 3.4f, 1);
        for (int i = -1; i <= 1; i++) {
            qb.box(i * 1.1f - 0.25f, -10.5f, 1.2f, 0.5f, 4f, 0.5f, 2).boxc(i * 1.1f - 0.7f, -11.2f, 1f, 1.4f, 1.4f, 0.9f, 0xFFFFFF);
        }
        qb.box(-0.5f, -6.4f, -0.4f, 1f, 11f, 0.4f, 1);
        qv.kid(qb);
        add(out, "quiver", "Arrow quiver", "جعبة سهام", new int[]{0x7A4A2A, 0x4A2E18, 0xB8B8C0}, qv);

        // Lantern belt
        Part lb = Part.group();
        lb.box(-4.3f, 9.4f, -2.3f, 8.6f, 1.3f, 4.6f, 0).boxc(-0.9f, 9.3f, -2.5f, 1.8f, 1.5f, 0.4f, 0xFFD34D);
        Part ln = Part.at(4.5f, 10.5f, 0).anim((t, k, o) -> o[2] = sin(t * 2.4f) * 7f + k * 8f);
        ln.box(-0.2f, 0, -0.2f, 0.4f, 2.2f, 0.4f, 1).box(-1.4f, 2.2f, -1.4f, 2.8f, 0.6f, 2.8f, 1).glow(true).boxc(-1.1f, 2.8f, -1.1f, 2.2f, 2.8f, 2.2f, 0xFFD34D)
                .glow(false).box(-1.4f, 5.6f, -1.4f, 2.8f, 0.6f, 2.8f, 1);
        lb.kid(ln);
        add(out, "lantern", "Lantern belt", "حزام فانوس", new int[]{0x5A3418, 0x3A3F4C, 0xFFD34D}, lb);

        // Cloth cape: a chain of strips that streams behind you and ripples like a flag
        out.add(new Cosmetic("cloth_cape", "Cloth cape (physics)", "كيب قماش (فيزياء)", Slot.BODY, Anchor.BODY,
                new int[]{0xC0392B, 0x8E2A20, 0xFFD34D}, clothCape(9, 2.7f, 9.2f)));
    }
}
