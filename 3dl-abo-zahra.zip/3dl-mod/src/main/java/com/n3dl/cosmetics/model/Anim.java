package com.n3dl.cosmetics.model;

/**
 * Animation of one part. Fills o with offsets that are ADDED to the part's base pose:
 * o[0..2] = rotation X, Y, Z in degrees, o[3..5] = move X, Y, Z in pixels, o[6] = extra scale.
 * t = seconds, k = activity 0..1 (how much the owner is moving).
 */
@FunctionalInterface
public interface Anim {
    void apply(float t, float k, float[] o);
}
