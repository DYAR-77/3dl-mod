package com.n3dl.cosmetics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/** World position of the pet; follows the local player. Updated once per client tick. */
public final class PetState {
    private PetState() {
    }

    public static double x, y, z, px, py, pz;
    /** Heading in Minecraft yaw degrees, and the previous value. */
    public static float yaw, pyaw;
    /** 0..1 how fast the pet is moving. */
    public static float speed;
    private static boolean init;

    public static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null) {
            init = false;
            return;
        }
        if (!init) {
            x = px = p.getX();
            y = py = p.getY();
            z = pz = p.getZ();
            yaw = pyaw = p.getYRot();
            init = true;
        }
        px = x;
        py = y;
        pz = z;
        pyaw = yaw;
        double dx = p.getX() - x, dz = p.getZ() - z;
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d > 16 || Math.abs(p.getY() - y) > 8) {
            x = px = p.getX();
            y = py = p.getY();
            z = pz = p.getZ();
            return;
        }
        // stay about 1.6 blocks away, drifting toward the player's side
        double stop = 1.6;
        double step = 0;
        if (d > stop) {
            step = Math.min(d - stop, 0.1 + d * 0.12);
            x += dx / d * step;
            z += dz / d * step;
            float want = (float) (Math.toDegrees(Math.atan2(-dx, dz)));
            float diff = wrap(want - yaw);
            yaw += diff * 0.35f;
        } else {
            float want = p.getYRot();
            yaw += wrap(want - yaw) * 0.06f;
        }
        double gy = groundY(mc, x, p.getY() + 1.0, z, p.getY());
        if (gy > y) y = Math.min(gy, y + 0.35);      // step up
        else y = Math.max(gy, y - (0.08 + (y - gy) * 0.15)); // gravity
        speed += ((float) Math.min(1, step * 6) - speed) * 0.4f;
    }

    /** Top of the highest solid block at or below fromY (within 5 blocks), else the fallback. */
    private static double groundY(Minecraft mc, double x, double fromY, double z, double fallback) {
        try {
            net.minecraft.core.BlockPos.MutableBlockPos bp = new net.minecraft.core.BlockPos.MutableBlockPos();
            int bx = (int) Math.floor(x), bz = (int) Math.floor(z);
            int top = (int) Math.floor(fromY);
            for (int by = top; by > top - 6; by--) {
                bp.set(bx, by, bz);
                var st = mc.level.getBlockState(bp);
                var sh = st.getCollisionShape(mc.level, bp);
                if (!sh.isEmpty()) {
                    double h = by + sh.max(net.minecraft.core.Direction.Axis.Y);
                    if (h <= fromY + 0.01) return h;
                }
            }
        } catch (Throwable t) {
            // fall through
        }
        return fallback;
    }

    private static float wrap(float a) {
        a %= 360f;
        if (a > 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }
}
