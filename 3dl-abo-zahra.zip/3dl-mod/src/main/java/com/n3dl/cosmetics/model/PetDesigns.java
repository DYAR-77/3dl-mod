package com.n3dl.cosmetics.model;

import static com.n3dl.cosmetics.model.M.*;
import static com.n3dl.cosmetics.model.Shapes.*;

import com.n3dl.cosmetics.model.Cosmetic.Anchor;
import com.n3dl.cosmetics.model.Cosmetic.Slot;
import java.util.List;

/** Ground pets (feet at y = 0, up = -y, front = -z) and floating companions (centred on the origin). */
final class PetDesigns {
    private PetDesigns() {
    }

    private static void pet(List<Cosmetic> out, String id, String en, String ar, int[] pal, Part p) {
        out.add(new Cosmetic(id, en, ar, Slot.PET, Anchor.PET, pal, p));
    }

    private static void comp(List<Cosmetic> out, String id, String en, String ar, int[] pal, Part p) {
        out.add(new Cosmetic(id, en, ar, Slot.COMPANION, Anchor.FLOAT, pal, p));
    }

    /** Head motion: looks toward the owner and idles. */
    private static Anim headLook(float amp) {
        return (t, k, o) -> {
            o[1] = clamp(Phys.cur.look, -50f, 50f);
            o[0] = sin(t * 1.4f) * 2f * amp + 4f * k;
        };
    }

    /** Walking leg: x,z position, w size, h length. phase swaps the diagonal pair. */
    private static Part leg(float x, float z, float w, float h, float phase, int role, int paw) {
        Part l = Part.at(x, -h, z);
        l.anim((t, k, o) -> o[0] = sin(t * 12f + phase) * 42f * k);
        l.box(-w / 2, 0, -w / 2, w, h * 0.72f, w, role);
        l.tone(0.88f).box(-w * 0.58f, h * 0.72f, -w * 0.75f, w * 1.16f, h * 0.28f, w * 1.3f, paw);
        return l;
    }

    private static Part legSock(float x, float z, float w, float h, float phase, int role, int sock) {
        Part l = Part.at(x, -h, z);
        l.anim((t, k, o) -> o[0] = sin(t * 12f + phase) * 42f * k);
        l.box(-w / 2, 0, -w / 2, w, h * 0.5f, w, role);
        l.boxc(-w / 2 - 0.05f, h * 0.5f, -w / 2 - 0.1f, w + 0.1f, h * 0.5f, w + 0.2f, sock);
        return l;
    }

    private static Part quadLegs(float x, float zf, float zb, float w, float h, int role, int paw) {
        Part r = Part.group();
        r.kid(leg(-x, zf, w, h, 0, role, paw)).kid(leg(x, zf, w, h, PI, role, paw))
                .kid(leg(-x, zb, w, h, PI, role, paw)).kid(leg(x, zb, w, h, 0, role, paw));
        return r;
    }

    private static Part earPair(float x, float y, float z, float half, float height, int role, int inner, float tilt) {
        Part g = Part.group();
        for (int s = -1; s <= 1; s += 2) {
            Part e = Part.at(s * x, y, z).rot(0, 0, s * tilt);
            cone(e, 0, 0, 0, half, height, half * 0.15f, 4, role, 1f, 0.95f);
            e.boxc(-half * 0.45f, -height * 0.75f, -half - 0.05f, half * 0.9f, height * 0.6f, 0.3f, 0xF29BB0);
            g.kid(e);
        }
        return g;
    }

    private static Part whiskers(float y, float z) {
        Part w = Part.group();
        for (int s = -1; s <= 1; s += 2) {
            for (int i = 0; i < 2; i++) {
                Part a = Part.at(s * 1.6f, y + i * 0.55f, z).rot(0, s * (-14 + i * 22), s * (4 - i * 8));
                a.boxc(s > 0 ? 0 : -2.6f, -0.1f, -0.1f, 2.6f, 0.2f, 0.2f, 0xF2F2F2);
                w.kid(a);
            }
        }
        return w;
    }

    static void register(List<Cosmetic> out) {
        // ---------------------------------------------------------------- Cat
        Part cat = Part.group();
        cat.anim((t, k, o) -> o[4] = -abs(sin(t * 12f)) * 0.5f * k);
        cat.kid(quadLegs(1.5f, -2.9f, 3.1f, 1.5f, 3.2f, 0, 1));
        blob(cat, 0, -5.9f, 0.1f, 2.5f, 2.3f, 4.3f, 0, 6, 1.08f, 0.82f);
        blob(cat, 0, -5.8f, -3.4f, 1.9f, 1.9f, 1.4f, 1, 4, 1.05f, 0.9f);
        // stripes
        for (int i = 0; i < 3; i++) cat.tone(0.62f).box(-2.55f, -8.1f, -1.5f + i * 2.1f, 5.1f, 0.7f, 0.9f, 0);
        Part ch = Part.at(0, -8.6f, -4.1f).anim(headLook(1f));
        blob(ch, 0, 0, 0, 2.7f, 2.3f, 2.3f, 0, 6, 1.1f, 0.88f);
        blob(ch, 0, 0.9f, -2.1f, 1.3f, 0.9f, 0.9f, 1, 3, 1.1f, 0.95f);
        ch.kid(earPair(1.65f, -1.7f, -0.2f, 1.1f, 2.3f, 0, 2, 10));
        ch.boxc(-0.45f, 0.1f, -3.05f, 0.9f, 0.6f, 0.5f, 0xF28DA0);
        ch.boxc(-1.9f, -0.95f, -2.4f, 1.5f, 1.7f, 0.5f, 0x7CE08A).boxc(0.4f, -0.95f, -2.4f, 1.5f, 1.7f, 0.5f, 0x7CE08A);
        ch.boxc(-1.45f, -0.95f, -2.5f, 0.6f, 1.7f, 0.4f, 0x14141C).boxc(0.85f, -0.95f, -2.5f, 0.6f, 1.7f, 0.4f, 0x14141C);
        ch.kid(whiskers(1.1f, -2.0f));
        cat.kid(ch);
        Part tail = Part.at(0, -6.6f, 4.2f).rot(25, 0, 0).sway(-0.55f, 0.10f).swayYaw().anim((t, k, o) -> o[1] = sin(t * 2.4f) * 8f);
        tail.tone(0.95f).box(-0.75f, -0.75f, 0, 1.5f, 1.5f, 3f, 0);
        Part t2 = Part.at(0, 0, 3f).rot(28, 0, 0).sway(-0.45f, 0.18f).swayYaw();
        t2.box(-0.7f, -0.7f, 0, 1.4f, 1.4f, 3f, 0);
        Part t3 = Part.at(0, 0, 3f).rot(26, 0, 0).sway(-0.4f, 0.26f).swayYaw();
        t3.tone(0.8f).box(-0.65f, -0.65f, 0, 1.3f, 1.3f, 2.6f, 1);
        t2.kid(t3);
        tail.kid(t2);
        cat.kid(tail);
        pet(out, "cat", "Cat", "قطة", new int[]{0xE0903A, 0xF6E6CC, 0xF28DA0}, cat);

        // ---------------------------------------------------------------- Dog
        Part dog = Part.group();
        dog.anim((t, k, o) -> o[4] = -abs(sin(t * 12f)) * 0.7f * k);
        dog.kid(quadLegs(1.7f, -3.3f, 3.5f, 1.8f, 3.6f, 0, 1));
        blob(dog, 0, -6.4f, 0.2f, 2.8f, 2.6f, 4.8f, 0, 6, 1.08f, 0.82f);
        blob(dog, 0, -5.8f, -3.9f, 2.1f, 2.1f, 1.5f, 1, 4, 1.05f, 0.92f);
        blob(dog, 0, -8.2f, 1.2f, 2.9f, 1.0f, 2.2f, 1, 3, 0.7f, 0.6f); // saddle patch
        Part dh = Part.at(0, -9.4f, -4.7f).anim(headLook(1f));
        blob(dh, 0, 0, 0, 2.7f, 2.5f, 2.5f, 0, 6, 1.1f, 0.88f);
        blob(dh, 0, 1.0f, -2.5f, 1.5f, 1.2f, 1.4f, 1, 4, 1.12f, 0.95f);
        dh.boxc(-0.7f, 0.1f, -3.9f, 1.4f, 0.9f, 0.5f, 0x1A1A1F);
        shapesEyes(dh, 1.35f, -0.7f, -2.5f, 1.1f);
        dh.boxc(-0.5f, 2.2f, -3.2f, 1.0f, 1.4f, 0.4f, 0xF06C84).anim((t, k, o) -> o[1] = Phys.cur.look);
        for (int s = -1; s <= 1; s += 2) {
            Part ear = Part.at(s * 2.8f, -1.9f, -0.4f).rot(0, 0, s * 8).sway(0.9f, 0.08f);
            ear.tone(0.72f).box(-0.6f, 0, -1.2f, 1.2f, 3.8f, 2.4f, 0);
            dh.kid(ear);
        }
        dog.kid(dh);
        Part dtail = Part.at(0, -7.2f, 4.9f).rot(55, 0, 0).sway(-0.6f, 0.08f).swayYaw()
                .anim((t, k, o) -> o[1] = sin(t * (7f + 9f * k)) * 30f);
        dtail.box(-0.8f, -0.8f, 0, 1.6f, 1.6f, 3.2f, 0);
        Part dt2 = Part.at(0, 0, 3.2f).rot(25, 0, 0).sway(-0.4f, 0.16f).swayYaw();
        dt2.tone(0.9f).box(-0.7f, -0.7f, 0, 1.4f, 1.4f, 2.6f, 0);
        dtail.kid(dt2);
        dog.kid(dtail);
        pet(out, "dog", "Dog", "كلب", new int[]{0xA8713C, 0xE9D3A9, 0x3A2A1C}, dog);

        // ---------------------------------------------------------------- Fox
        Part fox = Part.group();
        fox.anim((t, k, o) -> o[4] = -abs(sin(t * 12f)) * 0.6f * k);
        fox.kid(legSock(-1.4f, -3f, 1.4f, 3.4f, 0, 0, 0x2A1E18)).kid(legSock(1.4f, -3f, 1.4f, 3.4f, PI, 0, 0x2A1E18))
                .kid(legSock(-1.4f, 3.2f, 1.4f, 3.4f, PI, 0, 0x2A1E18)).kid(legSock(1.4f, 3.2f, 1.4f, 3.4f, 0, 0, 0x2A1E18));
        blob(fox, 0, -6.2f, 0.1f, 2.3f, 2.2f, 4.5f, 0, 6, 1.1f, 0.85f);
        blob(fox, 0, -5.6f, -3.6f, 1.6f, 1.7f, 1.4f, 1, 4, 1.05f, 0.95f);
        Part fh = Part.at(0, -8.8f, -4.3f).anim(headLook(1f));
        blob(fh, 0, 0, 0, 2.5f, 2.1f, 2.1f, 0, 5, 1.1f, 0.9f);
        fh.tone(1f).box(-1.0f, 0.2f, -4.3f, 2.0f, 1.3f, 2.4f, 0);
        fh.box(-1.2f, 1.1f, -4.1f, 2.4f, 0.8f, 2.2f, 1);
        fh.boxc(-0.55f, 0.1f, -4.55f, 1.1f, 0.8f, 0.5f, 0x15151A);
        fh.boxc(-2.2f, 0.5f, -2.0f, 0.5f, 0.9f, 1.8f, 0xF4F0E8).boxc(1.7f, 0.5f, -2.0f, 0.5f, 0.9f, 1.8f, 0xF4F0E8);
        fh.boxc(-1.95f, -0.9f, -2.2f, 1.1f, 1.0f, 0.5f, 0xE8B83A).boxc(0.85f, -0.9f, -2.2f, 1.1f, 1.0f, 0.5f, 0xE8B83A);
        fh.boxc(-1.65f, -0.9f, -2.3f, 0.5f, 1.0f, 0.4f, 0x15151A).boxc(1.15f, -0.9f, -2.3f, 0.5f, 1.0f, 0.4f, 0x15151A);
        for (int s = -1; s <= 1; s += 2) {
            Part e = Part.at(s * 1.7f, -1.7f, 0.1f).rot(0, 0, s * 8);
            cone(e, 0, 0, 0, 1.2f, 3.4f, 0.2f, 4, 0, 1f, 0.95f);
            e.boxc(-0.35f, -3.6f, -0.2f, 0.7f, 1.0f, 0.4f, 0x1C1512);
            e.boxc(-0.5f, -2.2f, -1.25f, 1.0f, 1.8f, 0.3f, 0x2A1E18);
            fh.kid(e);
        }
        fox.kid(fh);
        Part ft = Part.at(0, -6.2f, 4.6f).rot(20, 0, 0).sway(-0.7f, 0.10f).swayYaw().anim((t, k, o) -> o[1] = sin(t * 2f) * 7f);
        blob(ft, 0, 0, 2.3f, 1.8f, 1.8f, 3.0f, 0, 4, 1.05f, 0.85f);
        Part ft2 = Part.at(0, -0.6f, 5.0f).rot(22, 0, 0).sway(-0.5f, 0.18f).swayYaw();
        blob(ft2, 0, 0, 1.6f, 1.6f, 1.6f, 2.2f, 0, 3, 1.0f, 0.85f);
        blobc(ft2, 0, -0.2f, 3.6f, 1.4f, 1.4f, 1.5f, 0xF6F2EA, 3, 1.05f, 0.95f);
        ft.kid(ft2);
        fox.kid(ft);
        pet(out, "fox", "Fox", "ثعلب", new int[]{0xE2691F, 0xF6F0E6, 0x2A1E18}, fox);

        // ---------------------------------------------------------------- Slime
        Part sl = Part.group();
        sl.anim((t, k, o) -> {
            float b = abs(sin(t * 3.2f));
            o[4] = -b * 2.4f - 0.0f;
            o[6] = 0.05f * sin(t * 6.4f);
        });
        sl.alpha(0.62f).tone(1.05f).box(-3.5f, -7, -3.5f, 7, 7, 7, 0);
        sl.alpha(1f).tone(0.8f).box(-1.6f, -4.9f, -1.6f, 3.2f, 3.2f, 3.2f, 1);
        sl.tone(1f).glow(true).alpha(0.9f).box(-3.0f, -6.5f, -3.55f, 1.6f, 1.2f, 0.2f, 2).glow(false).alpha(1f);
        sl.boxc(-2.4f, -4.6f, -3.6f, 1.3f, 1.5f, 0.3f, 0x1B2A1B).boxc(1.1f, -4.6f, -3.6f, 1.3f, 1.5f, 0.3f, 0x1B2A1B);
        sl.boxc(-0.9f, -2.6f, -3.6f, 1.8f, 0.5f, 0.3f, 0x1B2A1B);
        pet(out, "slime", "Slime", "سلايم", new int[]{0x57D957, 0x2E8F3A, 0xD8FFD8}, sl);

        // ---------------------------------------------------------------- Chick
        Part ck = Part.group();
        ck.anim((t, k, o) -> o[4] = -abs(sin(t * 9f)) * 1.4f * k - abs(sin(t * 2.2f)) * 0.15f);
        blob(ck, 0, -4.6f, 0.3f, 2.9f, 2.8f, 3.0f, 0, 6, 1.1f, 0.85f);
        blob(ck, 0, -3.8f, -1.8f, 1.9f, 1.8f, 1.3f, 1, 4, 1.08f, 0.95f);
        for (int s = -1; s <= 1; s += 2) {
            Part w = Part.at(s * 3.0f, -5.5f, 0.2f).rot(0, 0, s * 12).anim((t, k, o) -> o[2] = (sin(t * 14f) * 22f * k + 6f * sin(t * 1.6f)));
            w.tone(0.88f).box(-0.4f, 0, -1.4f, 0.8f, 3.0f, 2.8f, 0);
            ck.kid(w);
            ck.boxc(s * 0.9f - 0.3f, -1.6f, -0.4f, 0.6f, 1.6f, 0.6f, 0xE8962A);
            ck.boxc(s * 0.9f - 0.9f, -0.35f, -1.3f, 1.8f, 0.35f, 1.6f, 0xE8962A);
        }
        Part kh = Part.at(0, -8.6f, -1.6f).anim(headLook(1f));
        blob(kh, 0, 0, 0, 2.3f, 2.2f, 2.2f, 0, 5, 1.12f, 0.92f);
        kh.boxc(-0.8f, 0.2f, -3.3f, 1.6f, 0.7f, 1.3f, 0xF0902A).boxc(-0.7f, 0.85f, -3.1f, 1.4f, 0.4f, 1.0f, 0xD97A1E);
        shapesEyes(kh, 1.25f, -0.5f, -2.1f, 1.0f);
        kh.box(-0.4f, -2.8f, -0.8f, 0.8f, 1.0f, 0.8f, 0).box(0.4f, -2.5f, -0.5f, 0.6f, 0.8f, 0.6f, 0).box(-1.1f, -2.5f, -0.5f, 0.6f, 0.8f, 0.6f, 0);
        ck.kid(kh);
        Part tf = Part.at(0, -6f, 3.1f).rot(-20, 0, 0).sway(-0.5f, 0.1f).swayYaw();
        tf.tone(0.85f).box(-1.2f, -1.6f, 0, 2.4f, 1.8f, 0.9f, 0);
        ck.kid(tf);
        pet(out, "chick", "Chick", "كتكوت", new int[]{0xFFD84A, 0xFFF0A0, 0xF0902A}, ck);

        // ---------------------------------------------------------------- Bunny
        Part bn = Part.group();
        bn.anim((t, k, o) -> {
            float h = abs(sin(t * 8.5f)) * k;
            o[4] = -h * 2.8f;
            o[0] = -h * 6f;
        });
        blob(bn, 0, -4.3f, 0.2f, 2.5f, 2.5f, 3.2f, 0, 6, 1.1f, 0.85f);
        blob(bn, 0, -3.4f, 1.9f, 3.3f, 1.8f, 1.9f, 0, 4, 1.05f, 0.82f);
        blob(bn, 0, -3.5f, -2.0f, 1.7f, 1.8f, 1.2f, 1, 4, 1.1f, 0.95f);
        blobc(bn, 0, -4.4f, 3.6f, 1.4f, 1.4f, 1.4f, 0xFFFFFF, 3, 1.1f, 0.95f);
        bn.kid(Part.at(-1.1f, 0, -3f).rot(0, 0, 0)).kid(Part.at(1.1f, 0, -3f));
        bn.box(-1.7f, -0.9f, -3.6f, 1.2f, 0.9f, 1.8f, 1).box(0.5f, -0.9f, -3.6f, 1.2f, 0.9f, 1.8f, 1);
        Part bh = Part.at(0, -7.3f, -2.5f).anim(headLook(1f));
        blob(bh, 0, 0, 0, 2.2f, 2.0f, 2.0f, 0, 5, 1.12f, 0.9f);
        blob(bh, 0, 0.8f, -1.6f, 1.2f, 0.9f, 0.9f, 1, 3, 1.1f, 1f);
        bh.boxc(-0.4f, 0.1f, -2.6f, 0.8f, 0.55f, 0.4f, 0xF28DA0);
        shapesEyes(bh, 1.2f, -0.5f, -2.0f, 1.0f);
        bh.kid(whiskers(1.0f, -1.7f));
        for (int s = -1; s <= 1; s += 2) {
            final float sf = s;
            Part e = Part.at(s * 1.0f, -1.8f, 0.2f).rot(0, 0, s * 9).sway(-1.0f, 0.12f)
                    .anim((t, k, o) -> o[0] = -sin(t * 2.4f + sf) * 3f - 10f * k);
            e.box(-0.75f, -5.8f, -0.45f, 1.5f, 5.8f, 0.9f, 0);
            e.boxc(-0.4f, -5.2f, -0.55f, 0.8f, 4.6f, 0.3f, 0xF29BB0);
            bh.kid(e);
        }
        bn.kid(bh);
        pet(out, "bunny", "Bunny", "أرنب", new int[]{0xE6E2DC, 0xFFFFFF, 0xF29BB0}, bn);

        // ---------------------------------------------------------------- Penguin
        Part pg = Part.group();
        pg.anim((t, k, o) -> {
            o[2] = sin(t * 8f) * 7f * k;
            o[4] = -abs(sin(t * 8f)) * 0.5f * k;
        });
        blob(pg, 0, -6.0f, 0.2f, 3.3f, 4.8f, 2.9f, 0, 8, 1.05f, 0.8f);
        blobc(pg, 0, -5.6f, -1.3f, 2.3f, 3.6f, 1.6f, 0xF5F5F8, 7, 1.08f, 0.9f);
        Part ph = Part.at(0, -11.6f, -0.2f).anim(headLook(0.8f));
        blob(ph, 0, 0, 0, 2.4f, 2.0f, 2.2f, 0, 5, 1.1f, 0.85f);
        ph.boxc(-0.9f, 0.2f, -3.3f, 1.8f, 0.7f, 1.4f, 0xF0902A).boxc(-0.8f, 0.9f, -3.1f, 1.6f, 0.4f, 1.1f, 0xD97A1E);
        ph.boxc(-1.6f, -0.6f, -2.1f, 1.3f, 1.4f, 0.4f, 0xF5F5F8).boxc(0.3f, -0.6f, -2.1f, 1.3f, 1.4f, 0.4f, 0xF5F5F8);
        ph.boxc(-1.2f, -0.2f, -2.3f, 0.7f, 0.8f, 0.4f, 0x15151C).boxc(0.5f, -0.2f, -2.3f, 0.7f, 0.8f, 0.4f, 0x15151C);
        pg.kid(ph);
        for (int s = -1; s <= 1; s += 2) {
            Part f = Part.at(s * 3.5f, -9.2f, 0f).rot(0, 0, s * 14).anim((t, k, o) -> o[2] = sin(t * 8f) * 16f * k);
            f.tone(0.85f).box(-0.45f, 0, -1.2f, 0.9f, 4.4f, 2.4f, 0);
            pg.kid(f);
            final float sf2 = s;
            Part pf = Part.at(s * 1.4f, -0.6f, -0.6f).anim((t, k, o) -> o[0] = sin(t * 8f + (sf2 > 0 ? 0 : PI)) * 25f * k);
            pf.boxc(-1.0f, 0, -1.6f, 2.0f, 0.6f, 3.0f, 0xF0902A);
            pg.kid(pf);
        }
        pet(out, "penguin", "Penguin", "بطريق", new int[]{0x23262E, 0xF5F5F8, 0xF0902A}, pg);

        // ---------------------------------------------------------------- Panda
        Part pd = Part.group();
        pd.anim((t, k, o) -> o[4] = -abs(sin(t * 12f)) * 0.6f * k);
        pd.kid(legSock(-2.0f, -2.9f, 2.0f, 3.6f, 0, 2, 0x17171B)).kid(legSock(2.0f, -2.9f, 2.0f, 3.6f, PI, 2, 0x17171B))
                .kid(legSock(-2.0f, 3.1f, 2.0f, 3.6f, PI, 2, 0x17171B)).kid(legSock(2.0f, 3.1f, 2.0f, 3.6f, 0, 2, 0x17171B));
        blob(pd, 0, -6.6f, 0.1f, 3.4f, 3.2f, 4.6f, 0, 7, 1.08f, 0.85f);
        blobc(pd, 0, -6.2f, -2.6f, 3.5f, 3.0f, 1.2f, 0x1B1B20, 5, 1.0f, 0.9f);
        Part pdh = Part.at(0, -10.0f, -4.1f).anim(headLook(1f));
        blob(pdh, 0, 0, 0, 3.2f, 2.8f, 2.7f, 0, 7, 1.12f, 0.9f);
        blob(pdh, 0, 1.1f, -2.4f, 1.4f, 1.0f, 1.0f, 1, 3, 1.1f, 1f);
        pdh.boxc(-0.6f, 0.4f, -3.5f, 1.2f, 0.8f, 0.5f, 0x15151A);
        for (int s = -1; s <= 1; s += 2) {
            Part pa = Part.at(s * 1.65f, -0.4f, -2.6f).rot(0, 0, s * -18);
            pa.boxc(-0.95f, -1.0f, 0, 1.9f, 2.2f, 0.45f, 0x17171B);
            pa.glow(true).boxc(-0.35f, -0.35f, -0.12f, 0.6f, 0.6f, 0.3f, 0xFFFFFF).glow(false);
            pdh.kid(pa);
            Part ear = Part.at(s * 2.3f, -2.3f, 0.2f);
            blobc(ear, 0, 0, 0, 1.3f, 1.1f, 0.9f, 0x17171B, 3, 1f, 0.9f);
            pdh.kid(ear);
        }
        pd.kid(pdh);
        blobc(pd, 0, -6.6f, 5.0f, 1.2f, 1.2f, 1.0f, 0xFFFFFF, 3, 1.1f, 0.9f);
        pet(out, "panda", "Panda", "باندا", new int[]{0xF2F2F2, 0xFFFFFF, 0x17171B}, pd);

        // ================================================================ Companions
        // ---- Drone
        Part dr = Part.group().sway(0.6f, 0.06f);
        dr.anim((t, k, o) -> {
            o[4] = sin(t * 2.6f) * 0.5f;
            o[0] = clamp(Phys.cur.vf * 2.5f, -14f, 14f);
        });
        blob(dr, 0, 0, 0, 2.6f, 1.3f, 2.6f, 0, 4, 1.1f, 0.8f);
        blob(dr, 0, -1.1f, 0, 1.6f, 0.8f, 1.6f, 1, 3, 1.1f, 0.95f);
        dr.glow(true).boxc(-1.2f, -0.4f, -2.7f, 2.4f, 0.8f, 0.3f, 0x2EF2FF).boxc(-0.5f, 0.3f, -2.75f, 1.0f, 0.9f, 0.3f, 0x101820);
        dr.glow(false);
        for (int i = 0; i < 4; i++) {
            float ang = 45 + i * 90;
            Part arm = Part.at(0, 0.1f, 0).rot(0, ang, 0);
            arm.tone(0.8f).box(-0.45f, -0.4f, -0.4f, 0.9f, 0.8f, 5.4f, 1);
            Part pod = Part.at(0, -0.3f, 5.3f);
            blob(pod, 0, 0, 0, 0.9f, 0.8f, 0.9f, 1, 2, 1.0f, 0.85f);
            Part rot = Part.at(0, -1.0f, 0).anim((t, k, o) -> o[1] = (t * 900f) % 360f);
            rot.alpha(0.8f).tone(1.1f).box(-3.0f, 0, -0.35f, 6.0f, 0.2f, 0.7f, 2).box(-0.35f, 0, -3.0f, 0.7f, 0.2f, 6.0f, 2);
            pod.kid(rot);
            arm.kid(pod);
            dr.kid(arm);
        }
        dr.boxc(-1.6f, 1.2f, -1.4f, 0.4f, 1.2f, 0.4f, 0x333840).boxc(1.2f, 1.2f, -1.4f, 0.4f, 1.2f, 0.4f, 0x333840)
                .boxc(-1.6f, 1.2f, 1.0f, 0.4f, 1.2f, 0.4f, 0x333840).boxc(1.2f, 1.2f, 1.0f, 0.4f, 1.2f, 0.4f, 0x333840);
        comp(out, "drone", "Drone", "درون", new int[]{0x3A4150, 0x6B7588, 0xAAF4FF}, dr);

        // ---- Fairy
        Part fp = Part.group();
        fp.anim((t, k, o) -> {
            o[4] = sin(t * 3f) * 0.8f;
            o[3] = sin(t * 1.5f) * 0.6f;
        });
        fp.glow(true).alpha(0.28f).tone(1f);
        blob(fp, 0, 0, 0, 3.4f, 3.4f, 3.4f, 2, 4, 1f, 1f);
        fp.glow(false).alpha(1f);
        blobc(fp, 0, -2.3f, 0, 1.2f, 1.2f, 1.2f, 0xFFE0C8, 3, 1.1f, 0.95f);
        fp.boxc(-1.3f, -3.4f, -1.2f, 2.6f, 1.0f, 2.4f, 0xFFD966);
        fp.boxc(-1.3f, -3.0f, 0.9f, 2.6f, 2.2f, 0.7f, 0xFFD966);
        cone(fp, 0, 0.0f, 0, 1.0f, 2.6f, 0.4f, 3, 0, 1f, 1f);
        fp.glow(true).tone(1f).box(-1.3f, -0.3f, -1.3f, 2.6f, 0.4f, 2.6f, 2);
        fp.glow(false);
        for (int s = -1; s <= 1; s += 2) {
            Part w = Part.at(s * 0.8f, -1.1f, 0.9f).rot(0, s * -35, 0).anim((t, k, o) -> {
                float f = sin(t * 38f);
                o[1] = -26f * f;
            });
            w.glow(true).alpha(0.7f).box(0, -3.3f, -0.1f, 3.8f, 3.6f, 0.2f, 2).box(0.2f, 0.2f, -0.1f, 2.6f, 2.0f, 0.2f, 1);
            fp.kid(w);
        }
        Part spark = Part.at(0, 0, 0).anim((t, k, o) -> o[1] = (t * 120f) % 360f);
        for (int i = 0; i < 4; i++) {
            Part s = Part.at(0, 0, 0).rot(0, i * 90, 0);
            s.glow(true).boxc(3.2f, -1.0f + (i % 2) * 1.4f, -0.2f, 0.5f, 0.5f, 0.5f, 0xFFF4A0);
            spark.kid(s);
        }
        fp.kid(spark);
        comp(out, "fairy_pet", "Fairy", "جنية صغيرة", new int[]{0xFF9BD8, 0xFFF4A0, 0xB8F0FF}, fp);

        // ---- Ghost
        Part gh = Part.group().sway(0.4f, 0.1f);
        gh.anim((t, k, o) -> o[4] = sin(t * 2f) * 1.0f);
        gh.alpha(0.88f);
        blob(gh, 0, -1.0f, 0, 2.6f, 2.8f, 2.4f, 0, 6, 1.12f, 0.95f);
        for (int i = 0; i < 5; i++) {
            float a = i * 72;
            Part sk = Part.at(0, 1.6f, 0).rot(0, a, 0).anim((t, k, o) -> o[0] = sin(t * 5f + a) * 14f);
            sk.alpha(0.88f).tone(0.95f).box(-0.9f, 0, 1.0f, 1.8f, 2.4f, 1.2f, 0);
            gh.kid(sk);
        }
        gh.alpha(1f).boxc(-1.8f, -2.2f, -2.45f, 1.1f, 1.6f, 0.4f, 0x15151C).boxc(0.7f, -2.2f, -2.45f, 1.1f, 1.6f, 0.4f, 0x15151C);
        gh.boxc(-0.6f, -0.2f, -2.45f, 1.2f, 1.2f, 0.4f, 0x15151C);
        for (int s = -1; s <= 1; s += 2) {
            Part ar = Part.at(s * 2.7f, -0.6f, -0.2f).rot(0, 0, s * 30).anim((t, k, o) -> o[2] = sin(t * 3f) * 10f);
            ar.alpha(0.88f).box(-0.5f, 0, -0.7f, 1.0f, 2.2f, 1.4f, 0);
            gh.kid(ar);
        }
        comp(out, "ghost", "Ghost", "شبح", new int[]{0xF2F4FF, 0xC8CCE8, 0x15151C}, gh);

        // ---- Wisp
        Part wp = Part.group();
        wp.anim((t, k, o) -> o[4] = sin(t * 2.4f) * 1.0f);
        wp.glow(true).alpha(0.3f);
        blob(wp, 0, 0, 0, 3.0f, 3.0f, 3.0f, 0, 4, 1f, 1f);
        wp.alpha(1f).tone(1f);
        blob(wp, 0, 0, 0, 1.5f, 1.5f, 1.5f, 2, 3, 1.1f, 1.1f);
        for (int i = 0; i < 3; i++) {
            Part tl = Part.at(0, 0.4f * i, 2.4f + i * 1.6f).sway(-0.7f, 0.1f + 0.08f * i).swayYaw();
            tl.alpha(0.55f - i * 0.12f).glow(true);
            blob(tl, 0, 0, 0, 1.1f - i * 0.25f, 1.1f - i * 0.25f, 1.4f, 0, 2, 1f, 1f);
            wp.kid(tl);
        }
        for (int i = 0; i < 6; i++) {
            float ph2 = i * 60;
            float sp = 90 + 25 * (i % 3);
            Part orb = Part.at(0, 0, 0).rot(0, ph2, 0).anim((t, k, o) -> o[1] = (t * sp) % 360f);
            Part s = Part.at(4.2f + (i % 2) * 1.2f, sin(ph2) * 2f, 0);
            s.glow(true).boxc(-0.4f, -0.4f, -0.4f, 0.8f, 0.8f, 0.8f, 0xFFFFFF);
            orb.kid(s);
            wp.kid(orb);
        }
        comp(out, "wisp", "Wisp", "شعلة روحية", new int[]{0x6FD3FF, 0x2A7BFF, 0xFFFFFF}, wp);

        // ---- Bee
        Part be = Part.group();
        be.anim((t, k, o) -> {
            o[4] = sin(t * 5f) * 0.9f;
            o[0] = clamp(Phys.cur.vf * 2f, -12f, 12f) - 4f;
        });
        blob(be, 0, 0, 0.4f, 2.1f, 2.0f, 2.9f, 0, 6, 1.08f, 0.85f);
        for (int i = 0; i < 2; i++) be.boxc(-2.2f, -1.5f, -0.2f + i * 2.0f, 4.4f, 3.0f, 0.9f, 0x1A1A1F);
        blobc(be, 0, 0.1f, -3.0f, 1.9f, 1.8f, 1.6f, 0xFFC93A, 4, 1.1f, 0.9f);
        shapesEyes(be, 1.0f, -0.3f, -4.5f, 0.9f);
        be.boxc(-0.2f, 0.4f, -3.4f, 0.4f, 0.4f, 0.4f, 0x1A1A1F);
        for (int s = -1; s <= 1; s += 2) {
            Part an = Part.at(s * 0.7f, -1.7f, -3.6f).rot(-30, 0, s * 18).sway(-0.8f, 0.08f);
            an.boxc(-0.15f, -2.0f, -0.15f, 0.3f, 2.0f, 0.3f, 0x1A1A1F).boxc(-0.35f, -2.4f, -0.35f, 0.7f, 0.7f, 0.7f, 0x1A1A1F);
            be.kid(an);
            Part w = Part.at(s * 1.2f, -1.8f, 0.3f).rot(0, 0, s * -8).anim((t, k, o) -> o[2] = sin(t * 70f) * 24f);
            w.glow(true).alpha(0.55f).tone(1.1f).box(0, 0, -0.1f, 3.8f, 0.2f, 2.2f, 2);
            Part wl = s > 0 ? w : w.mirror();
            if (s > 0) be.kid(w);
            else {
                Part m = Part.at(-1.2f, -1.8f, 0.3f).rot(0, 0, 8).anim((t, k, o) -> o[2] = -sin(t * 70f) * 24f);
                m.glow(true).alpha(0.55f).tone(1.1f).box(-3.8f, 0, -0.1f, 3.8f, 0.2f, 2.2f, 2);
                be.kid(m);
            }
            be.boxc(s * 1.0f - 0.2f, 1.9f, -1.0f, 0.4f, 1.0f, 0.4f, 0x1A1A1F);
            be.boxc(s * 1.0f - 0.2f, 1.9f, 0.6f, 0.4f, 1.0f, 0.4f, 0x1A1A1F);
        }
        be.boxc(-0.35f, -0.3f, 3.2f, 0.7f, 0.7f, 1.6f, 0x1A1A1F);
        comp(out, "bee", "Bee", "نحلة", new int[]{0xFFC93A, 0x1A1A1F, 0xFFFFFF}, be);

        // ---- Planet
        Part pl = Part.group();
        pl.anim((t, k, o) -> o[4] = sin(t * 1.8f) * 0.8f);
        Part globe = Part.at(0, 0, 0).anim((t, k, o) -> o[1] = (t * 25f) % 360f);
        blob(globe, 0, 0, 0, 2.9f, 2.9f, 2.9f, 0, 8, 1.1f, 0.78f);
        for (int i = 0; i < 3; i++) {
            float y = -1.4f + i * 1.4f;
            float r = 2.95f * (float) Math.sqrt(1 - (y / 2.9f) * (y / 2.9f));
            globe.tone(0.82f + 0.1f * i).box(-r * 0.95f, y - 0.25f, -r * 0.68f, r * 1.9f, 0.5f, r * 1.36f, 1);
            globe.box(-r * 0.68f, y - 0.25f, -r * 0.95f, r * 1.36f, 0.5f, r * 1.9f, 1);
        }
        pl.kid(globe);
        Part ringP = Part.at(0, 0, 0).rot(24, 0, -12).anim((t, k, o) -> o[1] = (t * 12f) % 360f);
        for (int i = 0; i < 16; i++) {
            Part seg = Part.at(0, 0, 0).rot(0, i * 22.5f, 0);
            seg.tone(0.9f + 0.1f * (i % 2)).box(4.6f, -0.2f, -0.9f, 1.8f, 0.4f, 1.8f, 2);
            ringP.kid(seg);
        }
        pl.kid(ringP);
        Part moon = Part.at(0, 0, 0).rot(0, 0, 0).anim((t, k, o) -> o[1] = (t * 70f) % 360f);
        Part mo = Part.at(7.8f, -1.5f, 0);
        blobc(mo, 0, 0, 0, 0.9f, 0.9f, 0.9f, 0xD8D8E0, 3, 1.1f, 0.8f);
        moon.kid(mo);
        pl.kid(moon);
        comp(out, "planet", "Planet", "كوكب", new int[]{0x4AA3FF, 0x2E5EAA, 0xFFD27A}, pl);

        // ---- Mini bat
        Part mb = Part.group();
        mb.anim((t, k, o) -> {
            o[4] = sin(t * 4f) * 1.2f;
            o[0] = clamp(Phys.cur.vf * 2f, -10f, 10f);
        });
        blob(mb, 0, 0, 0.2f, 1.8f, 2.0f, 1.6f, 0, 5, 1.1f, 0.8f);
        Part mh = Part.at(0, -2.4f, -0.4f);
        blob(mh, 0, 0, 0, 1.6f, 1.4f, 1.4f, 0, 4, 1.1f, 0.9f);
        mh.box(-1.5f, -2.8f, -0.4f, 0.9f, 1.6f, 0.7f, 0).box(0.6f, -2.8f, -0.4f, 0.9f, 1.6f, 0.7f, 0);
        mh.glow(true).boxc(-1.2f, -0.6f, -1.45f, 0.8f, 0.8f, 0.3f, 0xFF3B3B).boxc(0.4f, -0.6f, -1.45f, 0.8f, 0.8f, 0.3f, 0xFF3B3B).glow(false);
        mh.boxc(-0.8f, 0.6f, -1.4f, 0.4f, 0.8f, 0.3f, 0xFFFFFF).boxc(0.4f, 0.6f, -1.4f, 0.4f, 0.8f, 0.3f, 0xFFFFFF);
        mb.kid(mh);
        for (int s = -1; s <= 1; s += 2) {
            Part w = Part.at(s * 1.5f, -1.0f, 0.2f).anim((t, k, o) -> o[2] = sin(t * 16f) * 30f * -1);
            Part bone = Part.at(0, 0, 0).rot(0, 0, s * -10);
            if (s > 0) {
                bone.tone(0.8f).box(0, -0.4f, -0.4f, 7.0f, 0.8f, 0.8f, 0);
                w.alpha(1f).tone(0.9f).box(0.5f, -0.2f, -0.3f, 6.5f, 0.2f, 0.6f, 0);
                for (int f = 0; f < 3; f++) {
                    Part fin = Part.at(1.0f + f * 2.0f, 0, 0).rot(0, 0, -50 + f * 14);
                    fin.tone(0.85f).box(0, -0.25f, -0.25f, 5.5f - f * 0.8f, 0.5f, 0.5f, 0);
                    w.kid(fin);
                }
                w.alpha(0.95f).tone(0.7f).box(0.3f, 0.2f, -0.2f, 6.0f, 3.6f, 0.2f, 1);
                w.kid(bone);
                mb.kid(w);
            } else {
                Part wm = Part.at(-1.5f, -1.0f, 0.2f).anim((t, k, o) -> o[2] = sin(t * 16f) * 30f);
                wm.tone(0.9f).box(-7.0f, -0.4f, -0.4f, 7.0f, 0.8f, 0.8f, 0);
                for (int f = 0; f < 3; f++) {
                    Part fin = Part.at(-1.0f - f * 2.0f, 0, 0).rot(0, 0, 50 - f * 14);
                    fin.tone(0.85f).box(-(5.5f - f * 0.8f), -0.25f, -0.25f, 5.5f - f * 0.8f, 0.5f, 0.5f, 0);
                    wm.kid(fin);
                }
                wm.tone(0.7f).alpha(0.95f).box(-6.3f, 0.2f, -0.2f, 6.0f, 3.6f, 0.2f, 1);
                mb.kid(wm);
            }
        }
        comp(out, "mini_bat", "Mini bat", "خفاش صغير", new int[]{0x4B3A6B, 0x2A2040, 0xFF3B3B}, mb);
    }

    /** Dark eyes with glint at both sides of a head. */
    private static void shapesEyes(Part p, float gap, float y, float z, float s) {
        Shapes.eye(p, -gap, y, z, s);
        Shapes.eye(p, gap, y, z, s);
    }
}
