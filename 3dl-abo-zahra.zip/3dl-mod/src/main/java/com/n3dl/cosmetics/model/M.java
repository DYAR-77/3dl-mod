package com.n3dl.cosmetics.model;

/** Tiny float math helpers so animation code stays short. */
public final class M {
    private M() {
    }

    public static final float PI = (float) Math.PI;

    public static float sin(double x) {
        return (float) Math.sin(x);
    }

    public static float cos(double x) {
        return (float) Math.cos(x);
    }

    public static float abs(float x) {
        return Math.abs(x);
    }

    public static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** Smooth 0..1 ramp. */
    public static float ease(float t) {
        t = clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    public static float rad(float deg) {
        return deg * (PI / 180f);
    }

    public static float deg(float rad) {
        return rad * (180f / PI);
    }

    /** Pseudo random 0..1 from an integer seed (stable between frames). */
    public static float hash(int n) {
        n = (n << 13) ^ n;
        int v = (n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff;
        return v / 2147483647f;
    }

    public static int rgb(float r, float g, float b) {
        int ri = Math.round(clamp(r, 0, 1) * 255), gi = Math.round(clamp(g, 0, 1) * 255), bi = Math.round(clamp(b, 0, 1) * 255);
        return (ri << 16) | (gi << 8) | bi;
    }

    /** hue 0..1 -> RGB */
    public static int hsv(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float r, g, b;
        int i = (int) (h * 6);
        float f = h * 6 - i, p = v * (1 - s), q = v * (1 - f * s), t2 = v * (1 - (1 - f) * s);
        switch (i % 6) {
            case 0 -> { r = v; g = t2; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t2; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t2; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return rgb(r, g, b);
    }

    public static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static int scale(int c, float k) {
        return rgb(((c >> 16) & 255) / 255f * k, ((c >> 8) & 255) / 255f * k, (c & 255) / 255f * k);
    }
}
