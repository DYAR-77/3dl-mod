package com.n3dl.cosmetics.model;

import static com.n3dl.cosmetics.model.M.*;

import com.n3dl.cosmetics.model.Cosmetic.Anchor;
import com.n3dl.cosmetics.model.Cosmetic.Slot;
import java.util.List;

/** Wings: attached to the upper back. */
final class WingDesigns {
    private WingDesigns() {
    }

    /** Flapping used by most wings. k = how much the player moves. */
    private static Anim flap(float speed, float amp) {
        return (t, k, o) -> {
            Phys ph = Phys.cur;
            float act = Math.min(1f, k + ph.air + ph.fall);
            float f = sin(t * (speed + 3f * k + 5f * ph.air));
            float a2 = Math.max(amp, 13f) * (0.75f + 0.25f * act) * (1f + 0.5f * ph.fall) * (1f - 0.35f * ph.sneak);
            o[1] = -a2 * f + 9f * ph.sneak - 6f * ph.fall;
            o[2] = a2 * 0.35f * f + 6f * ph.sneak;
        };
    }

    private static Cosmetic wings(String id, String en, String ar, int[] pal, Part left) {
        Part root = Part.pair(left);
        return new Cosmetic(id, en, ar, Slot.WINGS, Anchor.BODY, pal, root);
    }

    /** A fan of feathers. Angles are rz (negative = pointing up). */
    private static void fan(Part wing, int n, float len, float dLen, float a0, float dA, float w, float th, int r0, int r1, float curve) {
        for (int i = 0; i < n; i++) {
            Part f = Part.at(0, 0, 0.04f * i).rot(0, 0, -(a0 + i * dA));
            float l = len - i * dLen;
            f.box(0, -w / 2, -th / 2, l, w, th, i % 2 == 0 ? r0 : r1);
            if (curve != 0) {
                Part tip = Part.at(l * 0.6f, 0, 0).rot(0, 0, -curve);
                tip.box(0, -w / 2 + 0.1f, -th / 2, l * 0.42f, w - 0.2f, th, i % 2 == 0 ? r0 : r1);
                f.kid(tip);
            }
            wing.kid(f);
        }
    }

    /** Membrane between two bones, with scalloped edge. */
    private static void membrane(Part wing, float a0, float a1, int n, float len, float scallop, int role, float th) {
        for (int j = 0; j < n; j++) {
            float u = n == 1 ? 0.5f : j / (float) (n - 1);
            float a = lerp(a0, a1, u);
            float l = len * (1f - scallop * sin(u * PI));
            Part s = Part.at(0, 0, 0.02f * j).rot(0, 0, -a);
            s.box(0, -1.1f, -th / 2, l, 2.2f, th, role);
            wing.kid(s);
        }
    }

    private static Part batWing(int bone, int skin, float size, int fingers, boolean claws) {
        Part w = Part.at(2f, 1.5f, 2.4f).rot(0, -32, 0).anim(flap(2.6f, 14f));
        // arm bone going up and out
        Part arm = Part.at(0, 0, 0).rot(0, 0, -62);
        arm.box(0, -0.8f, -0.8f, 9 * size, 1.6f, 1.6f, bone);
        w.kid(arm);
        float span = 18 * size;
        float[] ang = new float[fingers];
        for (int i = 0; i < fingers; i++) ang[i] = lerp(70, -5, i / (float) (fingers - 1));
        for (int i = 0; i < fingers; i++) {
            Part f = Part.at(6 * size * cos(rad(62)) * 0f, 0, 0.1f).rot(0, 0, -ang[i]);
            f.box(0, -0.6f, -0.6f, span * (0.85f + 0.15f * (i % 2)), 1.2f, 1.2f, bone);
            w.kid(f);
        }
        for (int i = 0; i + 1 < fingers; i++) {
            membrane(w, ang[i] - 2, ang[i + 1] + 2, 6, span * 0.92f, 0.28f, skin, 0.4f);
        }
        if (claws) {
            Part c = Part.at(8.2f * size, -7.5f * size, 0).rot(0, 0, 0);
            c.box(-0.5f, -2.5f, -0.5f, 1.4f, 3f, 1.4f, bone);
            w.kid(c);
        }
        return w;
    }

    private static Part ellipse(float cx, float cy, float rx, float ry, int role, float th, float rotZ, float z) {
        Part p = Part.at(cx, cy, z).rot(0, 0, rotZ);
        int rows = Math.max(4, Math.round(ry * 2 / 1.1f));
        for (int i = 0; i < rows; i++) {
            float y0 = -ry + i * (2 * ry / rows);
            float yc = y0 + ry / rows;
            float wv = 2 * rx * (float) Math.sqrt(Math.max(0.02, 1 - (yc / ry) * (yc / ry)));
            p.box(-wv / 2, y0, -th / 2, wv, 2 * ry / rows + 0.05f, th, role);
        }
        return p;
    }


    // ------------------------------------------------------------------ realistic jointed wings

    /** Flap of one joint. lag = phase delay (the wave travels from the shoulder to the tip), gain = strength. */
    private static Anim joint(float spd, float amp, float lag, float gain) {
        return (t, k, o) -> {
            Phys ph = Phys.cur;
            float act = Math.min(1f, k + ph.air + ph.fall);
            float w = t * (spd + 2.5f * k + 4f * ph.air);
            float a = amp * (0.75f + 0.45f * act) * (1f + 0.4f * ph.fall) * (1f - 0.45f * ph.sneak);
            o[2] = -a * gain * sin(w - lag) + 14f * ph.sneak * gain - 9f * ph.fall * gain;
            o[1] = a * 0.16f * gain * sin(w - lag - 0.6f);
        };
    }

    /** One feather: three tapering slices, a shaft, brightness shading. rel = angle relative to its bone (rz). */
    private static void feather(Part bone, float px, float py, float zOff, float rel, float len, float wd,
                                int role, float tone, int tipRole, boolean glow, boolean shaft) {
        Part f = Part.at(px, py, zOff).rot(0, 0, rel);
        f.glow(glow);
        f.tone(tone).box(0, -wd / 2, -0.4f, len * 0.62f, wd, 0.8f, role);
        f.tone(tone * 0.94f).box(len * 0.62f, -wd * 0.4f, -0.4f, len * 0.28f, wd * 0.8f, 0.8f, role);
        f.tone(tone * 0.86f).box(len * 0.9f, -wd * 0.22f, -0.4f, len * 0.1f, wd * 0.44f, 0.8f, tipRole);
        if (shaft) f.tone(0.8f).box(0, -0.2f, -0.55f, len * 0.92f, 0.4f, 0.25f, tipRole);
        f.tone(1f).glow(false);
        bone.kid(f);
    }

    /**
     * Feathered wing with shoulder, elbow and wrist. Angles written "abs" are measured in the wing plane
     * (negative = up, positive = down); a child bone stores its angle relative to its parent.
     */
    private static Part featherWing(float size, int prim, int sec, int ter, int main, int alt, int tip, int boneRole,
                                    boolean glow, float spd, float amp) {
        Part s = Part.at(2f, 1.5f, 2.4f).rot(0, -18, 0).anim(joint(spd, amp, 0f, 1f));
        Part ua = Part.at(0, 0, 0).rot(0, 0, -60);                       // abs -60
        ua.glow(glow).box(0, -1f, -1f, 7 * size, 2f, 2f, boneRole).glow(false);
        s.kid(ua);
        Part el = Part.at(7 * size, 0, 0).rot(0, 0, 38).anim(joint(spd, amp, 0.55f, 0.7f)); // abs -22
        el.glow(glow).box(0, -0.9f, -0.9f, 8 * size, 1.8f, 1.8f, boneRole).glow(false);
        ua.kid(el);
        Part wr = Part.at(8 * size, 0, 0).rot(0, 0, 30).anim(joint(spd, amp, 1.1f, 0.9f));  // abs +8
        wr.glow(glow).box(0, -0.8f, -0.8f, 5.5f * size, 1.6f, 1.6f, boneRole).glow(false);
        el.kid(wr);
        // upper coverts (small, on top of everything)
        for (int i = 0; i < 7; i++) {
            float u = i / 6f;
            feather(wr, u * 5f * size, 0, 1.0f, lerp(10, 62, u) - 8 + 2, (6.5f - 2f * u) * size, 2.2f,
                    i % 2 == 0 ? main : alt, 1.02f, tip, glow, false);
        }
        // middle coverts
        for (int i = 0; i < 8; i++) {
            float u = i / 7f;
            feather(el, 1f + u * 7f * size, 0, 0.6f, lerp(58, 92, u) + 22, (7.5f - 1.5f * u) * size, 2.5f,
                    i % 2 == 0 ? alt : main, 1.0f, tip, glow, false);
        }
        // primaries on the hand: the long outer feathers
        for (int i = 0; i < prim; i++) {
            float u = prim == 1 ? 0 : i / (float) (prim - 1);
            feather(wr, u * 5f * size, 0, 0.05f * i, lerp(2, 74, u) - 8, (18f - i * 0.8f) * size, 2.7f,
                    i % 2 == 0 ? main : alt, 0.97f + 0.05f * (i % 2), tip, glow, true);
        }
        // secondaries on the forearm
        for (int i = 0; i < sec; i++) {
            float u = sec == 1 ? 0 : i / (float) (sec - 1);
            feather(el, 0.6f + u * 7.4f * size, 0, 0.02f * i, lerp(60, 98, u) + 22, (14f - i * 0.5f) * size, 2.8f,
                    i % 2 == 0 ? main : alt, 0.95f + 0.05f * (i % 2), tip, glow, true);
        }
        // tertials on the upper arm
        for (int i = 0; i < ter; i++) {
            float u = ter == 1 ? 0 : i / (float) (ter - 1);
            feather(ua, 0.6f + u * 6f * size, 0, 0.02f * i, lerp(100, 122, u) + 60, (10f - i * 0.6f) * size, 2.8f,
                    i % 2 == 0 ? main : alt, 0.93f + 0.05f * (i % 2), tip, glow, true);
        }
        return s;
    }

    /** Slices of skin between two angles (relative to the parent), lengths interpolated, scalloped edge. */
    private static void skin(Part parent, float rel0, float rel1, int n, float len0, float len1, float scallop, int role, float tone) {
        for (int j = 0; j < n; j++) {
            float u = n == 1 ? 0.5f : j / (float) (n - 1);
            float l = lerp(len0, len1, u) * (1f - scallop * sin(u * PI));
            Part sl = Part.at(0, 0, 0.02f * j).rot(0, 0, lerp(rel0, rel1, u));
            sl.tone(tone).box(0, -1.2f, -0.25f, l, 2.4f, 0.5f, role).tone(1f);
            parent.kid(sl);
        }
    }

    /** Bat / dragon wing: bones with a wave, claw, fingers and a skin membrane that moves with them. */
    private static Part membraneWing(float size, int fingers, int bone, int skin, int tip, boolean glow, float spd, float amp) {
        Part s = Part.at(2f, 1.5f, 2.4f).rot(0, -18, 0).anim(joint(spd, amp, 0f, 1f));
        Part ua = Part.at(0, 0, 0).rot(0, 0, -62);
        ua.box(0, -1.1f, -1.1f, 8 * size, 2.2f, 2.2f, bone);
        s.kid(ua);
        Part el = Part.at(8 * size, 0, 0).rot(0, 0, 45).anim(joint(spd, amp, 0.5f, 0.75f)); // abs -17
        el.box(0, -1f, -1f, 9 * size, 2f, 2f, bone);
        ua.kid(el);
        Part wr = Part.at(9 * size, 0, 0).rot(0, 0, 25).anim(joint(spd, amp, 1.0f, 0.95f)); // abs +8
        wr.box(-1f, -1f, -1f, 2f, 2f, 2f, bone);
        wr.box(-0.6f, -4.4f, -0.6f, 1.2f, 4.2f, 1.2f, tip); // thumb claw
        el.kid(wr);
        float[] ang = new float[fingers];
        float[] ln = new float[fingers];
        for (int i = 0; i < fingers; i++) {
            float u = i / (float) (fingers - 1);
            ang[i] = lerp(-4, 98, u) - 8; // relative to the wrist
            ln[i] = (19f - 2.4f * i) * size;
            Part f = Part.at(0, 0, 0.1f).rot(0, 0, ang[i]);
            f.box(0, -0.6f, -0.6f, ln[i], 1.2f, 1.2f, bone);
            f.box(ln[i] - 1.5f, -0.5f, -0.5f, 2f, 1f, 1f, tip);
            wr.kid(f);
        }
        for (int i = 0; i + 1 < fingers; i++) {
            skin(wr, ang[i] + 2, ang[i + 1] - 1, 6, ln[i] * 0.94f, ln[i + 1] * 0.94f, 0.22f, skin, i % 2 == 0 ? 1f : 0.88f);
        }
        // membrane hanging from the forearm down to the body
        skin(el, 66 + 22 - 14, 112 + 22, 6, 11f * size, 8f * size, 0.1f, skin, 0.82f);
        if (glow) wr.glow(false);
        return s;
    }

    private static Cosmetic wingsOf(String id, String en, String ar, int[] pal, Part left) {
        return wings(id, en, ar, pal, left);
    }

    static void register(List<Cosmetic> out) {
        out.add(wingsOf("angel", "Angel wings", "أجنحة ملاك", new int[]{0xFFFFFF, 0xDDE6FF, 0xFFD34D},
                featherWing(1.1f, 10, 9, 6, 0, 1, 2, 2, false, 2.0f, 15f)));
        out.add(wingsOf("archangel", "Archangel wings (legendary)", "أجنحة رئيس الملائكة (أسطورية)", new int[]{0xFFE27A, 0xFFB000, 0xFFF6C8},
                featherWing(1.3f, 11, 10, 7, 0, 1, 2, 1, true, 1.8f, 14f)));
        out.add(wingsOf("raven", "Raven wings", "أجنحة الغراب", new int[]{0x1B1B26, 0x34344A, 0x7A5CFF},
                featherWing(1.2f, 10, 9, 6, 0, 1, 2, 1, false, 2.2f, 16f)));
        out.add(wingsOf("phoenix", "Phoenix wings", "أجنحة العنقاء", new int[]{0xFF5A1F, 0xFFB000, 0xFFF06A},
                featherWing(1.25f, 11, 10, 7, 0, 1, 2, 1, true, 2.4f, 16f)));
        out.add(wingsOf("demon", "Demon wings", "أجنحة شيطان", new int[]{0x7A0F14, 0x2B0A0D, 0xFF3B30},
                membraneWing(1.0f, 4, 1, 0, 2, false, 2.2f, 15f)));
        out.add(wingsOf("dragon", "Dragon wings", "أجنحة تنين", new int[]{0x35C13A, 0x0F4D17, 0xC9FF5A},
                membraneWing(1.2f, 5, 1, 0, 2, false, 1.9f, 14f)));

        // ---- Fairy
        Part fairy = Part.at(1.5f, 2f, 2.4f).rot(0, -20, 0).anim(flap(7f, 16f));
        fairy.glow(true).alpha(0.55f);
        fairy.kid(ellipse(5.5f, -7.5f, 5.2f, 8.5f, 0, 0.4f, -28, 0));
        fairy.kid(ellipse(4.2f, 3.5f, 3.4f, 5.4f, 1, 0.4f, 22, 0.05f));
        Part veins = Part.at(1.5f, 2f, 2.4f);
        fairy.glow(true).alpha(0.9f);
        Part vein = Part.at(0, 0, 0.1f).rot(0, 0, -50);
        vein.box(0, -0.25f, -0.2f, 13, 0.5f, 0.4f, 2);
        fairy.kid(vein);
        out.add(wings("fairy", "Fairy wings", "أجنحة جنية", new int[]{0xA8E6FF, 0xE9B8FF, 0xFFFFFF}, fairy));

        // ---- Butterfly
        Part bf = Part.at(1.5f, 2f, 2.4f).rot(0, -22, 0).anim(flap(4.2f, 24f));
        bf.alpha(1f);
        bf.kid(ellipse(7f, -6.5f, 7f, 9f, 0, 0.5f, -30, 0));
        bf.kid(ellipse(5f, 5f, 4.4f, 6f, 1, 0.5f, 24, 0.05f));
        Part dots = Part.at(0, 0, -0.4f);
        dots.boxc(5.2f, -8.5f, -0.3f, 3, 3, 0.4f, 0xFFFFFF).boxc(9.5f, -4.5f, -0.3f, 2, 2, 0.4f, 0x201020)
                .boxc(5.5f, 5.5f, -0.3f, 2.4f, 2.4f, 0.4f, 0xFFFFFF);
        bf.kid(dots);
        out.add(wings("butterfly", "Butterfly wings", "أجنحة فراشة", new int[]{0xFF8A1F, 0xFFD23F, 0x3A1F6B}, bf));

        // ---- Cyber
        Part cy = Part.at(2f, 2f, 2.6f).rot(0, -22, 0).anim(flap(1.8f, 7f));
        cy.box(-2f, -1.5f, -0.5f, 4, 4, 2.4f, 1);
        float[] ln = {17, 14, 11, 8};
        for (int i = 0; i < 4; i++) {
            Part b = Part.at(1.5f, 0, 0.2f + 0.05f * i).rot(0, 0, -(12 + i * 20));
            b.box(0, -1.2f, -0.4f, ln[i], 2.4f, 0.8f, 0);
            b.glow(true).box(1, -0.3f, -0.55f, ln[i] - 2, 0.6f, 0.4f, 2);
            b.glow(false);
            cy.kid(b);
        }
        out.add(wings("cyber", "Cyber wings", "أجنحة سايبر", new int[]{0x2A2F3A, 0x4A5160, 0x2EF2FF}, cy));

        // ---- Crystal
        Part cr = Part.at(2f, 1.5f, 2.4f).rot(0, -28, 0).anim(flap(2f, 6f));
        cr.glow(true).alpha(0.85f);
        float[] cl = {15, 12, 10, 8, 6};
        for (int i = 0; i < 5; i++) {
            Part s = Part.at(0.5f, 0, 0.05f * i).rot(0, 0, -(10 + i * 17));
            s.box(0, -1.4f, -0.8f, cl[i], 2.8f, 1.6f, i % 2 == 0 ? 0 : 1);
            Part tip = Part.at(cl[i], 0, 0).rot(0, 0, 0);
            tip.box(0, -0.8f, -0.5f, 2.5f, 1.6f, 1.0f, 2);
            s.kid(tip);
            cr.kid(s);
        }
        out.add(wings("crystal", "Crystal wings", "أجنحة كريستال", new int[]{0x6FD3FF, 0x9B7BFF, 0xFFFFFF}, cr));
    }
}
