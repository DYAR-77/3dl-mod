package com.n3dl.cosmetics;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.Base64;
import java.util.function.Consumer;
import javax.imageio.ImageIO;

/** Gets a skin PNG from a direct link or from a Minecraft username and saves it in the outfits folder. */
public final class SkinFetch {
    private SkinFetch() {
    }

    private static HttpClient client() {
        return HttpClient.newBuilder().followRedirects(HttpClient.Redirect.ALWAYS).connectTimeout(Duration.ofSeconds(15)).build();
    }

    private static String get(HttpClient hc, String url) throws Exception {
        HttpResponse<String> r = hc.send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(20))
                .header("User-Agent", "Mozilla/5.0").GET().build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (r.statusCode() / 100 != 2) throw new IllegalStateException("http " + r.statusCode());
        return r.body();
    }

    /** done gets the saved file name, or null on failure. Runs on its own thread; done is called from that thread. */
    public static void fromUrl(String url, boolean slim, Consumer<String> done) {
        run(() -> download(client(), url, "skin_" + Long.toString(System.currentTimeMillis() % 100000), slim), done);
    }

    public static void fromName(String name, Consumer<String> done) {
        run(() -> {
            HttpClient hc = client();
            String n = name.trim().replaceAll("[^A-Za-z0-9_]", "");
            if (n.isEmpty()) return null;
            JsonObject prof = JsonParser.parseString(get(hc, "https://api.mojang.com/users/profiles/minecraft/" + n)).getAsJsonObject();
            String id = prof.get("id").getAsString();
            JsonObject full = JsonParser.parseString(get(hc, "https://sessionserver.mojang.com/session/minecraft/profile/" + id)).getAsJsonObject();
            String value = full.getAsJsonArray("properties").get(0).getAsJsonObject().get("value").getAsString();
            JsonObject tex = JsonParser.parseString(new String(Base64.getDecoder().decode(value), StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject skin = tex.getAsJsonObject("textures").getAsJsonObject("SKIN");
            boolean slim = skin.has("metadata") && skin.getAsJsonObject("metadata").has("model")
                    && "slim".equalsIgnoreCase(skin.getAsJsonObject("metadata").get("model").getAsString());
            return download(hc, skin.get("url").getAsString(), n, slim);
        }, done);
    }

    private interface Job {
        String run() throws Exception;
    }

    private static void run(Job j, Consumer<String> done) {
        Thread t = new Thread(() -> {
            String r = null;
            try {
                r = j.run();
            } catch (Throwable ignored) {
            }
            done.accept(r);
        }, "3DL ABO ZAHRA-SkinFetch");
        t.setDaemon(true);
        t.start();
    }

    private static String download(HttpClient hc, String url, String base, boolean slim) throws Exception {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return null;
        HttpResponse<InputStream> r = hc.send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(25))
                .header("User-Agent", "Mozilla/5.0").GET().build(), HttpResponse.BodyHandlers.ofInputStream());
        if (r.statusCode() / 100 != 2) return null;
        Path dir = CosmeticsManager.outfitsDir();
        Files.createDirectories(dir);
        String name = base.replaceAll("[^A-Za-z0-9_-]", "_") + (slim ? "_slim" : "") + ".png";
        Path tmp = dir.resolve(name + ".part");
        try (InputStream in = r.body()) {
            long n = Files.copy(in, tmp, StandardCopyOption.REPLACE_EXISTING);
            if (n > 4_000_000L) {
                Files.deleteIfExists(tmp);
                return null;
            }
        }
        java.awt.image.BufferedImage img = ImageIO.read(tmp.toFile());
        if (img == null || img.getWidth() < 64 || img.getHeight() < 32) {
            Files.deleteIfExists(tmp);
            return null;
        }
        Files.move(tmp, dir.resolve(name), StandardCopyOption.REPLACE_EXISTING);
        return name;
    }
}
