package com.n3dl.cosmetics;

import com.mojang.blaze3d.vertex.PoseStack;
import com.n3dl.net.SyncClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

/** Render layer added to player renderers. Draws cosmetics only for the local player. */
public class CosmeticLayer<S extends LivingEntityRenderState, M extends EntityModel<? super S>> extends RenderLayer<S, M> {
    public CosmeticLayer(RenderLayerParent<S, M> parent) {
        super(parent);
    }

    @Override
    public void submit(PoseStack poseStack, SubmitNodeCollector collector, int packedLight, S state, float yRot, float xRot) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || state.isInvisible) return;
        float partial = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        double px = mc.player.getX() + (mc.player.xOld - mc.player.getX()) * (1.0 - partial);
        double py = mc.player.getY() + (mc.player.yOld - mc.player.getY()) * (1.0 - partial);
        double pz = mc.player.getZ() + (mc.player.zOld - mc.player.getZ()) * (1.0 - partial);
        if (!(getParentModel() instanceof HumanoidModel<?> hm)) return;
        var pl = SyncClient.playerAt(state.x, state.y, state.z, partial);
        if (pl == null) return;
        com.n3dl.cosmetics.model.Phys ph = com.n3dl.cosmetics.model.Phys.of(pl.getId());
        ph.update(pl.getX(), pl.getY(), pl.getZ(), state.bodyRot, pl.onGround(), pl.isCrouching(), pl.isFallFlying());
        com.n3dl.cosmetics.model.Phys.cur = ph;
        if (pl == mc.player) {
            CosmeticsRender.lastModel = hm;
            if (!com.n3dl.core.Config.get().cosEnabled) return;
            CosmeticsRender.renderAll(poseStack, collector, hm, packedLight, state.ageInTicks, state.bodyRot, px, py, pz,
                    state.walkAnimationSpeed, partial, CosmeticsRender.localSlots(), true);
        } else {
            SyncClient.Remote r = SyncClient.remote(pl.getUUID());
            if (r == null || !r.enabled) return;
            CosmeticsRender.renderAll(poseStack, collector, hm, packedLight, state.ageInTicks, state.bodyRot, state.x, state.y, state.z,
                    state.walkAnimationSpeed, partial, r.slots, false);
        }
    }
}
