package com.n3dl.cosmetics.model;

import java.util.ArrayList;
import java.util.List;

/**
 * A node of a cosmetic: a pivot with a base pose, some boxes, child nodes and an optional animation.
 * Axes in model pixels: +x = the player's left, +y = DOWN, +z = BEHIND the player.
 */
public final class Part {
    public float x, y, z, rx, ry, rz, scale = 1f;
    public final List<Box> boxes = new ArrayList<>();
    public final List<Part> kids = new ArrayList<>();
    public Anim anim;
    public boolean mirrored;
    private boolean glowOn;
    private float alphaVal = 1f;
    private float toneVal = 1f;
    /** Physics sway: strength (+ hangs down, - stands up) and how many seconds it lags behind the wearer. */
    public float swayK, swayLag;
    /** Sideways sway turns the node around Y (for parts that point backward, like tails) instead of Z. */
    public boolean swayYaw;

    public static Part at(float x, float y, float z) {
        Part p = new Part();
        p.x = x;
        p.y = y;
        p.z = z;
        return p;
    }

    public Part rot(float rx, float ry, float rz) {
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        return this;
    }

    public Part scale(float s) {
        this.scale = s;
        return this;
    }

    /** Boxes added after this call glow (full brightness). */
    public Part glow(boolean on) {
        glowOn = on;
        return this;
    }

    /** Boxes added after this call use this opacity (0..1). */
    public Part alpha(float a) {
        alphaVal = a;
        return this;
    }

    /** Boxes added after this call are multiplied by this brightness (use it for shading / gradients). */
    public Part tone(float t) {
        toneVal = t;
        return this;
    }

    /** Make this node follow the wearer's motion with a delay (tails, scarves, ears, hat tips). */
    public Part swayYaw() {
        swayYaw = true;
        return this;
    }

    public Part sway(float strength, float lagSeconds) {
        swayK = strength;
        swayLag = lagSeconds;
        return this;
    }

    /** Palette-coloured box: role 0 = main, 1 = second, 2 = accent. */
    public Part box(float x, float y, float z, float w, float h, float d, int role) {
        boxes.add(new Box(x, y, z, w, h, d, role, 0xFFFFFF, glowOn, alphaVal, toneVal));
        return this;
    }

    /** Fixed-colour box. */
    public Part boxc(float x, float y, float z, float w, float h, float d, int rgb) {
        boxes.add(new Box(x, y, z, w, h, d, -1, rgb, glowOn, alphaVal, toneVal));
        return this;
    }

    public Part kid(Part k) {
        kids.add(k);
        return this;
    }

    public Part anim(Anim a) {
        this.anim = a;
        return this;
    }

    /** Copy of this node reflected left<->right (animation is mirrored too). */
    public Part mirror() {
        Part m = new Part();
        m.x = -x;
        m.y = y;
        m.z = z;
        m.rx = rx;
        m.ry = -ry;
        m.rz = -rz;
        m.scale = scale;
        m.anim = anim;
        m.swayK = swayK;
        m.swayLag = swayLag;
        m.swayYaw = swayYaw;
        m.mirrored = !mirrored;
        for (Box b : boxes) m.boxes.add(b.mirrored());
        for (Part k : kids) m.kids.add(k.mirror());
        return m;
    }

    /** This node plus its mirror image, wrapped in a neutral group. */
    public static Part pair(Part left) {
        Part g = new Part();
        g.kids.add(left);
        g.kids.add(left.mirror());
        return g;
    }

    public static Part group() {
        return new Part();
    }

    public int boxCount() {
        int n = boxes.size();
        for (Part k : kids) n += k.boxCount();
        return n;
    }
}
