package com.n3dl.cosmetics.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Motion of one wearer, used by the cosmetics so that wings, tails and hats react to walking, jumping, falling and
 * turning. Updated once per frame from the entity position.
 */
public final class Phys {
    /** The wearer being drawn right now. */
    public static Phys cur = new Phys();

    /** 0..1 horizontal speed, airborne, falling fast, sneaking. */
    public float speed, air, fall, sneak;
    /** Smoothed velocities in blocks per second: forward, to the player's left, up. */
    public float vf, vs, vy;
    /** Turning speed (degrees per second). */
    public float yawVel;
    /** Where the pet looks: degrees relative to its heading (set by the pet code). */
    public float look;

    private static final int N = 96;
    private final float[] ht = new float[N], hf = new float[N], hs = new float[N], hu = new float[N];
    private int hi, hn;
    private long lastNs;
    private double lx, ly, lz;
    private float lyaw;
    private boolean has;
    public long touched;

    private static final Map<Integer, Phys> MAP = new HashMap<>();

    public static Phys of(int id) {
        Phys p = MAP.get(id);
        if (p == null) {
            if (MAP.size() > 48) {
                long now = System.nanoTime();
                MAP.values().removeIf(x -> now - x.touched > 5_000_000_000L);
            }
            p = new Phys();
            MAP.put(id, p);
        }
        p.touched = System.nanoTime();
        return p;
    }

    public void update(double x, double y, double z, float bodyYaw, boolean onGround, boolean sneaking, boolean gliding) {
        long now = System.nanoTime();
        if (!has) {
            has = true;
            lastNs = now;
            lx = x;
            ly = y;
            lz = z;
            lyaw = bodyYaw;
            return;
        }
        float dt = (now - lastNs) / 1e9f;
        if (dt < 0.0008f) return;
        lastNs = now;
        dt = Math.min(dt, 0.1f);
        float vx = (float) ((x - lx) / dt), vz = (float) ((z - lz) / dt), vyy = (float) ((y - ly) / dt);
        lx = x;
        ly = y;
        lz = z;
        if (Math.abs(vx) > 60 || Math.abs(vz) > 60 || Math.abs(vyy) > 80) { // teleport
            vx = vz = vyy = 0;
        }
        double yaw = Math.toRadians(bodyYaw);
        float left = (float) (vx * Math.cos(yaw) + vz * Math.sin(yaw));
        float fwd = (float) (-vx * Math.sin(yaw) + vz * Math.cos(yaw));
        float a = Math.min(1f, dt * 14f);
        vf += (fwd - vf) * a;
        vs += (left - vs) * a;
        vy += (vyy - vy) * a;
        float sp = (float) Math.min(1.0, Math.sqrt(vf * vf + vs * vs) / 5.5);
        speed += (sp - speed) * Math.min(1f, dt * 10f);
        air += ((onGround ? 0f : 1f) - air) * Math.min(1f, dt * 9f);
        float fl = !onGround && (vy < -3.5f || gliding) ? 1f : 0f;
        fall += (fl - fall) * Math.min(1f, dt * 8f);
        sneak += ((sneaking ? 1f : 0f) - sneak) * Math.min(1f, dt * 10f);
        float dy = bodyYaw - lyaw;
        while (dy > 180) dy -= 360;
        while (dy < -180) dy += 360;
        lyaw = bodyYaw;
        yawVel += (dy / dt - yawVel) * Math.min(1f, dt * 10f);
        float t = now / 1e9f;
        hi = (hi + 1) % N;
        ht[hi] = t;
        hf[hi] = vf;
        hs[hi] = vs;
        hu[hi] = vy;
        if (hn < N) hn++;
    }

    private float lag(float[] arr, float lagSec, float fallback) {
        if (hn == 0 || lagSec <= 0.001f) return fallback;
        float target = System.nanoTime() / 1e9f - lagSec;
        int i = hi;
        for (int n = 0; n < hn; n++) {
            if (ht[i] <= target) return arr[i];
            i = (i - 1 + N) % N;
        }
        return arr[(hi + 1) % N == hi ? hi : (hi - hn + 1 + N) % N];
    }

    public float vfLag(float s) {
        return lag(hf, s, vf);
    }

    public float vsLag(float s) {
        return lag(hs, s, vs);
    }

    public float vuLag(float s) {
        return lag(hu, s, vy);
    }
}
