package com.n3dl.cosmetics.model;

/** One selectable 3D cosmetic design. */
public final class Cosmetic {
    public enum Slot {WINGS, HEAD, BODY, PET, COMPANION, AURA}

    /** Where the design is attached. */
    public enum Anchor {HEAD, BODY, PET, FLOAT, AURA}

    public final String id, en, ar;
    public final Slot slot;
    public final Anchor anchor;
    /** Default palette (RGB): main, second, accent. */
    public final int[] pal;
    public final Part root;

    public Cosmetic(String id, String en, String ar, Slot slot, Anchor anchor, int[] pal, Part root) {
        this.id = id;
        this.en = en;
        this.ar = ar;
        this.slot = slot;
        this.anchor = anchor;
        this.pal = pal;
        this.root = root;
    }
}
