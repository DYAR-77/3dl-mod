package com.n3dl.combat;

import com.mojang.blaze3d.platform.InputConstants;
import com.n3dl.core.Config;
import com.n3dl.core.Tr;
import java.util.Random;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import org.lwjgl.glfw.GLFW;

/** Attacks by itself when the crosshair is on a valid target. Client side only. */
public final class TriggerBot {
    private TriggerBot() {
    }

    private static final Random R = new Random();
    private static boolean keyWas;
    private static long nextMs;
    private static int focusId = -1;

    private static boolean keyDown(long win, int k) {
        if (k <= 0 || win == 0) return false;
        return k >= 1000 ? GLFW.glfwGetMouseButton(win, k - 1000) == GLFW.GLFW_PRESS
                : GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
    }

    private static boolean valid(Minecraft mc, Config c, Entity e) {
        if (e == null || e == mc.player || !e.isAlive() || !e.isAttackable()) return false;
        if (e instanceof Player p) {
            if (!c.tbPlayers || p.isSpectator()) return false;
            if (c.tbAntiBot && (mc.getConnection() == null || mc.getConnection().getPlayerInfo(p.getUUID()) == null)) return false;
            if (c.tbSkipBlocking && p.isBlocking()) return false;
            return true;
        }
        if (e instanceof EndCrystal) return c.tbCrystal;
        if (e instanceof ArmorStand) return c.tbStands;
        if (e.getType() == EntityType.VILLAGER || e.getType() == EntityType.WANDERING_TRADER) return c.tbVillagers;
        if (e instanceof Enemy) return c.tbMobs;
        if (e instanceof Animal) return c.tbAnimals;
        return c.tbOthers && e instanceof LivingEntity;
    }

    private static boolean weapon(ItemStack s) {
        if (s.isEmpty()) return false;
        if (s.is(ItemTags.SWORDS) || s.is(ItemTags.AXES) || s.is(Items.MACE) || s.is(Items.TRIDENT)) return true;
        return BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().endsWith("_spear");
    }

    private static boolean canCrit(Minecraft mc) {
        var p = mc.player;
        return p.fallDistance > 0f && !p.onGround() && !p.onClimbable() && !p.isInWater()
                && !p.hasEffect(MobEffects.BLINDNESS) && !p.isPassenger();
    }

    public static void tick(Minecraft mc) {
        Config c = Config.get();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        long win = GLFW.glfwGetCurrentContext();
        boolean down = c.enabled && mc.screen == null && keyDown(win, c.tbKey);
        if (down && !keyWas) {
            c.tbOn = !c.tbOn;
            Config.save();
            mc.player.displayClientMessage(Component.literal("[3DL ABO ZAHRA] TriggerBot " + (c.tbOn ? "ON" : "OFF")), true);
        }
        keyWas = down;
        if (!c.enabled || !c.tbOn) {
            focusId = -1;
            return;
        }
        if (mc.screen != null && !c.tbInGui) return;
        if (c.tbPauseUse && mc.player.isUsingItem()) return;
        if (c.tbOnlyWeapon && !weapon(mc.player.getMainHandItem())) return;
        if (!(mc.hitResult instanceof EntityHitResult h)) return;
        Entity e = h.getEntity();
        if (!valid(mc, c, e)) return;
        if (c.tbFocus) {
            if (focusId >= 0 && focusId != e.getId()) {
                Entity f = mc.level.getEntity(focusId);
                if (f != null && f.isAlive()) return;
            }
            focusId = e.getId();
        }
        if (c.tbReach > 0f && mc.player.distanceTo(e) > c.tbReach) return;
        long now = System.currentTimeMillis();
        boolean crit = canCrit(mc);
        if (c.tbHitMode == 1 && !crit) return;
        if (c.tbMode == 0) {
            if (mc.player.getAttackStrengthScale(0.5f) < 0.95f) return;
        } else {
            if (now < nextMs) return;
            nextMs = now + (long) (1000f / c.tbCps * (0.8f + R.nextFloat() * 0.4f));
        }
        if (c.tbMiss > 0f && R.nextFloat() * 100f < c.tbMiss) {
            if (c.tbMode == 0) nextMs = now;
            return;
        }
        hit(mc, c, e);
        if (c.tbMode == 1 && c.tbDouble > 0f && R.nextFloat() * 100f < c.tbDouble) hit(mc, c, e);
    }

    private static void hit(Minecraft mc, Config c, Entity e) {
        if (c.tbSimulate) {
            InputConstants.Key k = InputConstants.getKey(mc.options.keyAttack.saveString());
            if (k != InputConstants.UNKNOWN) KeyMapping.click(k);
        } else {
            Combat.beforeAttack(mc);
            mc.gameMode.attack(mc.player, e);
            mc.player.swing(InteractionHand.MAIN_HAND);
        }
    }
}
