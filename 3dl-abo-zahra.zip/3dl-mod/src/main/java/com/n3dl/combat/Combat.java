package com.n3dl.combat;

import com.mojang.blaze3d.platform.InputConstants;
import com.n3dl.core.Config;
import com.n3dl.core.Tr;
import java.util.function.Predicate;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import org.lwjgl.glfw.GLFW;

/** Hotbar helpers for PvP: mace swap, spear quick swap, wind-charge launch. All client side. */
public final class Combat {
    private Combat() {
    }

    // mace swap
    private static int maceBack = -1, maceIdle, maceTimer;
    // spear
    private static int spearBack = -1, spearTimer;
    // wind launch
    private static int wStage, wTick, wBack = -1, wSlot = -1, wPearl = -1;
    private static float wPitch;
    private static boolean jumpHeld;
    private static boolean spearWas, windWas;
    private static int wDone, wWait, jumpTick, spearJumpT, wTotal;

    // ------------------------------------------------------------------ helpers

    private static boolean isMace(ItemStack s) {
        return s.is(Items.MACE);
    }

    private static boolean isWind(ItemStack s) {
        return s.is(Items.WIND_CHARGE);
    }

    private static boolean isSpear(ItemStack s) {
        return !s.isEmpty() && BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().endsWith("_spear");
    }

    private static int find(Minecraft mc, Predicate<ItemStack> p) {
        for (int i = 0; i < 9; i++) if (p.test(mc.player.getInventory().getItem(i))) return i;
        return -1;
    }

    private static int sel(Minecraft mc) {
        return mc.player.getInventory().getSelectedSlot();
    }

    private static void select(Minecraft mc, int slot) {
        if (slot >= 0 && slot < 9) mc.player.getInventory().setSelectedSlot(slot);
    }

    private static void press(KeyMapping km) {
        InputConstants.Key k = InputConstants.getKey(km.saveString());
        if (k != InputConstants.UNKNOWN) KeyMapping.click(k);
    }

    private static void msg(Minecraft mc, String en, String ar) {
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("[3DL ABO ZAHRA] " + Tr.t(en, ar)), true);
    }

    private static boolean keyDown(long win, int k) {
        if (k <= 0 || win == 0) return false;
        return k >= 1000 ? GLFW.glfwGetMouseButton(win, k - 1000) == GLFW.GLFW_PRESS
                : GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
    }

    private static boolean busy() {
        return spearBack >= 0 || wStage != 0;
    }

    // ------------------------------------------------------------------ mace swap

    /** Called right before the game starts an attack (mixin) and at the start of each tick while attack is held. */
    public static void beforeAttack(Minecraft mc) {
        Config c = Config.get();
        if (!c.enabled || !c.maceSwap || mc.player == null || mc.screen != null || busy()) return;
        if (!(mc.hitResult instanceof EntityHitResult h)) return;
        if (c.maceSwapPlayersOnly && !(h.getEntity() instanceof Player)) return;
        int m = find(mc, Combat::isMace);
        if (m < 0) return;
        int cur = sel(mc);
        maceIdle = 0;
        if (cur == m) return;
        if (maceBack < 0) maceBack = cur;
        select(mc, m);
    }

    public static void startTick(Minecraft mc) {
        // With "go back" on, the swap happens only inside the attack itself (mixin) so it can be undone instantly.
        if (mc.player != null && !Config.get().maceSwapReturn && mc.options.keyAttack.isDown()) beforeAttack(mc);
    }

    /**
     * Called the moment the game finished starting an attack (mixin). The attack packet was already sent with the mace
     * in hand, so we switch straight back: the slot changes and returns inside the same tick, which is never drawn.
     */
    public static void afterAttack(Minecraft mc) {
        if (maceBack < 0 || mc.player == null || !Config.get().maceSwapReturn) return;
        int n = Config.get().maceReturnTicks;
        if (n <= 0) {
            select(mc, maceBack);
            maceBack = -1;
        } else {
            maceTimer = n + 1; // counted down at the end of every tick, so it returns n ticks after the hit
        }
    }

    private static void stepMace(Minecraft mc) {
        if (maceBack < 0) return;
        if (!Config.get().maceSwapReturn) {
            maceBack = -1;
            return;
        }
        if (maceTimer > 0 && --maceTimer > 0) return;
        select(mc, maceBack); // the wait is over (or there was no attack): go back right now
        maceBack = -1;
        maceTimer = 0;
    }

    // ------------------------------------------------------------------ main tick

    public static void tick(Minecraft mc) {
        Config c = Config.get();
        if (mc.player == null || mc.level == null) {
            reset();
            return;
        }
        long win = GLFW.glfwGetCurrentContext();
        boolean ok = c.enabled && mc.screen == null;
        boolean sp = ok && keyDown(win, c.spearKey);
        boolean wi = ok && keyDown(win, c.windKey);
        if (sp && !spearWas) startSpear(mc);
        if (wi && !windWas) startWind(mc);
        spearWas = sp;
        windWas = wi;
        stepSpear(mc);
        stepWind(mc);
        stepMace(mc);
        TriggerBot.tick(mc);
    }

    private static void reset() {
        maceBack = spearBack = wBack = -1;
        maceTimer = 0;
        wStage = 0;
        jumpHeld = false;
    }

    // ------------------------------------------------------------------ spear

    private static void startSpear(Minecraft mc) {
        Config c = Config.get();
        if (wStage != 0) return;
        int s = find(mc, Combat::isSpear);
        if (s < 0) {
            msg(mc, "No spear in your hotbar", "ما فيه رمح (سبير) في الهوت بار");
            return;
        }
        if (spearBack < 0) spearBack = sel(mc);
        if (sel(mc) != s) select(mc, s);
        press(mc.options.keyAttack);
        if (c.spearJump) {
            mc.options.keyJump.setDown(true);
            spearJumpT = 3;
        }
        spearTimer = Math.max(2, c.spearReturnTicks);
    }

    private static void stepSpear(Minecraft mc) {
        if (spearJumpT > 0 && --spearJumpT == 0 && !jumpHeld) mc.options.keyJump.setDown(false);
        if (spearBack < 0) return;
        if (--spearTimer <= 0) {
            select(mc, spearBack);
            spearBack = -1;
        }
    }

    // ------------------------------------------------------------------ wind charge + ender pearl combo
    // Press the key: look down + wind charge, jump right after, look at the sky + ender pearl,
    // then one more wind charge (the game makes wind charges wait about half a second).

    private static boolean isPearl(ItemStack s) {
        return s.is(Items.ENDER_PEARL);
    }

    private static void startWind(Minecraft mc) {
        if (wStage != 0 || spearBack >= 0) return;
        int w = find(mc, Combat::isWind);
        int pe = find(mc, Combat::isPearl);
        if (w < 0 || pe < 0) {
            msg(mc, "Needs a wind charge and an ender pearl in the hotbar", "تحتاج ويند تشارج وإندر بيرل في الهوت بار");
            return;
        }
        wBack = sel(mc);
        wSlot = w;
        wPearl = pe;
        wPitch = mc.player.getXRot();
        wStage = 1;
        wTick = 0;
        wDone = 0;
        wWait = 0;
        wTotal = 0;
    }

    /** Uses the item in the selected slot directly (no key press), aiming already applied. */
    private static void use(Minecraft mc, int slot, float pitch) {
        select(mc, slot);
        mc.player.setXRot(pitch);
        if (mc.gameMode != null) mc.gameMode.useItem(mc.player, net.minecraft.world.InteractionHand.MAIN_HAND);
        mc.player.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
    }

    private static boolean cooling(Minecraft mc, int slot) {
        try {
            return mc.player.getCooldowns().isOnCooldown(mc.player.getInventory().getItem(slot));
        } catch (Throwable t) {
            return false;
        }
    }

    private static void finish(Minecraft mc) {
        Config c = Config.get();
        if (jumpHeld) mc.options.keyJump.setDown(false);
        jumpHeld = false;
        if (c.windRestoreView) mc.player.setXRot(wPitch);
        if (c.windReturn && wBack >= 0) select(mc, wBack);
        wStage = 0;
        wBack = -1;
    }

    /** True while the wind combo runs: the mouse / touch look is frozen so the camera cannot be moved. */
    public static boolean viewLocked() {
        return wStage != 0;
    }

    /**
     * Fixed sequence, no user timings. Every step waits for the game's own item cooldowns, so it never misfires:
     * tick 0 wind charge down, tick 1 jump, tick 2 ender pearl up, then the last wind charge the moment the
     * wind charge cooldown is over. The camera is frozen until it is finished.
     */
    private static void stepWind(Minecraft mc) {
        if (wStage == 0) return;
        Config c = Config.get();
        if (mc.player.isDeadOrDying() || mc.screen != null || wTotal++ > 80) {
            if (jumpHeld) mc.options.keyJump.setDown(false);
            reset();
            return;
        }
        int t = wTick++;
        if (jumpHeld && t >= jumpTick + 3) {
            mc.options.keyJump.setDown(false);
            jumpHeld = false;
        }
        if (wDone == 0) { // first wind charge, down (waits for its cooldown)
            if (cooling(mc, wSlot)) {
                wTick = 0;
                return;
            }
            use(mc, wSlot, 90f);
            wDone = 1;
            wTick = 1;
            return;
        }
        if (wDone == 1) { // jump right after (waits until we touch something, max 6 ticks)
            if (mc.player.onGround() || t > 6) {
                mc.options.keyJump.setDown(true);
                jumpHeld = true;
                jumpTick = t;
                wDone = 2;
            }
            return;
        }
        if (wDone == 2 && t > jumpTick) { // ender pearl, up
            if (cooling(mc, wPearl)) {
                finish(mc);
                msg(mc, "Ender pearl is on cooldown", "الإندر بيرل في فترة انتظار");
                return;
            }
            use(mc, wPearl, -90f);
            wDone = 3;
            return;
        }
        if (wDone == 3) { // last wind charge: exactly when the wind charge cooldown ends
            if (cooling(mc, wSlot)) return;
            float pit = c.windFinalDir == 0 ? 90f : c.windFinalDir == 1 ? -90f : wPitch;
            use(mc, wSlot, pit);
            wDone = 4;
            wTick = 0;
            return;
        }
        if (wDone == 4 && t >= 2) finish(mc);
    }
}
