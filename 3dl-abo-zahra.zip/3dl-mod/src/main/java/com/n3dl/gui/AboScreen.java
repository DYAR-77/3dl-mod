package com.n3dl.gui;

import com.mojang.blaze3d.platform.InputConstants;
import com.n3dl.AboClient;
import com.n3dl.audio.SoundPlayer;
import com.n3dl.core.Actions;
import com.n3dl.core.Config;
import com.n3dl.core.FilePicker;
import com.n3dl.cosmetics.CosmeticsRender;
import com.n3dl.cosmetics.model.Cosmetic;
import com.n3dl.cosmetics.model.Designs;
import com.n3dl.emote.EmoteManager;
import com.n3dl.emote.Emotes;
import com.n3dl.core.Theme;
import com.n3dl.core.Tr;
import com.n3dl.cosmetics.CosmeticsManager;
import com.n3dl.cosmetics.LookPacks;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * The 3DL ABO ZAHRA menu. Everything is drawn by hand so it can be fully themed, scaled, moved and mirrored for Arabic (RTL).
 * Widget coordinates are relative to the top-left of the scrolling content area.
 */
public class AboScreen extends Screen {
    private static int lastPage = 0;

    /** Opens the menu on the Cape & Looks / Cosmetics page (used by the main menu button). */
    public static void openCosmetics() {
        lastPage = 4;
        Minecraft.getInstance().setScreen(new AboScreen());
    }

    private final Config c = Config.get();
    private final Minecraft mc = Minecraft.getInstance();

    private int page = lastPage;
    private int scroll = 0, contentH = 0;
    private final List<W> ws = new ArrayList<>();
    private W focus, dragW;
    private KeyBtn capturing;

    // panel geometry (logical units; the whole UI is multiplied by panelScale)
    private float ps = 1f;
    private int lw, lh;
    private int px, py, pw, ph;
    private int hh, nw;
    private int bx, by, bw, bh;
    private int cwid;                // width of the content column
    private String builtKey = "";
    private boolean draggingPanel, resizing, draggingBar;
    private int dragDX, dragDY;
    private int cy;                  // layout cursor while building

    // small page-local state
    private String newPlayer = "";
    private int quickSel = 0;
    private Config.BindEntry capBind;
    private int capIdx = -1;

    private Cosmetic.Slot cosSlot = Cosmetic.Slot.WINGS;
    private int bundleSel = 0;
    private String status = "";
    private boolean dropOutfit;
    private Config.SoundCfg dropSound;

    private static final int PAD = 6, GAP = 4, SB = 6;

    public AboScreen() {
        super(Component.literal("3DL ABO ZAHRA"));
    }

    // ================================================================== helpers

    private boolean rtl() {
        return c.ar();
    }

    private int fh() {
        return Math.round(9 * c.textScale);
    }

    private int rh() {
        return fh() + 9;
    }

    private int tw(String s) {
        return Math.round(font.width(Component.literal(s)) * c.textScale);
    }

    private static int opaque(int rgb) {
        return 0xFF000000 | (rgb & 0xFFFFFF);
    }

    private int cText() {
        return opaque(c.cText);
    }

    private int cAcc() {
        return opaque(c.cAccent);
    }

    private int cBtn(boolean hover) {
        return opaque(hover ? Theme.mix(c.cButton, 0xFFFFFF, 0.14f) : c.cButton);
    }

    private static int onColor(int rgb) {
        double l = 0.299 * ((rgb >> 16) & 255) + 0.587 * ((rgb >> 8) & 255) + 0.114 * (rgb & 255);
        return l > 150 ? 0xFF101010 : 0xFFFFFFFF;
    }

    private void rfill(GuiGraphics g, int x, int y, int w, int h, int col) {
        if (w <= 0 || h <= 0) return;
        if (!c.round || w < 8 || h < 8) {
            g.fill(x, y, x + w, y + h, col);
            return;
        }
        g.fill(x + 2, y, x + w - 2, y + h, col);
        g.fill(x, y + 2, x + w, y + h - 2, col);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, col);
    }

    /** Fills a rectangle with the menu gradient between two colours (or a solid colour when gradients are off). */
    private void grad(GuiGraphics g, int x, int y, int w, int h, int rgb1, int rgb2, float alpha) {
        if (w <= 0 || h <= 0) return;
        if (!c.gradient) {
            rfill(g, x, y, w, h, Theme.argb(rgb1, alpha));
            return;
        }
        int a = rgb1, b = rgb2;
        if (c.gradAnim) {
            float ph = 0.5f + 0.5f * (float) Math.sin(System.nanoTime() / 1.6e9);
            a = Theme.mix(rgb1, rgb2, ph);
            b = Theme.mix(rgb2, rgb1, ph);
        }
        boolean horiz = c.gradDir == 1;
        int len = horiz ? w : h;
        int n = Math.max(1, Math.min(28, len / 2));
        for (int i = 0; i < n; i++) {
            int s0 = i * len / n, s1 = (i + 1) * len / n;
            if (s1 <= s0) continue;
            int col = Theme.argb(Theme.mix(a, b, (i + 0.5f) / n), alpha);
            int inset = c.round && w >= 8 && h >= 8 && (i == 0 || i == n - 1) ? 2 : 0;
            if (horiz) {
                int yy = y + (c.round && w >= 8 && h >= 8 && (i == 0 || i == n - 1) ? 1 : 0);
                g.fill(x + s0, yy, x + s1, y + h - (yy - y), col);
            } else {
                g.fill(x + inset, y + s0, x + w - inset, y + s1, col);
            }
        }
        if (c.round && w >= 8 && h >= 8) {
            // fill the rows trimmed at the rounded corners
            if (horiz) {
                g.fill(x, y + 2, x + 1, y + h - 2, Theme.argb(a, alpha));
                g.fill(x + w - 1, y + 2, x + w, y + h - 2, Theme.argb(b, alpha));
            }
        }
    }

    private void txt(GuiGraphics g, String s, int x, int y, int col) {
        var p = g.pose();
        p.pushMatrix();
        p.translate(x, y);
        p.scale(c.textScale, c.textScale);
        g.drawString(font, Component.literal(s), 0, 0, col, false);
        p.popMatrix();
    }

    /** Text aligned to the start side of the rectangle (left for English, right for Arabic). */
    private void txtStart(GuiGraphics g, String s, int x, int w, int y, int col) {
        int t = tw(s);
        txt(g, s, rtl() ? x + w - t : x, y, col);
    }

    private void txtCenter(GuiGraphics g, String s, int x, int w, int y, int col) {
        txt(g, s, x + (w - tw(s)) / 2, y, col);
    }

    private static String t(String en, String ar) {
        return Tr.t(en, ar);
    }

    private static String pct(float v) {
        return Math.round(v * 100) + "%";
    }

    private String keyName(int code) {
        if (code == -1) return t("None", "بدون");
        if (code >= 1000) return t("Mouse ", "ماوس ") + (code - 1000 + 1);
        try {
            return InputConstants.Type.KEYSYM.getOrCreate(code).getDisplayName().getString();
        } catch (Throwable e) {
            return "#" + code;
        }
    }

    private void setMapping(KeyMapping km, int code) {
        InputConstants.Key k = code == -1 ? InputConstants.UNKNOWN
                : code >= 1000 ? InputConstants.Type.MOUSE.getOrCreate(code - 1000)
                : InputConstants.Type.KEYSYM.getOrCreate(code);
        km.setKey(k);
        KeyMapping.resetMapping();
        mc.options.save();
    }

    public static void openDir(Path dir) {
        try {
            String p = dir.toString();
            String os = System.getProperty("os.name", "").toLowerCase();
            if (os.contains("win")) new ProcessBuilder("explorer", p).start();
            else if (os.contains("mac")) new ProcessBuilder("open", p).start();
            else new ProcessBuilder("xdg-open", p).start();
        } catch (Throwable ignored) {
        }
    }

    // ================================================================== widgets

    private abstract class W {
        int x, y, w, h;

        boolean in(int mx, int my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }

        abstract void draw(GuiGraphics g, int mx, int my);

        boolean click(int mx, int my, int b) {
            return false;
        }

        void drag(int mx, int my) {
        }

        void release() {
        }

        boolean key(int k, int mods) {
            return false;
        }

        boolean chr(String s) {
            return false;
        }

        void place() {
        }

        /** Widget under the pointer (containers delegate to their children). */
        W under(int mx, int my) {
            return in(mx, my) ? this : null;
        }

        /** Mouse wheel over this widget: returns true if it used it. */
        boolean wheel(int dir) {
            return false;
        }
    }

    private class Sec extends W {
        final String title;

        Sec(String title) {
            this.title = title;
            h = rh() + 4;
        }

        void draw(GuiGraphics g, int mx, int my) {
            txtStart(g, title, x, w, y + 2, cAcc());
            g.fill(x, y + h - 2, x + w, y + h - 1, Theme.argb(c.cAccent, 0.5f));
        }
    }

    private class Note extends W {
        final List<String> lines = new ArrayList<>();
        final String text;

        Note(String text) {
            this.text = text;
        }

        void wrap(int width) {
            lines.clear();
            StringBuilder cur = new StringBuilder();
            for (String word : text.split(" ")) {
                String tryLine = cur.length() == 0 ? word : cur + " " + word;
                if (tw(tryLine) > width && cur.length() > 0) {
                    lines.add(cur.toString());
                    cur = new StringBuilder(word);
                } else {
                    cur = new StringBuilder(tryLine);
                }
            }
            if (cur.length() > 0) lines.add(cur.toString());
            h = lines.size() * (fh() + 2) + 2;
        }

        void draw(GuiGraphics g, int mx, int my) {
            int col = Theme.argb(c.cText, 0.65f);
            for (int i = 0; i < lines.size(); i++) txtStart(g, lines.get(i), x, w, y + 1 + i * (fh() + 2), col);
        }
    }

    private class Lbl extends W {
        final Supplier<String> s;

        Lbl(Supplier<String> s) {
            this.s = s;
            h = rh();
        }

        void draw(GuiGraphics g, int mx, int my) {
            txtStart(g, s.get(), x + 2, w - 4, y + (h - fh()) / 2, cText());
        }
    }

    private class Btn extends W {
        final Supplier<String> label;
        final Runnable act;
        boolean accent;
        BooleanSupplier hl;

        Btn hl(BooleanSupplier b) {
            hl = b;
            return this;
        }

        Btn(Supplier<String> label, Runnable act) {
            this.label = label;
            this.act = act;
            h = rh();
        }

        Btn accent() {
            accent = true;
            return this;
        }

        Btn width(int wd) {
            w = wd;
            return this;
        }

        void draw(GuiGraphics g, int mx, int my) {
            boolean hv = in(mx, my);
            boolean ac = accent || (hl != null && hl.getAsBoolean());
            if (ac) grad(g, x, y, w, h, hv ? Theme.mix(c.cAccent, 0xFFFFFF, 0.18f) : c.cAccent,
                    hv ? Theme.mix(c.cAccent2, 0xFFFFFF, 0.18f) : c.cAccent2, 1f);
            else grad(g, x, y, w, h, hv ? Theme.mix(c.cButton, 0xFFFFFF, 0.14f) : c.cButton,
                    hv ? Theme.mix(c.cButton2, 0xFFFFFF, 0.14f) : c.cButton2, 1f);
            String lb = label.get();
            while (tw(lb) > w - 6 && lb.length() > 3) lb = lb.substring(0, lb.length() - 2);
            txtCenter(g, lb, x, w, y + (h - fh()) / 2, ac ? onColor(c.cAccent) : cText());
        }

        boolean click(int mx, int my, int b) {
            if (in(mx, my) && b == 0) {
                act.run();
                return true;
            }
            return false;
        }
    }

    private class Toggle extends W {
        final BooleanSupplier get;
        final Consumer<Boolean> set;

        Toggle(BooleanSupplier get, Consumer<Boolean> set) {
            this.get = get;
            this.set = set;
            h = rh();
        }

        void draw(GuiGraphics g, int mx, int my) {
            boolean on = get.getAsBoolean();
            boolean hv = in(mx, my);
            int base = on ? c.cAccent : c.cButton;
            rfill(g, x, y, w, h, opaque(hv ? Theme.mix(base, 0xFFFFFF, 0.14f) : base));
            int kw = Math.max(8, h - 6);
            int kx = on ? x + w - kw - 3 : x + 3;
            rfill(g, kx, y + 3, kw, h - 6, opaque(on ? onColor(c.cAccent) == 0xFFFFFFFF ? 0xFFFFFF : 0x101010 : 0x8A8A8A));
            String s = on ? t("ON", "مفعّل") : t("OFF", "متوقف");
            int tx = on ? x + 6 : x + w - tw(s) - 6;
            txt(g, s, tx, y + (h - fh()) / 2, on ? onColor(c.cAccent) : cText());
        }

        boolean click(int mx, int my, int b) {
            if (in(mx, my) && b == 0) {
                set.accept(!get.getAsBoolean());
                return true;
            }
            return false;
        }
    }

    private class Slider extends W {
        final float min, max, step;
        final Supplier<Float> get;
        final Consumer<Float> set;
        final Function<Float, String> fmt;
        boolean deferred;
        float tmp;
        boolean active;

        Slider(float min, float max, float step, Supplier<Float> get, Consumer<Float> set, Function<Float, String> fmt) {
            this.min = min;
            this.max = max;
            this.step = step;
            this.get = get;
            this.set = set;
            this.fmt = fmt;
            h = rh();
        }

        Slider deferred() {
            deferred = true;
            return this;
        }

        float value() {
            return active && deferred ? tmp : get.get();
        }

        void draw(GuiGraphics g, int mx, int my) {
            rfill(g, x, y, w, h, opaque(Theme.mix(c.cButton, 0x000000, 0.25f)));
            float v = value();
            float tt = Math.max(0f, Math.min(1f, (v - min) / (max - min)));
            int fw = Math.round(tt * (w - 2));
            if (fw > 0) grad(g, x + 1, y + 1, fw, h - 2, c.cAccent, c.cAccent2, 0.85f);
            int kx = x + 1 + fw - 1;
            g.fill(kx, y, kx + 3, y + h, 0xFFFFFFFF);
            txtCenter(g, fmt.apply(v), x, w, y + (h - fh()) / 2, cText());
        }

        private void update(int mx) {
            float tt = Math.max(0f, Math.min(1f, (mx - x) / (float) Math.max(1, w)));
            float v = min + tt * (max - min);
            if (step > 0) v = Math.round(v / step) * step;
            v = Math.max(min, Math.min(max, v));
            if (deferred) tmp = v;
            else set.accept(v);
        }

        boolean click(int mx, int my, int b) {
            if (in(mx, my) && b == 0) {
                active = true;
                tmp = get.get();
                dragW = this;
                update(mx);
                return true;
            }
            return false;
        }

        void drag(int mx, int my) {
            update(mx);
        }

        boolean wheel(int dir) {
            float st = step > 0 ? step : (max - min) / 50f;
            float v = Math.max(min, Math.min(max, get.get() + dir * st));
            if (step > 0) v = Math.round(v / step) * step;
            set.accept(v);
            Config.save();
            return true;
        }

        void release() {
            if (deferred) set.accept(tmp);
            active = false;
            Config.save();
        }
    }

    private class Cycle extends W {
        final Supplier<String> cur;
        final Runnable next, prev;

        Cycle(Supplier<String> cur, Runnable next, Runnable prev) {
            this.cur = cur;
            this.next = next;
            this.prev = prev;
            h = rh();
        }

        void draw(GuiGraphics g, int mx, int my) {
            boolean hv = in(mx, my);
            rfill(g, x, y, w, h, cBtn(hv));
            int ty = y + (h - fh()) / 2;
            txt(g, "<", x + 5, ty, cAcc());
            txt(g, ">", x + w - tw(">") - 5, ty, cAcc());
            String s = cur.get();
            while (tw(s) > w - 30 && s.length() > 4) s = s.substring(0, s.length() - 2);
            txtCenter(g, s, x, w, ty, cText());
        }

        boolean click(int mx, int my, int b) {
            if (!in(mx, my)) return false;
            if (b == 1 || mx < x + w / 4) prev.run();
            else next.run();
            return true;
        }

        boolean wheel(int dir) {
            if (dir > 0) next.run();
            else prev.run();
            return true;
        }
    }

    private class TextBox extends W {
        final Supplier<String> get;
        final Consumer<String> set;
        final String hint;
        String buf = "";
        int cur = 0;

        TextBox(Supplier<String> get, Consumer<String> set, String hint) {
            this.get = get;
            this.set = set;
            this.hint = hint;
            h = rh();
        }

        boolean focused() {
            return focus == this;
        }

        String text() {
            return focused() ? buf : get.get();
        }

        void draw(GuiGraphics g, int mx, int my) {
            boolean f = focused();
            rfill(g, x, y, w, h, opaque(Theme.mix(c.cButton, 0x000000, 0.35f)));
            if (f) {
                g.fill(x, y + h - 1, x + w, y + h, cAcc());
            }
            String s = text();
            cur = Math.max(0, Math.min(cur, s.length()));
            int caret = tw(s.substring(0, cur));
            int off = Math.min(0, w - 10 - caret);
            g.enableScissor(x + 2, y, x + w - 2, y + h);
            if (s.isEmpty() && !f) txtStart(g, hint, x + 4, w - 8, y + (h - fh()) / 2, Theme.argb(c.cText, 0.4f));
            else txt(g, s, x + 4 + off, y + (h - fh()) / 2, cText());
            if (f && (System.currentTimeMillis() / 500) % 2 == 0) {
                g.fill(x + 4 + off + caret, y + 3, x + 5 + off + caret, y + h - 3, cText());
            }
            g.disableScissor();
        }

        boolean click(int mx, int my, int b) {
            if (!in(mx, my)) return false;
            if (!focused()) {
                focus = this;
                buf = get.get();
                cur = buf.length();
            } else {
                int caret = tw(buf.substring(0, Math.min(cur, buf.length())));
                int off = Math.min(0, w - 10 - caret);
                int rel = mx - (x + 4 + off);
                int best = 0;
                for (int i = 0; i <= buf.length(); i++) {
                    if (tw(buf.substring(0, i)) <= rel) best = i;
                }
                cur = best;
            }
            return true;
        }

        private void commit() {
            set.accept(buf);
        }

        boolean key(int k, int mods) {
            if (!focused()) return false;
            boolean ctrl = (mods & 10) != 0;
            if (ctrl && k == 86) { // Ctrl+V
                String cb = mc.keyboardHandler.getClipboard();
                if (cb != null) chr(cb.replaceAll("[\\r\\n]", " "));
                return true;
            }
            switch (k) {
                case 259 -> { // backspace
                    if (cur > 0) {
                        buf = buf.substring(0, cur - 1) + buf.substring(cur);
                        cur--;
                        commit();
                    }
                }
                case 261 -> { // delete
                    if (cur < buf.length()) {
                        buf = buf.substring(0, cur) + buf.substring(cur + 1);
                        commit();
                    }
                }
                case 263 -> cur = Math.max(0, cur - 1);
                case 262 -> cur = Math.min(buf.length(), cur + 1);
                case 268 -> cur = 0;
                case 269 -> cur = buf.length();
                case 257, 335 -> {
                    commit();
                    focus = null;
                    Config.save();
                }
                default -> {
                }
            }
            return true;
        }

        boolean chr(String s) {
            if (!focused()) return false;
            for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return true;
            if (buf.length() + s.length() > 240) return true;
            buf = buf.substring(0, cur) + s + buf.substring(cur);
            cur += s.length();
            commit();
            return true;
        }

        void blur() {
            if (focused()) commit();
        }
    }

    private class KeyBtn extends W {
        final IntSupplier get;
        final IntConsumer set;
        final Supplier<String> labelOverride;

        KeyBtn(IntSupplier get, IntConsumer set, Supplier<String> labelOverride) {
            this.get = get;
            this.set = set;
            this.labelOverride = labelOverride;
            h = rh();
        }

        void draw(GuiGraphics g, int mx, int my) {
            boolean cap = capturing == this;
            boolean hv = in(mx, my);
            rfill(g, x, y, w, h, cap ? opaque(c.cAccent) : cBtn(hv));
            String s = cap ? t("Press a key...", "اضغط زرا...")
                    : labelOverride != null ? labelOverride.get() : keyName(get.getAsInt());
            while (tw(s) > w - 8 && s.length() > 3) s = s.substring(0, s.length() - 2);
            txtCenter(g, s, x, w, y + (h - fh()) / 2, cap ? onColor(c.cAccent) : cText());
        }

        boolean click(int mx, int my, int b) {
            if (in(mx, my) && b == 0) {
                capturing = this;
                focus = null;
                return true;
            }
            return false;
        }

        void apply(int code) {
            set.accept(code);
            Config.save();
        }
    }

    private class HBox extends W {
        final List<W> kids = new ArrayList<>();
        final List<Integer> pref = new ArrayList<>();

        HBox(W... ks) {
            for (W k : ks) {
                kids.add(k);
                pref.add(k.w);
            }
            h = rh();
        }

        void place() {
            int fixed = 0, flex = 0;
            for (int p : pref) {
                if (p > 0) fixed += p + GAP;
                else flex++;
            }
            int flexW = flex == 0 ? 0 : Math.max(30, (w - fixed) / flex - (flex > 1 ? GAP : 0));
            int cx = rtl() ? x + w : x;
            for (int i = 0; i < kids.size(); i++) {
                W k = kids.get(i);
                int kw = pref.get(i) > 0 ? pref.get(i) : flexW;
                k.w = kw;
                k.h = h;
                k.y = y;
                if (rtl()) {
                    k.x = cx - kw;
                    cx -= kw + GAP;
                } else {
                    k.x = cx;
                    cx += kw + GAP;
                }
                k.place();
            }
        }

        void draw(GuiGraphics g, int mx, int my) {
            for (W k : kids) k.draw(g, mx, my);
        }

        boolean click(int mx, int my, int b) {
            for (W k : kids) if (k.click(mx, my, b)) return true;
            return false;
        }

        W under(int mx, int my) {
            for (W k : kids) {
                W u = k.under(mx, my);
                if (u != null) return u;
            }
            return null;
        }
    }

    private class Row extends W {
        final String label;
        final W ctrl;
        final int ctrlW;

        Row(String label, W ctrl, int ctrlW) {
            this.label = label;
            this.ctrl = ctrl;
            this.ctrlW = ctrlW;
            h = Math.max(rh(), ctrl.h);
        }

        void place() {
            ctrl.w = Math.min(ctrlW, w - 40);
            ctrl.h = h;
            ctrl.y = y;
            ctrl.x = rtl() ? x : x + w - ctrl.w;
            ctrl.place();
        }

        void draw(GuiGraphics g, int mx, int my) {
            int lw2 = w - ctrl.w - 8;
            String s = label;
            while (tw(s) > lw2 && s.length() > 4) s = s.substring(0, s.length() - 2);
            txtStart(g, s, rtl() ? x + ctrl.w + 8 : x, lw2, y + (h - fh()) / 2, cText());
            ctrl.draw(g, mx, my);
        }

        boolean click(int mx, int my, int b) {
            return ctrl.click(mx, my, b);
        }

        W under(int mx, int my) {
            return ctrl.under(mx, my);
        }
    }

    private static final int[] SWATCH = {0xFFFFFF, 0xFF4D4D, 0xFF9F1C, 0xFFE14D, 0x4DFF88, 0x2EC4FF, 0x4D6BFF, 0x7A5CFF,
            0xFF5CE1, 0x8B5A2B, 0x808080, 0x101010};

    private class ColorBox extends W {
        final IntSupplier get;
        final IntConsumer set;
        final TextBox hex;
        final Slider sr, sg, sb;
        int hueY, hueH, swY, swH;

        ColorBox(IntSupplier get, IntConsumer set) {
            this.get = get;
            this.set = set;
            hex = new TextBox(() -> String.format("#%06X", get.getAsInt() & 0xFFFFFF), s -> {
                String v = s.trim().replace("#", "");
                if (v.length() == 6) {
                    try {
                        set.accept(Integer.parseInt(v, 16));
                    } catch (NumberFormatException ignored) {
                    }
                }
            }, "#RRGGBB");
            sr = new Slider(0, 255, 1, () -> (float) ((get.getAsInt() >> 16) & 255),
                    v -> set.accept((get.getAsInt() & 0x00FFFF) | (Math.round(v) << 16)), v -> "R " + Math.round(v));
            sg = new Slider(0, 255, 1, () -> (float) ((get.getAsInt() >> 8) & 255),
                    v -> set.accept((get.getAsInt() & 0xFF00FF) | (Math.round(v) << 8)), v -> "G " + Math.round(v));
            sb = new Slider(0, 255, 1, () -> (float) (get.getAsInt() & 255),
                    v -> set.accept((get.getAsInt() & 0xFFFF00) | Math.round(v)), v -> "B " + Math.round(v));
            h = rh() * 3 + 16;
        }

        void place() {
            int r = rh();
            hex.x = x + r + 6;
            hex.y = y;
            hex.w = Math.min(110, w - r - 6);
            hex.h = r;
            hueY = y + r + 4;
            hueH = r - 2;
            swY = hueY + hueH + 4;
            swH = r - 2;
            int sw = (w - 2 * GAP) / 3;
            W[] s = {sr, sg, sb};
            for (int i = 0; i < 3; i++) {
                s[i].x = x + i * (sw + GAP);
                s[i].y = swY + swH + 4;
                s[i].w = sw;
                s[i].h = r;
            }
        }

        private int hueAt(int mx) {
            float t = Math.max(0f, Math.min(1f, (mx - x) / (float) Math.max(1, w - 1)));
            return com.n3dl.cosmetics.model.M.hsv(t, 0.85f, 1f) & 0xFFFFFF;
        }

        void draw(GuiGraphics g, int mx, int my) {
            int r = rh();
            int sx = rtl() ? x + w - r : x;
            if (rtl()) hex.x = x + w - r - 6 - hex.w;
            g.fill(sx - 1, y - 1, sx + r + 1, y + r + 1, 0xFFFFFFFF);
            g.fill(sx, y, sx + r, y + r, opaque(get.getAsInt()));
            hex.draw(g, mx, my);
            // hue strip
            int n = Math.min(48, w);
            for (int i = 0; i < n; i++) {
                int x0 = x + i * w / n, x1 = x + (i + 1) * w / n;
                g.fill(x0, hueY, x1, hueY + hueH, opaque(hueAt(x0 + (x1 - x0) / 2)));
            }
            // swatches
            int cw = w / SWATCH.length;
            for (int i = 0; i < SWATCH.length; i++) {
                int x0 = x + i * cw;
                g.fill(x0 + 1, swY, x0 + cw - 1, swY + swH, opaque(SWATCH[i]));
                if ((get.getAsInt() & 0xFFFFFF) == SWATCH[i]) {
                    g.fill(x0, swY - 1, x0 + cw, swY, 0xFFFFFFFF);
                    g.fill(x0, swY + swH, x0 + cw, swY + swH + 1, 0xFFFFFFFF);
                }
            }
            sr.draw(g, mx, my);
            sg.draw(g, mx, my);
            sb.draw(g, mx, my);
        }

        boolean click(int mx, int my, int b) {
            if (hex.click(mx, my, b) || sr.click(mx, my, b) || sg.click(mx, my, b) || sb.click(mx, my, b)) return true;
            if (b == 0 && mx >= x && mx < x + w && my >= hueY && my < hueY + hueH) {
                set.accept(hueAt(mx));
                dragW = this;
                return true;
            }
            if (b == 0 && mx >= x && mx < x + w && my >= swY && my < swY + swH) {
                int i = Math.min(SWATCH.length - 1, (mx - x) * SWATCH.length / Math.max(1, w));
                set.accept(SWATCH[i]);
                Config.save();
                return true;
            }
            return false;
        }

        void drag(int mx, int my) {
            set.accept(hueAt(mx));
        }

        void release() {
            Config.save();
        }

        W under(int mx, int my) {
            for (W k : new W[]{sr, sg, sb}) if (k.in(mx, my)) return k;
            return null;
        }
    }

    private class Preview extends W {
        Preview() {
            h = 16 * 3 + 12;
        }

        private void blit(GuiGraphics g, Identifier tex, int dx, int dy, int dw, int dh, float u, float v, int rw, int rhh, int tw0, int th0) {
            g.blit(RenderPipelines.GUI_TEXTURED, tex, dx, dy, u, v, dw, dh, rw, rhh, tw0, th0);
        }

        void draw(GuiGraphics g, int mx, int my) {
            int sx = rtl() ? x + w - 30 : x;
            rfill(g, x, y, w, h, Theme.argb(c.cBg, 0.6f));
            try {
                CosmeticsManager.Tex cape = CosmeticsManager.preview(c.cape);
                int capeX = rtl() ? x + w - 12 - 30 : x + 12;
                if (cape != null) {
                    Identifier tp = CosmeticsManager.texturePath(cape.current(c.capeFrameMs));
                    float k = Math.max(1f, cape.width / 64f);
                    if (cape.width == 22) k = 1f;
                    blit(g, tp, capeX, y + 6, 30, 48, Math.round(k), Math.round(k), Math.round(10 * k), Math.round(16 * k), cape.width, cape.height);
                } else {
                    txt(g, t("no cape", "بدون كيب"), capeX - 4, y + h / 2 - fh() / 2, Theme.argb(c.cText, 0.5f));
                }
                CosmeticsManager.Tex sk = CosmeticsManager.previewOutfit(c.outfit);
                int ox = rtl() ? x + 12 : x + w - 12 - 36;
                if (sk != null) {
                    Identifier tp = CosmeticsManager.texturePath(sk.frames.get(0));
                    int s = 3, W2 = sk.width, H2 = sk.height;
                    float k = W2 / 64f;
                    int oy = y + 6;
                    blit(g, tp, ox + 4 * s, oy, 8 * s, 8 * s, 8 * k, 8 * k, Math.round(8 * k), Math.round(8 * k), W2, H2);
                    blit(g, tp, ox + 4 * s, oy + 8 * s, 8 * s, 12 * s, 20 * k, 20 * k, Math.round(8 * k), Math.round(12 * k), W2, H2);
                    blit(g, tp, ox, oy + 8 * s, 4 * s, 12 * s, 44 * k, 20 * k, Math.round(4 * k), Math.round(12 * k), W2, H2);
                    blit(g, tp, ox + 12 * s, oy + 8 * s, 4 * s, 12 * s, 36 * k, 52 * k, Math.round(4 * k), Math.round(12 * k), W2, H2);
                    blit(g, tp, ox + 4 * s, oy + 20 * s, 4 * s, 12 * s, 4 * k, 20 * k, Math.round(4 * k), Math.round(12 * k), W2, H2);
                    blit(g, tp, ox + 8 * s, oy + 20 * s, 4 * s, 12 * s, 20 * k, 52 * k, Math.round(4 * k), Math.round(12 * k), W2, H2);
                } else {
                    txt(g, t("no outfit", "بدون ملابس"), ox - 8, y + h / 2 - fh() / 2, Theme.argb(c.cText, 0.5f));
                }
            } catch (Throwable ignored) {
            }
        }
    }

    // ================================================================== building pages

    private String[] pageNames() {
        return new String[]{
                t("General", "عام"), t("Hide", "الإخفاء"), t("Keybinds", "الأزرار"), t("Sounds", "الأصوات"),
                t("Cape & Looks", "الكيب والمظهر"), t("Cosmetics", "الإكسسوارات"), t("Emotes", "الرقصات"), t("Combat", "القتال"), t("Menu style", "شكل القائمة"), t("Extras", "إضافات"), t("Music", "الموسيقى")
        };
    }

    private <T extends W> T sized(T widget, int width) {
        widget.w = width;
        return widget;
    }

    private void add(W w) {
        w.x = 0;
        w.y = cy;
        w.w = cwid;
        if (w instanceof Note n) n.wrap(cwid);
        w.place();
        ws.add(w);
        cy += w.h + GAP;
    }

    private int ctrlW() {
        return Math.max(120, Math.min(230, cwid * 48 / 100));
    }

    private void sec(String s) {
        add(new Sec(s));
    }

    private void note(String s) {
        add(new Note(s));
    }

    private void row(String label, W ctrl) {
        add(new Row(label, ctrl, ctrlW()));
    }

    private void tog(String label, BooleanSupplier g, Consumer<Boolean> s) {
        row(label, new Toggle(g, v -> {
            s.accept(v);
            Config.save();
        }));
    }

    private void sld(String label, float min, float max, float step, Supplier<Float> g, Consumer<Float> s, Function<Float, String> f) {
        row(label, new Slider(min, max, step, g, s, f));
    }

    private void rebuild() {
        if (font == null) return;
        layoutPanel();
        ws.clear();
        focus = null;
        capturing = null;
        cwid = Math.max(80, bw - 2 * PAD - SB - 2);
        cy = 0;
        switch (page) {
            case 0 -> pageGeneral();
            case 1 -> pageHide();
            case 2 -> pageBinds();
            case 3 -> pageSounds();
            case 4 -> pageCosmetics();
            case 5 -> pageCosFx();
            case 6 -> pageEmotes();
            case 7 -> pageCombat();
            case 8 -> pageStyle();
            case 10 -> pageMusic();
            default -> pageExtras();
        }
        contentH = cy + PAD;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentH - bh)));
        builtKey = key();
    }

    private String key() {
        return cwid + "|" + c.textScale + "|" + c.lang + "|" + page + "|" + c.layout + "|" + bw;
    }

    private void pageGeneral() {
        sec(t("General", "عام"));
        tog(t("3DL ABO ZAHRA enabled", "تشغيل 3DL ABO ZAHRA"), () -> c.enabled, v -> c.enabled = v);
        row(t("Language", "اللغة"), new Cycle(() -> c.ar() ? "العربية" : "English", () -> {
            c.lang = c.ar() ? "en" : "ar";
            Config.save();
            rebuild();
        }, () -> {
            c.lang = c.ar() ? "en" : "ar";
            Config.save();
            rebuild();
        }));
        sec(t("Online sync (see other 3DL ABO ZAHRA users)", "المزامنة (شوف مستخدمي 3DL ABO ZAHRA الثانيين)"));
        tog(t("Online sync", "تشغيل المزامنة"), () -> c.syncEnabled, v -> c.syncEnabled = v);
        tog(t("Share my look with others", "شارك مظهري مع الآخرين"), () -> c.syncShare, v -> c.syncShare = v);
        row(t("Server address", "رابط الخادم"), new TextBox(() -> c.syncUrl, v -> c.syncUrl = v.trim(), "https://...workers.dev"));
        add(new HBox(
                new Btn(() -> t("Test connection", "اختبار الاتصال"), com.n3dl.net.SyncClient::test).accent(),
                new Lbl(() -> {
                    String st = com.n3dl.net.SyncClient.status();
                    if (st.isEmpty()) return t("Not connected yet", "غير متصل بعد");
                    if (com.n3dl.net.SyncClient.connected())
                        return t("Connected. 3DL ABO ZAHRA users nearby: ", "متصل. مستخدمو 3DL ABO ZAHRA حولك: ") + com.n3dl.net.SyncClient.nearbyCount();
                    return st;
                })));
        note(t("Both players paste the same server address (setup steps are in the server folder of the mod project). Players without the mod see you normally. Capes up to 300 KB are shared.",
                "كل اللاعبين يلصقون نفس رابط الخادم (خطوات التجهيز في مجلد server داخل مشروع المود). اللي ما عنده المود يشوفك عادي. الكيب يتشارك إذا حجمه أقل من 300 كيلوبايت."));
        sec(t("Keys (click then press a key)", "الأزرار (اضغط ثم اختر زرا)"));
        mapRow(t("Open this menu", "فتح هذه القائمة"), AboClient.OPEN);
        mapRow(t("Streamer mode", "وضع البث"), AboClient.STREAMER);
        mapRow(t("3DL ABO ZAHRA on / off", "تشغيل / إيقاف 3DL ABO ZAHRA"), AboClient.TOGGLE);
        mapRow(t("Zoom (hold)", "التقريب (اضغط باستمرار)"), AboClient.ZOOM);
        note(t("Default menu key is Right Shift. Right-click a key button while choosing to clear it. You can create unlimited command keys in the Keybinds page.",
                "زر القائمة الافتراضي هو Right Shift. اضغط على زر ماوس إضافي أو لوحة المفاتيح لتعيين الزر. يمكنك إنشاء عدد غير محدود من أزرار الأوامر من صفحة الأزرار."));
    }

    private void mapRow(String label, KeyMapping km) {
        row(label, new KeyBtn(() -> AboClient.boundKey(km), code -> setMapping(km, code),
                () -> km.getTranslatedKeyMessage().getString()));
    }

    private void pageHide() {
        sec(t("Hide parts of the game", "إخفاء عناصر اللعبة"));
        tog(t("Streamer mode (hide everything)", "وضع البث (إخفاء الكل)"), () -> c.streamer, v -> c.streamer = v);
        tog(t("Hide chat", "إخفاء الشات"), () -> c.hideChat, v -> c.hideChat = v);
        tog(t("Hide tab list", "إخفاء التاب"), () -> c.hideTab, v -> c.hideTab = v);
        tog(t("Hidden tab still shows player names", "التاب المخفي يظهر الأسماء فقط"), () -> c.tabNamesOnly, v -> c.tabNamesOnly = v);
        tog(t("Hide scoreboard", "إخفاء السكور بورد"), () -> c.hideScoreboard, v -> c.hideScoreboard = v);
        tog(t("Hide rank look (prefix/suffix/colour)", "إخفاء شكل الرتبة"), () -> c.hideRanks, v -> c.hideRanks = v);
        tog(t("Hide all name tags", "إخفاء النيم تاج للجميع"), () -> c.hideNametags, v -> c.hideNametags = v);
        tog(t("Hide boss bars", "إخفاء شريط الزعيم"), () -> c.hideBossBar, v -> c.hideBossBar = v);
        tog(t("Hide titles", "إخفاء العناوين"), () -> c.hideTitle, v -> c.hideTitle = v);
        sec(t("Hide the name tag of one player", "إخفاء النيم تاج للاعب معين"));
        TextBox nb = new TextBox(() -> newPlayer, s -> newPlayer = s, t("Player name", "اسم اللاعب"));
        add(new HBox(nb, new Btn(() -> "+", () -> {
            String n = newPlayer.trim();
            if (!n.isEmpty() && c.hiddenPlayers.stream().noneMatch(p -> p.equalsIgnoreCase(n))) c.hiddenPlayers.add(n);
            newPlayer = "";
            focus = null;
            Config.save();
            rebuild();
        }).accent().width(rh() + 6)));
        for (int i = 0; i < c.hiddenPlayers.size(); i++) {
            final int idx = i;
            add(new HBox(new Lbl(() -> c.hiddenPlayers.get(idx)), new Btn(() -> "x", () -> {
                c.hiddenPlayers.remove(idx);
                Config.save();
                rebuild();
            }).width(rh() + 6)));
        }
        if (c.hiddenPlayers.isEmpty()) note(t("No players hidden.", "لا يوجد لاعبون مخفيون."));
    }

    private void pageBinds() {
        sec(t("One-press commands", "أزرار تنفذ أوامر بضغطة واحدة"));
        note(t("Each bind has keys and commands. Commands: /command, plain chat text, or an action like @streamer. Use @wait:500 to pause. Many keys can trigger the same bind.",
                "لكل زر مفاتيح وأوامر. الأوامر: /أمر ، أو نص يُرسل في الشات ، أو إجراء مثل @streamer. استخدم @wait:500 للانتظار. يمكن لعدة أزرار تشغيل نفس الأمر."));
        for (int bi = 0; bi < c.binds.size(); bi++) {
            final Config.BindEntry b = c.binds.get(bi);
            add(new Sec(t("Bind ", "زر ") + (bi + 1)));
            add(new HBox(
                    new TextBox(() -> b.name, s -> b.name = s, t("Name", "الاسم")),
                    sized(new Toggle(() -> b.enabled, v -> {
                        b.enabled = v;
                        Config.save();
                    }), 72),
                    new Btn(() -> "x", () -> {
                        c.binds.remove(b);
                        Config.save();
                        rebuild();
                    }).width(rh() + 6)));
            // keys
            List<W> keyRow = new ArrayList<>();
            for (int ki = 0; ki < b.keys.size(); ki++) {
                final int kIdx = ki;
                KeyBtn kb = new KeyBtn(() -> b.keys.get(kIdx), code -> b.keys.set(kIdx, code), null);
                kb.w = Math.max(70, tw("Right Shift") + 16);
                if (capBind == b && capIdx == ki) {
                    capturing = kb;
                    capBind = null;
                }
                keyRow.add(kb);
                keyRow.add(new Btn(() -> "x", () -> {
                    b.keys.remove(kIdx);
                    Config.save();
                    rebuild();
                }).width(rh() + 4));
            }
            keyRow.add(new Btn(() -> t("+ key", "+ زر"), () -> {
                b.keys.add(-1);
                capBind = b;
                capIdx = b.keys.size() - 1;
                rebuild();
            }).accent().width(Math.max(50, tw(t("+ key", "+ زر")) + 14)));
            add(new HBox(keyRow.toArray(new W[0])));
            // commands
            for (int ci = 0; ci < b.commands.size(); ci++) {
                final int cIdx = ci;
                add(new HBox(
                        new TextBox(() -> b.commands.get(cIdx), s -> b.commands.set(cIdx, s), "/command  |  text  |  @action"),
                        new Btn(() -> "x", () -> {
                            b.commands.remove(cIdx);
                            Config.save();
                            rebuild();
                        }).width(rh() + 6)));
            }
            add(new HBox(
                    new Btn(() -> t("+ command", "+ أمر"), () -> {
                        b.commands.add("");
                        rebuild();
                    }).width(Math.max(80, tw(t("+ command", "+ أمر")) + 16)),
                    new Cycle(() -> Actions.label(Actions.QUICK.get(quickSel)),
                            () -> quickSel = (quickSel + 1) % Actions.QUICK.size(),
                            () -> quickSel = (quickSel + Actions.QUICK.size() - 1) % Actions.QUICK.size()),
                    new Btn(() -> t("+ action", "+ إجراء"), () -> {
                        b.commands.add(Actions.QUICK.get(quickSel));
                        Config.save();
                        rebuild();
                    }).accent().width(Math.max(70, tw(t("+ action", "+ إجراء")) + 16)),
                    new Btn(() -> t("Test", "تجربة"), () -> Actions.run(b.commands)).width(Math.max(50, tw(t("Test", "تجربة")) + 16))));
        }
        add(new Btn(() -> t("+ New bind", "+ زر جديد"), () -> {
            Config.BindEntry nb = new Config.BindEntry();
            nb.name = t("My bind", "زري");
            nb.keys.add(-1);
            c.binds.add(nb);
            capBind = nb;
            capIdx = 0;
            Config.save();
            rebuild();
        }).accent());
    }

    // ---- in-game file browser (phones have no file window)
    private java.nio.file.Path browseDir;
    private Config.SoundCfg browseTarget;
    private String skinSrc = "", skinStatus = "";
    private boolean browseExtra, browseMusic;
    private String musicUrl = "", musicStatus = "";

    private void openBrowser(Config.SoundCfg s, boolean extra) {
        browseTarget = s;
        browseExtra = extra;
        if (browseDir == null) {
            for (String d : new String[]{"/storage/emulated/0/Download", "/storage/emulated/0", System.getProperty("user.home")}) {
                if (d != null && java.nio.file.Files.isDirectory(java.nio.file.Path.of(d))) {
                    browseDir = java.nio.file.Path.of(d);
                    break;
                }
            }
        }
        if (browseDir == null) browseDir = java.nio.file.Path.of(".").toAbsolutePath();
        rebuild();
    }

    private void pageBrowser() {
        sec(t("Choose a sound file", "اختيار ملف صوت"));
        add(new Lbl(() -> browseDir.toString()));
        add(new HBox(
                new Btn(() -> t("Cancel", "إلغاء"), () -> {
                    browseTarget = null;
                    browseMusic = false;
                    rebuild();
                }),
                new Btn(() -> t("Up", "للأعلى"), () -> {
                    if (browseDir.getParent() != null) browseDir = browseDir.getParent();
                    rebuild();
                }),
                new Btn(() -> t("Downloads", "التنزيلات"), () -> {
                    java.nio.file.Path d = java.nio.file.Path.of("/storage/emulated/0/Download");
                    if (java.nio.file.Files.isDirectory(d)) browseDir = d;
                    rebuild();
                })));
        java.util.List<java.nio.file.Path> items = new ArrayList<>();
        try (var st = java.nio.file.Files.list(browseDir)) {
            st.forEach(items::add);
        } catch (Exception e) {
            note(t("Cannot open this folder (no permission).", "تعذر فتح هذا المجلد (لا توجد صلاحية)."));
        }
        items.sort((a, b) -> {
            boolean da = java.nio.file.Files.isDirectory(a), db = java.nio.file.Files.isDirectory(b);
            if (da != db) return da ? -1 : 1;
            return a.getFileName().toString().compareToIgnoreCase(b.getFileName().toString());
        });
        int shown = 0;
        for (java.nio.file.Path f : items) {
            String n = f.getFileName().toString();
            if (n.startsWith(".")) continue;
            boolean dir = java.nio.file.Files.isDirectory(f);
            if (!dir && !com.n3dl.audio.AudioDecoder.supported(n.toLowerCase())) continue;
            if (shown++ > 300) break;
            add(new Btn(() -> (dir ? "[ ] " : "♪ ") + n, () -> {
                if (dir) {
                    browseDir = f;
                } else if (browseMusic) {
                    String added = com.n3dl.audio.MusicPlayer.addFile(f);
                    browseMusic = false;
                    browseTarget = null;
                    musicStatus = added != null ? t("Song added: ", "تمت إضافة الأغنية: ") + added
                            : t("Could not use this file.", "تعذر استخدام هذا الملف.");
                } else {
                    Config.SoundCfg s = browseTarget;
                    browseTarget = null;
                    if (browseExtra) {
                        String src = SoundPlayer.importFile(f);
                        if (src != null) {
                            if (s.more == null) s.more = new ArrayList<>();
                            s.more.add(src);
                            Config.save();
                            SoundPlayer.clearCache();
                            status = t("Sound added: ", "تمت إضافة الصوت: ") + SoundPlayer.display(src);
                        } else {
                            status = t("Could not use this file.", "تعذر استخدام هذا الملف.");
                        }
                    } else {
                        applyAudio(s, f);
                    }
                }
                rebuild();
            }));
        }
        if (shown == 0) note(t("No folders or sound files here.", "لا توجد مجلدات أو ملفات صوت هنا."));
    }

    private void pageSounds() {
        if (browseTarget != null) {
            pageBrowser();
            return;
        }
        sec(t("Sounds", "الأصوات"));
        sld(t("Master volume", "مستوى الصوت العام"), 0f, 3f, 0.05f, () -> c.soundMaster, v -> c.soundMaster = v, AboScreen::pct);
        row(t("Kill chat text ({me} = you)", "نص القتل في الشات ({me} = اسمك)"),
                new TextBox(() -> c.killChatPattern, s -> c.killChatPattern = s, "by {me}"));
        note(t("Kill sound plays when the player you hit dies, or when a chat line contains the text above. Volume above 100% is amplified. Put your own .wav files in the sounds folder.",
                "يعمل صوت القتل عندما يموت اللاعب الذي ضربته، أو عندما يحتوي سطر في الشات على النص أعلاه. المستوى فوق 100% يعني تضخيم الصوت. ضع ملفات wav الخاصة بك في مجلد الأصوات."));
        soundBlock(t("Kill sound", "صوت القتل"), c.kill);
        soundBlock(t("Hit sound (when you hit someone)", "صوت الضربة"), c.hit);
        soundBlock(t("Death sound (when you die)", "صوت موتك"), c.death);
        soundBlock(t("Chat mention sound", "صوت ذكر اسمك في الشات"), c.mention);
        sec(t("Weapon sounds", "أصوات الأسلحة"));
        tog(t("Weapon sounds", "أصوات الأسلحة"), () -> c.weaponSounds, v -> c.weaponSounds = v);
        note(t("Pick a weapon and give it its own kill / hit sound. Any weapon you did not add uses the normal sounds above. You can add several sounds to one weapon: one is picked at random.",
                "اختر سلاحا وحدد له صوت قتل وضربة خاص. أي سلاح ما أضفته يستخدم الأصوات العادية بالأعلى. تقدر تضيف أكثر من صوت للسلاح: يختار واحدا عشوائيا."));
        for (int wi = 0; wi < c.weaponList.size(); wi++) {
            Config.WeaponSound w = c.weaponList.get(wi);
            sec(weaponLabel(w.item));
            row(t("Weapon", "السلاح"), new Cycle(() -> weaponLabel(w.item), () -> cycleWeapon(w, 1), () -> cycleWeapon(w, -1)));
            add(new HBox(
                    new Btn(() -> t("Use the item in my hand", "خذ الغرض اللي بيدي"), () -> {
                        net.minecraft.world.item.ItemStack st = mc.player == null ? null : mc.player.getMainHandItem();
                        w.item = st == null || st.isEmpty() ? "hand"
                                : net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(st.getItem()).toString();
                        Config.save();
                    }),
                    new Btn(() -> t("Remove this weapon", "حذف هذا السلاح"), () -> {
                        c.weaponList.remove(w);
                        Config.save();
                        rebuild();
                    })));
            soundBlock(t("Kill sound", "صوت القتل") + " - " + weaponLabel(w.item), w.kill);
            soundBlock(t("Hit sound", "صوت الضربة") + " - " + weaponLabel(w.item), w.hit);
        }
        add(new Btn(() -> t("+ Add a weapon", "+ إضافة سلاح"), () -> {
            Config.WeaponSound w = new Config.WeaponSound();
            w.item = c.weaponList.isEmpty() ? "minecraft:mace" : "minecraft:diamond_sword";
            c.weaponList.add(w);
            Config.save();
            rebuild();
        }).accent());
        sec(t("Your sound files", "ملفات الصوت الخاصة بك"));
        note(t("Press \"Choose audio file\" under any sound and pick an mp3 / ogg / wav from your device, or drag a file into this menu. Files are copied into the sounds folder. On phones where no file window opens, copy the file into the sounds folder yourself.",
                "اضغط \"اختيار ملف صوت\" تحت أي صوت واختر ملف mp3 أو ogg أو wav من جهازك، أو اسحب الملف إلى القائمة. تُنسخ الملفات إلى مجلد الأصوات. في الجوال إذا لم تظهر نافذة اختيار، انسخ الملف إلى مجلد الأصوات بنفسك."));
        add(new Lbl(() -> status));
        add(new HBox(
                new Btn(() -> t("Open sounds folder", "فتح مجلد الأصوات"), () -> openDir(SoundPlayer.soundsDir())),
                new Btn(() -> t("Reload list", "تحديث القائمة"), () -> {
                    SoundPlayer.clearCache();
                    rebuild();
                })));
    }

    private void soundBlock(String title, Config.SoundCfg s) {
        sec(title);
        tog(t("Enabled", "مفعّل"), () -> s.enabled, v -> s.enabled = v);
        List<String> all = SoundPlayer.sources();
        Runnable next = () -> {
            int i = all.indexOf(s.source);
            s.source = all.get((i + 1) % all.size());
            Config.save();
        };
        Runnable prev = () -> {
            int i = all.indexOf(s.source);
            s.source = all.get((i - 1 + all.size()) % all.size());
            Config.save();
        };
        row(t("Sound", "الصوت"), new Cycle(() -> SoundPlayer.display(s.source), next, prev));
        if (s.more == null) s.more = new ArrayList<>();
        for (int mi = 0; mi < s.more.size(); mi++) {
            int idx = mi;
            Cycle ex = new Cycle(() -> SoundPlayer.display(s.more.get(idx)), () -> {
                int i = all.indexOf(s.more.get(idx));
                s.more.set(idx, all.get((i + 1) % all.size()));
                Config.save();
            }, () -> {
                int i = all.indexOf(s.more.get(idx));
                s.more.set(idx, all.get((i - 1 + all.size()) % all.size()));
                Config.save();
            });
            row(t("Extra sound ", "صوت إضافي ") + (mi + 1), new HBox(ex, sized(new Btn(() -> "x", () -> {
                s.more.remove(idx);
                Config.save();
                rebuild();
            }), 28)));
        }
        add(new HBox(
                new Btn(() -> t("+ Add another sound", "+ إضافة صوت آخر"), () -> {
                    s.more.add(all.get(0));
                    Config.save();
                    rebuild();
                }),
                new Btn(() -> t("+ Add a file", "+ إضافة ملف"), () -> pickAudioExtra(s)),
                new Btn(() -> t("Browse (phone)", "تصفح (جوال)"), () -> openBrowser(s, true))));
        if (!s.more.isEmpty()) note(t("Several sounds: one is chosen at random each time.", "عدة أصوات: يختار واحدا عشوائيا كل مرة."));
        sld(t("Volume", "مستوى الصوت"), 0f, 3f, 0.05f, () -> s.volume, v -> s.volume = v, AboScreen::pct);
        sld(t("Pitch", "حدة الصوت"), 0.5f, 2f, 0.05f, () -> s.pitch, v -> s.pitch = v, v -> String.format("%.2f", v));
        add(new HBox(
                new Btn(() -> t("Play", "تشغيل"), () -> {
                    dropSound = s;
                    SoundPlayer.play(s);
                }),
                new Btn(() -> t("Stop", "إيقاف"), SoundPlayer::stopAll),
                new Btn(() -> t("Choose audio file...", "اختيار ملف صوت..."), () -> pickAudio(s)).accent(),
                new Btn(() -> t("Browse (phone)", "تصفح (جوال)"), () -> openBrowser(s, false))));
    }

    private void pickAudioExtra(Config.SoundCfg s) {
        dropSound = s;
        FilePicker.pick(t("Choose a sound (mp3, ogg, wav)", "اختر ملف صوت (mp3, ogg, wav)"), "Audio",
                new String[]{"*.mp3", "*.ogg", "*.wav", "*.aif", "*.aiff", "*.au"}, path -> {
                    if (path == null) {
                        status = t("No file chosen. If no window opened: copy the file into the sounds folder, then use \"Add another sound\".",
                                "لم يتم اختيار ملف. إذا لم تظهر نافذة: انسخ الملف إلى مجلد الأصوات ثم استخدم \"إضافة صوت آخر\".");
                    } else {
                        String src = SoundPlayer.importFile(path);
                        if (src != null) {
                            s.more.add(src);
                            Config.save();
                            SoundPlayer.clearCache();
                            status = t("Sound added: ", "تمت إضافة الصوت: ") + SoundPlayer.display(src);
                        } else {
                            status = t("Could not use this file.", "تعذر استخدام هذا الملف.");
                        }
                    }
                    rebuild();
                });
    }

    private static final String[] WEAPONS = buildWeapons();

    private static String[] buildWeapons() {
        List<String> l = new ArrayList<>();
        l.add("hand");
        for (String m : new String[]{"wooden", "stone", "copper", "iron", "golden", "diamond", "netherite"}) {
            l.add("minecraft:" + m + "_sword");
            l.add("minecraft:" + m + "_axe");
        }
        l.add("minecraft:mace");
        l.add("minecraft:trident");
        l.add("minecraft:bow");
        l.add("minecraft:crossbow");
        l.add("minecraft:wind_charge");
        for (String m : new String[]{"wooden", "stone", "copper", "iron", "golden", "diamond", "netherite"}) l.add("minecraft:" + m + "_spear");
        return l.toArray(new String[0]);
    }

    private String weaponLabel(String id) {
        if (id == null || id.equals("hand")) return t("Empty hand", "اليد (بدون سلاح)");
        String p = id.startsWith("minecraft:") ? id.substring(10) : id;
        if (!c.ar()) {
            StringBuilder sb = new StringBuilder();
            for (String w : p.split("_")) sb.append(w.isEmpty() ? "" : Character.toUpperCase(w.charAt(0)) + w.substring(1)).append(' ');
            return sb.toString().trim();
        }
        java.util.Map<String, String> mat = java.util.Map.of("wooden", "خشبي", "stone", "حجري", "copper", "نحاسي", "iron", "حديدي",
                "golden", "ذهبي", "diamond", "ماسي", "netherite", "نذرايت");
        java.util.Map<String, String> typ = java.util.Map.of("sword", "سيف", "axe", "فأس", "mace", "مطرقة (ميس)", "trident", "ترايدنت",
                "bow", "قوس", "crossbow", "كروسبو", "spear", "رمح (سبير)", "wind_charge", "ويند تشارج");
        String[] parts = p.split("_", 2);
        if (typ.containsKey(p)) return typ.get(p);
        if (parts.length == 2 && mat.containsKey(parts[0]) && typ.containsKey(parts[1])) return typ.get(parts[1]) + " " + mat.get(parts[0]);
        return p;
    }

    private void cycleWeapon(Config.WeaponSound w, int d) {
        int i = -1;
        for (int k = 0; k < WEAPONS.length; k++) if (WEAPONS[k].equals(w.item)) i = k;
        w.item = WEAPONS[Math.floorMod(i + d, WEAPONS.length)];
        Config.save();
    }

    private void pageCombat() {
        sec(t("Mace swap", "تبديل المطرقة (ميس)"));
        tog(t("Hit with the mace automatically", "الضربة تتحول للميس تلقائيا"), () -> c.maceSwap, v -> c.maceSwap = v);
        tog(t("Only when I hit a player", "فقط لما أضرب لاعب"), () -> c.maceSwapPlayersOnly, v -> c.maceSwapPlayersOnly = v);
        tog(t("Go back to my item after the hit", "ارجع لغرضي بعد الضربة"), () -> c.maceSwapReturn, v -> c.maceSwapReturn = v);
        sld(t("Go back after (ticks, 0 = instant)", "الرجوع بعد (تك، 0 = فوري)"), 0f, 10f, 1f, () -> (float) c.maceReturnTicks,
                v -> c.maceReturnTicks = Math.round(v), v -> Math.round(v) + "");
        note(t("With \"go back\" on, the swap to the mace and back happens inside the same tick as the hit, so you never see the mace in your hand and there is no delay.",
                "لما \"ارجع لغرضي\" يكون مفعل، التحويل للميس والرجوع يصير في نفس تك الضربة، فما تشوف الميس بيدك وما فيه أي تأخير."));
        note(t("The mace must be in your hotbar (not only the inventory). Whatever weapon you hold, hitting a target switches to the mace first.",
                "لازم الميس يكون في الهوت بار (مو بس في الانفنتوري). بأي سلاح تمسكه، أول ما تضرب هدف يتحول للميس قبل الضربة."));

        sec(t("Spear swap", "تبديل الرمح (سبير)"));
        row(t("Key", "الزر"), sized(new KeyBtn(() -> c.spearKey, k -> c.spearKey = k, null), 120));
        sld(t("Back to my item after (ticks)", "الرجوع لغرضي بعد (تك)"), 2f, 20f, 1f, () -> (float) c.spearReturnTicks,
                v -> c.spearReturnTicks = Math.round(v), v -> Math.round(v) + "");
        note(t("Press the key: it switches to the spear in your hotbar, does the lunge, and goes back to your last item. Press again quickly to repeat. Right click on the key button to clear it.",
                "اضغط الزر: يتحول للرمح اللي بالهوت بار، يسوي الحركة، ويرجع لآخر غرض كنت ماسكه. اضغطه بسرعة مرة ثانية للتكرار. كليك يمين على زر الزر لمسحه."));

        tog(t("Jump together with the swap", "نط مع السواب (مسافة أكثر)"), () -> c.spearJump, v -> c.spearJump = v);

        sec(t("Trigger bot (auto attack)", "تريقر بوت (ضرب تلقائي)"));
        tog(t("Enabled", "مفعّل"), () -> c.tbOn, v -> c.tbOn = v);
        row(t("Toggle key", "زر التشغيل/الإيقاف"), sized(new KeyBtn(() -> c.tbKey, k -> c.tbKey = k, null), 120));
        tog(t("Players", "لاعبين"), () -> c.tbPlayers, v -> c.tbPlayers = v);
        tog(t("Mobs", "وحوش"), () -> c.tbMobs, v -> c.tbMobs = v);
        tog(t("Animals", "حيوانات"), () -> c.tbAnimals, v -> c.tbAnimals = v);
        tog(t("Crystal", "كرستال"), () -> c.tbCrystal, v -> c.tbCrystal = v);
        tog(t("Villagers", "قرويين"), () -> c.tbVillagers, v -> c.tbVillagers = v);
        tog(t("Armor stands", "ستاند"), () -> c.tbStands, v -> c.tbStands = v);
        tog(t("Others", "أخرى"), () -> c.tbOthers, v -> c.tbOthers = v);
        String[] hm = {t("Always", "دائما"), t("Only crits", "كريتيكال فقط"), t("Crit if falling, else normal", "كريتيكال بالهواء وإلا عادي")};
        row(t("Hit mode", "نمط الضرب"), new Cycle(() -> hm[c.tbHitMode], () -> {
            c.tbHitMode = (c.tbHitMode + 1) % 3;
            Config.save();
        }, () -> {
            c.tbHitMode = (c.tbHitMode + 2) % 3;
            Config.save();
        }));
        sld(t("Reach (0 = default)", "المدى (0 = الافتراضي)"), 0f, 6f, 0.1f, () -> c.tbReach, v -> c.tbReach = v,
                v -> v < 0.05f ? t("Default", "افتراضي") : String.format("%.1f", v));
        sld(t("Miss chance", "نسبة التفويت"), 0f, 100f, 1f, () -> c.tbMiss, v -> c.tbMiss = v, v -> Math.round(v) + "%");
        tog(t("Not while using an item", "لا تضرب وأنت تستخدم غرض"), () -> c.tbPauseUse, v -> c.tbPauseUse = v);
        tog(t("Simulate clicks", "محاكاة النقرات"), () -> c.tbSimulate, v -> c.tbSimulate = v);
        tog(t("Only with a weapon", "فقط بالسلاح"), () -> c.tbOnlyWeapon, v -> c.tbOnlyWeapon = v);
        tog(t("Ignore NPC bots", "تجاهل البوتات (NPC)"), () -> c.tbAntiBot, v -> c.tbAntiBot = v);
        tog(t("Skip targets that block with a shield", "تجاهل اللي يصد بالدرع"), () -> c.tbSkipBlocking, v -> c.tbSkipBlocking = v);
        tog(t("Focus mode (stay on one target)", "تركيز (على هدف واحد)"), () -> c.tbFocus, v -> c.tbFocus = v);
        tog(t("Attack with a menu open", "اضرب والقائمة مفتوحة"), () -> c.tbInGui, v -> c.tbInGui = v);
        String[] tm = {t("Weapon cooldown", "كولداون السلاح"), "CPS"};
        row(t("Mode", "الوضع"), new Cycle(() -> tm[c.tbMode], () -> {
            c.tbMode = (c.tbMode + 1) % 2;
            Config.save();
        }, () -> {
            c.tbMode = (c.tbMode + 1) % 2;
            Config.save();
        }));
        sld("CPS", 1f, 20f, 0.5f, () -> c.tbCps, v -> c.tbCps = v, v -> String.format("%.1f", v));
        sld(t("Double click chance", "فرصة النقرة المزدوجة"), 0f, 100f, 1f, () -> c.tbDouble, v -> c.tbDouble = v, v -> Math.round(v) + "%");
        note(t("It hits when the crosshair is on a valid target. \"Only crits\" waits until you are falling (jump and it hits at the right moment). Many servers ban this; use it where it is allowed.",
                "يضرب لما يكون المؤشر على هدف صالح. \"كريتيكال فقط\" ينتظر لين تكون نازل من القفزة (اقفز وبيضرب بالوقت الصحيح). كثير سيرفرات تمنعه، استخدمه بالأماكن المسموحة."));

        sec(t("Wind charge + ender pearl", "ويند تشارج + إندر بيرل"));
        row(t("Key", "الزر"), sized(new KeyBtn(() -> c.windKey, k -> c.windKey = k, null), 120));
        String[] dirs = {t("Down", "للأسفل"), t("Up", "للأعلى"), t("Where I look", "حسب نظري")};
        row(t("Last wind charge aims", "آخر ويند يتجه"), new Cycle(() -> dirs[c.windFinalDir], () -> {
            c.windFinalDir = (c.windFinalDir + 1) % 3;
            Config.save();
        }, () -> {
            c.windFinalDir = (c.windFinalDir + 2) % 3;
            Config.save();
        }));
        tog(t("Restore my view direction", "رجّع اتجاه النظر"), () -> c.windRestoreView, v -> c.windRestoreView = v);
        tog(t("Back to my item at the end", "ارجع لغرضي في الآخر"), () -> c.windReturn, v -> c.windReturn = v);
        note(t("Press the key: it looks down and throws a wind charge, jumps right after, looks at the sky and throws an ender pearl, then throws the last wind charge the moment its cooldown ends. The timing is fixed and follows the game's own cooldowns, and the camera is frozen until it finishes (mouse and touch). You need a wind charge and an ender pearl in the hotbar.",
                "اضغط الزر: ينظر للأسفل ويرمي ويند تشارج، يقفز بعدها مباشرة، ينظر للسماء ويرمي إندر بيرل، ثم يرمي آخر ويند تشارج في نفس لحظة انتهاء الكول داون. التوقيت ثابت ويمشي مع كول داون اللعبة نفسه، والشاشة تتجمد (ماوس ولمس) لين تخلص الحركة. تحتاج ويند تشارج وإندر بيرل في الهوت بار."));
        note(t("Many servers ban automatic item swapping or movement help. Use it where it is allowed.",
                "كثير من السيرفرات تمنع تبديل الأغراض أو المساعدة التلقائية في الحركة. استخدمه في الأماكن المسموحة."));
    }

    private void pickAudio(Config.SoundCfg s) {
        dropSound = s;
        status = t("Opening file dialog...", "جاري فتح نافذة الملفات...");
        FilePicker.pick(t("Choose a sound (mp3, ogg, wav)", "اختر ملف صوت (mp3, ogg, wav)"), "Audio",
                new String[]{"*.mp3", "*.ogg", "*.wav", "*.aif", "*.aiff", "*.au"}, path -> {
                    if (path == null) {
                        status = t("No file chosen. If no window opened: drag the file into this menu, or copy it into the sounds folder.",
                                "لم يتم اختيار ملف. إذا لم تظهر نافذة: اسحب الملف إلى هذه القائمة، أو انسخه إلى مجلد الأصوات.");
                    } else {
                        applyAudio(s, path);
                    }
                    rebuild();
                });
    }

    private void applyAudio(Config.SoundCfg s, Path path) {
        String src = SoundPlayer.importFile(path);
        if (src == null) {
            status = t("Could not use this file (supported: mp3, ogg, wav).", "تعذر استخدام هذا الملف (المدعوم: mp3, ogg, wav).");
            return;
        }
        s.source = src;
        s.enabled = true;
        Config.save();
        SoundPlayer.clearCache();
        status = t("Sound set: ", "تم تعيين الصوت: ") + SoundPlayer.display(src);
    }

    /** Files dropped on the window (desktop). */
    public void onFilesDrop(List<Path> paths) {
        for (Path p : paths) {
            String n = p.getFileName().toString().toLowerCase();
            if (SoundPlayer.sources() != null && com.n3dl.audio.AudioDecoder.supported(n)) {
                applyAudio(dropSound != null ? dropSound : c.kill, p);
            } else if (n.matches(".*\\.(png|gif|jpg|jpeg|bmp)$")) {
                String r = dropOutfit ? CosmeticsManager.importOutfit(p) : CosmeticsManager.importCape(p);
                if (r != null) {
                    if (dropOutfit) c.outfit = r;
                    else c.cape = r;
                    Config.save();
                    status = t("Added: ", "تمت الإضافة: ") + r;
                } else {
                    status = t("Could not read this picture.", "تعذر قراءة هذه الصورة.");
                }
            }
        }
        rebuild();
    }

    private List<String> withNone(List<String> l) {
        List<String> r = new ArrayList<>();
        r.add("");
        r.addAll(l);
        return r;
    }

    private void pageCosmetics() {
        sec(t("Cape", "الكيب"));
        add(new Preview());
        List<String> capes = withNone(CosmeticsManager.list(CosmeticsManager.capesDir(), true));
        row(t("Cape", "الكيب"), new Cycle(() -> c.cape.isEmpty() ? t("None", "بدون") : c.cape,
                () -> pick(capes, true, 1), () -> pick(capes, true, -1)));
        sld(t("Animation speed (ms per frame)", "سرعة الحركة (مللي ثانية لكل إطار)"), 30f, 500f, 10f, () -> (float) c.capeFrameMs, v -> c.capeFrameMs = Math.round(v), v -> Math.round(v) + " ms");
        tog(t("Same cape on elytra", "نفس الكيب على الإليترا"), () -> c.capeElytra, v -> c.capeElytra = v);
        add(new HBox(
                new Btn(() -> t("Choose picture / GIF...", "اختيار صورة / GIF..."), this::pickCapeFile).accent()));
        String[] fits = {"COVER", "CONTAIN", "STRETCH"};
        String[] fitNames = {t("Fill (crop)", "ملء (قص)"), t("Fit inside", "احتواء"), t("Stretch", "تمديد")};
        row(t("Picture fit on cape", "ضبط الصورة على الكيب"), new Cycle(() -> {
            for (int i = 0; i < fits.length; i++) if (fits[i].equals(c.capeFit)) return fitNames[i];
            return fitNames[0];
        }, () -> cycleFit(fits, 1), () -> cycleFit(fits, -1)));
        add(new Lbl(() -> status));
        note(t("Any picture or GIF works: it is placed on the cape automatically. Ready-made cape files (PNG 64x32 / 128x64) and animated ones (frames stacked, or GIF) also work.",
                "أي صورة أو GIF تصلح: توضع على الكيب تلقائيا. وملفات الكيب الجاهزة (PNG بحجم 64x32 أو 128x64) والمتحركة (إطارات فوق بعض أو GIF) تعمل أيضا."));
        note(t("Static cape: PNG 64x32 (or HD 128x64). Animated cape: PNG with frames stacked vertically (64 x 32N) or a GIF. Only you can see it.",
                "كيب ثابت: صورة PNG بحجم 64x32 (أو 128x64). كيب متحرك: صورة PNG بإطارات فوق بعضها (64 x 32N) أو ملف GIF. أنت فقط من يراه."));
        add(new HBox(
                new Btn(() -> t("Open capes folder", "فتح مجلد الكيب"), () -> openDir(CosmeticsManager.capesDir())),
                new Btn(() -> t("Reload", "تحديث"), () -> {
                    CosmeticsManager.reload();
                    rebuild();
                })));
        sec(t("Outfit (full skin)", "الملابس (سكن كامل)"));
        List<String> outfits = withNone(CosmeticsManager.list(CosmeticsManager.outfitsDir(), false));
        row(t("Outfit", "الملابس"), new Cycle(() -> c.outfit.isEmpty() ? t("None", "بدون") : c.outfit,
                () -> pick(outfits, false, 1), () -> pick(outfits, false, -1)));
        note(t("Put 64x64 skin PNG files in the outfits folder. Add \"slim\" to the file name for slim arms. Only you see it.",
                "ضع ملفات سكن PNG بحجم 64x64 في مجلد الملابس. أضف كلمة slim لاسم الملف للأذرع النحيفة. أنت فقط من يراها."));
        add(new HBox(
                new Btn(() -> t("Choose skin file...", "اختيار ملف سكن..."), this::pickOutfitFile).accent(),
                new Btn(() -> t("Open outfits folder", "فتح مجلد الملابس"), () -> openDir(CosmeticsManager.outfitsDir()))));
        sec(t("Main menu skin", "سكن القائمة الرئيسية"));
        tog(t("Show my skin on the main menu", "اظهار سكني بالقائمة الرئيسية"), () -> c.menuSkinOn, v -> c.menuSkinOn = v);
        String[] sides = {t("Left", "يسار"), t("Right", "يمين")};
        row(t("Side", "الجهة"), new Cycle(() -> sides[c.menuSide], () -> {
            c.menuSide = (c.menuSide + 1) % 2;
            Config.save();
        }, () -> {
            c.menuSide = (c.menuSide + 1) % 2;
            Config.save();
        }));
        List<String> menuSkins = withNone(CosmeticsManager.list(CosmeticsManager.outfitsDir(), false));
        row(t("Menu skin", "سكن القائمة"), new Cycle(() -> c.menuSkin.isEmpty() ? t("Same as outfit", "نفس الملابس") : c.menuSkin, () -> {
            int i = menuSkins.indexOf(c.menuSkin);
            String n = menuSkins.get((i + 1) % menuSkins.size());
            c.menuSkin = n.equals(menuSkins.get(0)) ? "" : n;
            Config.save();
        }, () -> {
            int i = menuSkins.indexOf(c.menuSkin);
            String n = menuSkins.get((i - 1 + menuSkins.size()) % menuSkins.size());
            c.menuSkin = n.equals(menuSkins.get(0)) ? "" : n;
            Config.save();
        }));
        row(t("Link or player name", "رابط أو اسم لاعب"), new TextBox(() -> skinSrc, v -> skinSrc = v, "https://.../skin.png  |  Notch"));
        add(new HBox(
                new Btn(() -> t("Get skin", "جلب السكن"), () -> {
                    String in = skinSrc == null ? "" : skinSrc.trim();
                    skinStatus = t("Downloading...", "جاري التحميل...");
                    java.util.function.Consumer<String> done = name -> mc.execute(() -> {
                        if (name != null) {
                            c.menuSkin = name;
                            Config.save();
                            CosmeticsManager.reload();
                            skinStatus = t("Skin added: ", "تمت إضافة السكن: ") + name;
                        } else {
                            skinStatus = t("Could not get this skin.", "تعذر جلب هذا السكن.");
                        }
                        rebuild();
                    });
                    if (in.startsWith("http")) com.n3dl.cosmetics.SkinFetch.fromUrl(in, in.toLowerCase().contains("slim"), done);
                    else com.n3dl.cosmetics.SkinFetch.fromName(in, done);
                }).accent(),
                new Btn(() -> t("Paste", "لصق"), () -> {
                    skinSrc = mc.keyboardHandler.getClipboard();
                    rebuild();
                })));
        add(new Lbl(() -> skinStatus));
        note(t("Type a Minecraft player name to use their skin, or paste a direct link to a 64x64 skin PNG. You can also put a skin file in the outfits folder. The skin shows as a flat front view on the main menu.",
                "اكتب اسم لاعب ماينكرافت عشان تاخذ سكنه، أو الصق رابط مباشر لصورة سكن PNG بحجم 64x64. وتقدر كمان تحط ملف السكن في مجلد الملابس. السكن يظهر من الأمام على القائمة الرئيسية."));
        row(t("Dropped pictures become", "الصور المسحوبة تصبح"), new Cycle(() -> dropOutfit ? t("Outfit", "ملابس") : t("Cape", "كيب"),
                () -> dropOutfit = !dropOutfit, () -> dropOutfit = !dropOutfit));
        sec(t("Tools & armor look", "شكل الأدوات والدروع"));
        if (LookPacks.available()) {
            tog(t("Neon tools pack (pickaxes, swords, axes...)", "حزمة النيون (بيكاكس، سيوف، فؤوس...)"), LookPacks::isOn, v -> LookPacks.set(v));
        } else {
            note(t("The built-in look pack was not found by this Minecraft version.", "لم يتم العثور على حزمة الشكل المدمجة."));
        }
        note(t("To change armor or other items on your server, enable any resource pack in Options > Resource Packs.",
                "لتغيير شكل الدروع أو أي عناصر أخرى فعّل أي حزمة موارد من الإعدادات > حزم الموارد."));
    }

    private void cycleFit(String[] fits, int d) {
        int i = 0;
        for (int k = 0; k < fits.length; k++) if (fits[k].equals(c.capeFit)) i = k;
        c.capeFit = fits[Math.floorMod(i + d, fits.length)];
        Config.save();
        CosmeticsManager.reload();
    }

    private void pickCapeFile() {
        pickImage(false);
    }

    private void pickOutfitFile() {
        pickImage(true);
    }

    private void pickImage(boolean outfit) {
        status = t("Opening file dialog...", "جاري فتح نافذة الملفات...");
        FilePicker.pick(outfit ? t("Choose a skin", "اختر سكن") : t("Choose a picture or GIF", "اختر صورة أو GIF"), "Images",
                new String[]{"*.png", "*.gif", "*.jpg", "*.jpeg", "*.bmp"}, path -> {
                    if (path == null) {
                        status = t("No file chosen. If no window opened: drag the picture into this menu, or copy it into the folder.",
                                "لم يتم اختيار ملف. إذا لم تظهر نافذة: اسحب الصورة إلى القائمة، أو انسخها إلى المجلد.");
                    } else {
                        String r = outfit ? CosmeticsManager.importOutfit(path) : CosmeticsManager.importCape(path);
                        if (r == null) {
                            status = t("Could not read this picture.", "تعذر قراءة هذه الصورة.");
                        } else {
                            if (outfit) c.outfit = r;
                            else c.cape = r;
                            Config.save();
                            status = t("Added: ", "تمت الإضافة: ") + r;
                        }
                    }
                    rebuild();
                });
    }

    private void pick(List<String> l, boolean cape, int d) {
        String cur = cape ? c.cape : c.outfit;
        int i = Math.max(0, l.indexOf(cur));
        String n = l.get(Math.floorMod(i + d, l.size()));
        if (cape) c.cape = n;
        else c.outfit = n;
        Config.save();
    }

    private static final String[] SLOT_EN = {"Wings", "Headwear", "Bodywear", "Pets", "Companions", "Auras"};
    private static final String[] SLOT_AR = {"أجنحة", "أغطية الرأس", "ملابس الجسم", "حيوانات أليفة", "رفقاء", "هالات"};

    private String cosName(Cosmetic d) {
        return c.ar() ? d.ar : d.en;
    }

    private void pageCosFx() {
        sec(t("3D Cosmetics", "إكسسوارات ثلاثية الأبعاد"));
        tog(t("Show my cosmetics", "إظهار إكسسواراتي"), () -> c.cosEnabled, v -> c.cosEnabled = v);
        tog(t("Physics (sway & motion)", "الفيزياء (تمايل وحركة)"), () -> c.cosPhysics, v -> c.cosPhysics = v);
        tog(t("Show aura & pets in first person", "إظهار الأورا والحيوانات بالمنظور الأول"), () -> c.cosFirstPerson, v -> c.cosFirstPerson = v);
        note(t("Only you see these (client-side). Look at yourself in third person (F5) to see them.",
                "أنت فقط من يراها (على جهازك). انظر لنفسك بالشخص الثالث (F5) لتشاهدها."));
        add(new Btn(() -> t("Look at myself (3rd person)", "شاهد نفسي (شخص ثالث)"), () -> {
            mc.options.setCameraType(net.minecraft.client.CameraType.THIRD_PERSON_FRONT);
            onClose();
        }).accent());

        sec(t("Bundles (full sets)", "الحزم (أطقم كاملة)"));
        List<Designs.Bundle> bl = Designs.bundles();
        if (!bl.isEmpty()) {
            bundleSel = Math.floorMod(bundleSel, bl.size());
            row(t("Bundle", "الحزمة"), new Cycle(() -> {
                Designs.Bundle b = bl.get(Math.floorMod(bundleSel, bl.size()));
                return c.ar() ? b.ar() : b.en();
            }, () -> bundleSel++, () -> bundleSel--));
            add(new Btn(() -> t("Wear this bundle", "البس هذه الحزمة"), () -> applyBundle(bl.get(Math.floorMod(bundleSel, bl.size())))).accent());
        }
        add(new Btn(() -> t("Take everything off", "إزالة الكل"), () -> {
            for (Cosmetic.Slot sl : Cosmetic.Slot.values()) CosmeticsRender.cfgOf(sl).id = "";
            Config.save();
        }));

        sec(t("Pick a category", "اختر الفئة"));
        Cosmetic.Slot[] slots = Cosmetic.Slot.values();
        for (int i = 0; i < slots.length; i += 3) {
            W[] kids = new W[3];
            for (int j = 0; j < 3; j++) {
                if (i + j < slots.length) {
                    Cosmetic.Slot sl = slots[i + j];
                    kids[j] = new Btn(() -> c.ar() ? SLOT_AR[sl.ordinal()] : SLOT_EN[sl.ordinal()], () -> {
                        cosSlot = sl;
                        rebuild();
                    }).hl(() -> cosSlot == sl);
                } else {
                    kids[j] = new Lbl(() -> "");
                }
            }
            add(new HBox(kids));
        }

        Config.CosSlot cfg = CosmeticsRender.cfgOf(cosSlot);
        sec((c.ar() ? SLOT_AR : SLOT_EN)[cosSlot.ordinal()]);
        List<Cosmetic> list = Designs.of(cosSlot);
        List<W> items = new ArrayList<>();
        items.add(new Btn(() -> t("None", "بدون"), () -> {
            cfg.id = "";
            Config.save();
        }).hl(() -> cfg.id == null || cfg.id.isEmpty()));
        for (Cosmetic d : list) {
            items.add(new Btn(() -> cosName(d), () -> {
                cfg.id = d.id;
                Config.save();
            }).hl(() -> d.id.equals(cfg.id)));
        }
        for (int i = 0; i < items.size(); i += 3) {
            W[] kids = new W[3];
            for (int j = 0; j < 3; j++) kids[j] = i + j < items.size() ? items.get(i + j) : new Lbl(() -> "");
            add(new HBox(kids));
        }

        sec(t("Colour & size", "اللون والحجم"));
        String[] modes = {t("Original", "الأصلي"), t("Solid colour", "لون واحد"), t("Gradient", "متدرج"), t("Rainbow", "قوس قزح")};
        row(t("Colour mode", "نمط اللون"), new Cycle(() -> modes[Math.max(0, Math.min(3, cfg.mode))], () -> {
            cfg.mode = (cfg.mode + 1) % 4;
            Config.save();
            rebuild();
        }, () -> {
            cfg.mode = (cfg.mode + 3) % 4;
            Config.save();
            rebuild();
        }));
        if (cfg.mode == 1 || cfg.mode == 2) colorRow(cfg.mode == 2 ? t("Top colour", "اللون العلوي") : t("Colour", "اللون"), () -> cfg.c1, v -> cfg.c1 = v);
        if (cfg.mode == 2) colorRow(t("Bottom colour", "اللون السفلي"), () -> cfg.c2, v -> cfg.c2 = v);
        sld(t("Size", "الحجم"), 0.5f, 2f, 0.05f, () -> cfg.scale, v -> cfg.scale = v, AboScreen::pct);
    }

    private void applyBundle(Designs.Bundle b) {
        c.cosWings.id = b.wings();
        c.cosHead.id = b.head();
        c.cosBody.id = b.body();
        c.cosPet.id = b.pet();
        c.cosComp.id = b.comp();
        c.cosAura.id = b.aura();
        if (!b.cape().isEmpty() && CosmeticsManager.list(CosmeticsManager.capesDir(), true).contains(b.cape())) c.cape = b.cape();
        if (!b.outfit().isEmpty() && CosmeticsManager.list(CosmeticsManager.outfitsDir(), false).contains(b.outfit())) c.outfit = b.outfit();
        c.cosEnabled = true;
        for (Cosmetic.Slot sl : Cosmetic.Slot.values()) {
            Config.CosSlot cs = CosmeticsRender.cfgOf(sl);
            cs.mode = 0;
        }
        Config.save();
        CosmeticsManager.reload();
    }

    private void pageEmotes() {
        sec(t("Emotes & dances", "الرقصات والحركات"));
        note(t("Press an emote to play it, press again to stop. Set a key next to any emote to play it from the game. Only you see it (client-side).",
                "اضغط على الرقصة لتشغيلها، واضغط مرة ثانية لإيقافها. حدد زرا بجانب أي رقصة لتشغيلها من اللعبة. أنت فقط من يراها (على جهازك)."));
        add(new Btn(() -> t("Stop emote", "إيقاف الرقصة"), EmoteManager::stop).accent());
        add(new HBox(
                new Btn(() -> t("Random emote", "رقصة عشوائية"), () -> {
                    EmoteManager.random();
                    onClose();
                })));
        tog(t("Stop when I move", "إيقاف عند الحركة"), () -> c.emoteStopOnMove, v -> c.emoteStopOnMove = v);
        tog(t("Auto third-person camera", "كاميرا شخص ثالث تلقائيا"), () -> c.emoteThirdPerson, v -> c.emoteThirdPerson = v);
        sld(t("Speed", "السرعة"), 0.5f, 2f, 0.05f, () -> c.emoteSpeed, v -> c.emoteSpeed = v, AboScreen::pct);
        sec(t("Emote list", "قائمة الرقصات"));
        for (Emotes.Emote e : Emotes.all()) {
            add(new HBox(
                    new Btn(() -> c.ar() ? e.ar() : e.en(), () -> {
                        EmoteManager.toggle(e.id());
                        onClose();
                    }).hl(() -> EmoteManager.current() != null && EmoteManager.current().id().equals(e.id())),
                    sized(new KeyBtn(() -> c.emoteKeys.getOrDefault(e.id(), -1), k -> c.emoteKeys.put(e.id(), k), null), 100)));
        }
    }

    private void pageMusic() {
        if (browseMusic && browseTarget != null) {
            pageBrowser();
            return;
        }
        sec(t("Music player", "مشغّل الموسيقى"));
        add(new Lbl(() -> {
            String n = com.n3dl.audio.MusicPlayer.nowPlaying();
            if (n.isEmpty()) return t("Nothing playing", "لا شيء يعمل");
            long sec = com.n3dl.audio.MusicPlayer.positionSeconds();
            String st = com.n3dl.audio.MusicPlayer.isPlaying()
                    ? (com.n3dl.audio.MusicPlayer.isPaused() ? t("Paused", "متوقف مؤقتا") : t("Playing", "يعمل")) : t("Stopped", "متوقف");
            return st + ": " + n + String.format("  %d:%02d", sec / 60, sec % 60);
        }));
        add(new HBox(
                new Btn(() -> t("Prev", "السابق"), com.n3dl.audio.MusicPlayer::prev),
                new Btn(() -> com.n3dl.audio.MusicPlayer.isPlaying() && !com.n3dl.audio.MusicPlayer.isPaused()
                        ? t("Pause", "إيقاف مؤقت") : t("Play", "تشغيل"), com.n3dl.audio.MusicPlayer::togglePause).accent(),
                new Btn(() -> t("Stop", "إيقاف"), com.n3dl.audio.MusicPlayer::stop),
                new Btn(() -> t("Next", "التالي"), com.n3dl.audio.MusicPlayer::next)));
        sld(t("Music volume", "مستوى الموسيقى"), 0f, 2f, 0.05f, () -> c.musicVolume, v -> c.musicVolume = v, AboScreen::pct);
        add(new Lbl(() -> com.n3dl.audio.MusicPlayer.status().isEmpty() ? musicStatus : com.n3dl.audio.MusicPlayer.status()));
        note(t("Songs play one after another. When the last one ends the first one starts again (with one song it repeats). Each song can be up to 2 hours. Music only starts when you press Play, and it plays in the background without lagging the game.",
                "الأغاني تشتغل ورا بعض. لما تخلص آخر أغنية ترجع الأولى (ولو فيه أغنية وحدة تنعاد). كل أغنية لين ساعتين. الموسيقى ما تشتغل إلا لما تضغط تشغيل، وتشتغل بالخلفية بدون ما تلاغي اللعبة."));

        sec(t("Add a song", "إضافة أغنية"));
        add(new HBox(
                new Btn(() -> t("Browse files (phone)", "تصفح الملفات (جوال)"), () -> {
                    browseMusic = true;
                    openBrowser(new Config.SoundCfg(false, ""), false);
                }).accent(),
                new Btn(() -> t("Choose file... (PC)", "اختيار ملف... (كمبيوتر)"), () -> FilePicker.pick(
                        t("Choose a song (mp3, ogg, wav)", "اختر أغنية (mp3, ogg, wav)"), "Audio",
                        new String[]{"*.mp3", "*.ogg", "*.wav"}, path -> {
                            if (path != null) {
                                String a = com.n3dl.audio.MusicPlayer.addFile(path);
                                musicStatus = a != null ? t("Song added: ", "تمت إضافة الأغنية: ") + a
                                        : t("Could not use this file.", "تعذر استخدام هذا الملف.");
                            }
                            rebuild();
                        }))));
        row(t("Direct link", "رابط مباشر"), new TextBox(() -> musicUrl, v -> musicUrl = v, "https://.../song.mp3"));
        add(new HBox(
                new Btn(() -> t("Download from link", "تحميل من الرابط"), () -> {
                    String u = musicUrl == null ? "" : musicUrl.trim();
                    musicStatus = t("Downloading...", "جاري التحميل...");
                    com.n3dl.audio.MusicPlayer.addUrl(u, name -> mc.execute(() -> {
                        musicStatus = name != null ? t("Song added: ", "تمت إضافة الأغنية: ") + name
                                : t("Download failed. Use a direct link to an mp3 / ogg / wav file.", "فشل التحميل. استخدم رابط مباشر لملف mp3 / ogg / wav.");
                        rebuild();
                    }));
                }),
                new Btn(() -> t("Paste link", "لصق الرابط"), () -> {
                    musicUrl = mc.keyboardHandler.getClipboard();
                    rebuild();
                }),
                new Btn(() -> t("Open music folder", "فتح مجلد الموسيقى"), () -> openDir(com.n3dl.audio.MusicPlayer.dir()))));
        note(t("On a phone: if no file window opens use \"Browse files (phone)\" (it is inside the game), or copy the songs into the folder config/n3dl/music. Links must point straight to an audio file (YouTube / Spotify links cannot be played).",
                "في الجوال: لو ما طلعت نافذة الملفات استخدم \"تصفح الملفات (جوال)\" (داخل اللعبة نفسها)، أو انسخ الأغاني لمجلد config/n3dl/music. الرابط لازم يكون مباشر لملف صوت (روابط يوتيوب وسبوتيفاي ما تشتغل)."));

        sec(t("Playlist", "قائمة التشغيل"));
        List<String> list = com.n3dl.audio.MusicPlayer.tracks();
        if (list.isEmpty()) note(t("No songs yet.", "لا توجد أغاني بعد."));
        for (String nm : list) {
            add(new HBox(
                    new Btn(() -> (nm.equals(com.n3dl.audio.MusicPlayer.nowPlaying()) && com.n3dl.audio.MusicPlayer.isPlaying() ? "> " : "") + nm,
                            () -> com.n3dl.audio.MusicPlayer.play(nm)),
                    sized(new Btn(() -> "x", () -> {
                        com.n3dl.audio.MusicPlayer.delete(nm);
                        rebuild();
                    }), 28)));
        }
    }


    private void pageStyle() {
        sec(t("Layout", "شكل القائمة"));
        String[] ids = {"WINDOW", "FULLSCREEN", "SIDEBAR", "COMPACT"};
        String[] names = {t("Window (movable)", "نافذة (تتحرك)"), t("Full screen", "ملء الشاشة"), t("Side panel", "قائمة جانبية"), t("Small compact", "صغيرة")};
        row(t("Layout", "الشكل"), new Cycle(() -> {
            for (int i = 0; i < ids.length; i++) if (ids[i].equals(c.layout)) return names[i];
            return names[0];
        }, () -> cycleLayout(ids, 1), () -> cycleLayout(ids, -1)));
        row(t("Menu size", "حجم القائمة"), new Slider(0.6f, 2f, 0.05f, () -> c.panelScale, v -> c.panelScale = v, AboScreen::pct).deferred());
        sld(t("Text size", "حجم الكتابة"), 0.7f, 2f, 0.05f, () -> c.textScale, v -> c.textScale = v, AboScreen::pct);
        sld(t("Window width", "عرض النافذة"), 300f, 800f, 10f, () -> (float) c.panelW, v -> c.panelW = Math.round(v), v -> Math.round(v) + "");
        sld(t("Window height", "ارتفاع النافذة"), 200f, 600f, 10f, () -> (float) c.panelH, v -> c.panelH = Math.round(v), v -> Math.round(v) + "");
        sld(t("Opacity", "الشفافية"), 0.3f, 1f, 0.02f, () -> c.opacity, v -> c.opacity = v, AboScreen::pct);
        tog(t("Rounded corners", "زوايا مدورة"), () -> c.round, v -> c.round = v);
        add(new Btn(() -> t("Reset window position", "إعادة موضع النافذة"), () -> {
            c.panelX = -1;
            c.panelY = -1;
            Config.save();
        }));
        sec(t("Gradient", "التدرج"));
        tog(t("Gradient colours", "ألوان متدرجة"), () -> c.gradient, v -> {
            c.gradient = v;
            rebuild();
        });
        if (c.gradient) {
            row(t("Direction", "الاتجاه"), new Cycle(() -> c.gradDir == 1 ? t("Horizontal", "أفقي") : t("Vertical", "عمودي"),
                    () -> {
                        c.gradDir = 1 - c.gradDir;
                        Config.save();
                    }, () -> {
                        c.gradDir = 1 - c.gradDir;
                        Config.save();
                    }));
            tog(t("Animated gradient", "تدرج متحرك"), () -> c.gradAnim, v -> c.gradAnim = v);
            colorRow(t("Panel - second colour", "اللوحة - اللون الثاني"), () -> c.cPanel2, v -> c.cPanel2 = v);
            colorRow(t("Header - second colour", "الشريط - اللون الثاني"), () -> c.cHeader2, v -> c.cHeader2 = v);
            colorRow(t("Buttons - second colour", "الأزرار - اللون الثاني"), () -> c.cButton2, v -> c.cButton2 = v);
            colorRow(t("Accent - second colour", "التمييز - اللون الثاني"), () -> c.cAccent2, v -> c.cAccent2 = v);
            note(t("The first colours are in the Colours section below.", "الألوان الأولى في قسم الألوان بالأسفل."));
        }
        sec(t("Colours", "الألوان"));
        row(t("Preset", "نمط جاهز"), new Cycle(() -> Theme.display(Theme.index(c.theme)),
                () -> applyTheme(1), () -> applyTheme(-1)));
        colorRow(t("Accent (buttons, highlights)", "لون التمييز"), () -> c.cAccent, v -> c.cAccent = v);
        colorRow(t("Text", "لون الكتابة"), () -> c.cText, v -> c.cText = v);
        colorRow(t("Panel", "لون اللوحة"), () -> c.cPanel, v -> c.cPanel = v);
        colorRow(t("Header", "لون الشريط العلوي"), () -> c.cHeader, v -> c.cHeader = v);
        colorRow(t("Buttons", "لون الأزرار"), () -> c.cButton, v -> c.cButton = v);
        colorRow(t("Background", "لون الخلفية"), () -> c.cBg, v -> c.cBg = v);
    }

    private void colorRow(String label, IntSupplier g, IntConsumer s) {
        add(new Lbl(() -> label));
        add(new ColorBox(g, s));
    }

    private void applyTheme(int d) {
        Theme.apply(c, Theme.index(c.theme) + d);
        Config.save();
    }

    private void cycleLayout(String[] ids, int d) {
        int i = 0;
        for (int k = 0; k < ids.length; k++) if (ids[k].equals(c.layout)) i = k;
        c.layout = ids[Math.floorMod(i + d, ids.length)];
        Config.save();
        rebuild();
    }

    private void pageExtras() {
        sec(t("Look & F3", "الشكل و F3"));
        tog(t("Animated shard background", "خلفية الشظايا المتحركة"), () -> c.shardBg, v -> c.shardBg = v);
        tog(t("Fake RTX 5090 on F3 screen", "كرت RTX 5090 وهمي في F3"), () -> c.fakeGpu, v -> c.fakeGpu = v);
        sec(t("Info on screen", "معلومات على الشاشة"));
        tog(t("Show info panel", "إظهار لوحة المعلومات"), () -> c.infoHud, v -> c.infoHud = v);
        tog("FPS", () -> c.infoFps, v -> c.infoFps = v);
        tog(t("Coordinates", "الإحداثيات"), () -> c.infoXyz, v -> c.infoXyz = v);
        tog(t("Facing direction", "الاتجاه"), () -> c.infoFacing, v -> c.infoFacing = v);
        tog("Ping", () -> c.infoPing, v -> c.infoPing = v);
        tog("CPS", () -> c.infoCps, v -> c.infoCps = v);
        tog(t("Clock", "الساعة"), () -> c.infoTime, v -> c.infoTime = v);
        String[] corners = {t("Top left", "أعلى اليسار"), t("Top right", "أعلى اليمين"), t("Bottom left", "أسفل اليسار"), t("Bottom right", "أسفل اليمين")};
        row(t("Position", "الموضع"), new Cycle(() -> corners[c.infoCorner], () -> c.infoCorner = (c.infoCorner + 1) % 4,
                () -> c.infoCorner = (c.infoCorner + 3) % 4));
        sec(t("Zoom", "التقريب"));
        tog(t("Zoom enabled (hold the zoom key)", "تفعيل التقريب (اضغط باستمرار)"), () -> c.zoomEnabled, v -> c.zoomEnabled = v);
        sld(t("Zoom field of view", "زاوية التقريب"), 10f, 80f, 1f, () -> (float) c.zoomFov, v -> c.zoomFov = Math.round(v), v -> Math.round(v) + "");
        sec(t("Voice chat link", "ربط الفويس شات"));
        note(Actions.voiceInstalled()
                ? t("Simple Voice Chat detected. Use the actions below as keybinds (page Keybinds > + action). The voice chat key must be bound in its own settings.",
                "تم العثور على Simple Voice Chat. يمكنك استخدام الإجراءات أدناه كأزرار (صفحة الأزرار > + إجراء). يجب ربط زر الفويس شات في إعداداته أولاً.")
                : t("Simple Voice Chat is not installed. Install it to control the microphone from 3DL ABO ZAHRA keybinds.",
                "مود Simple Voice Chat غير مثبت. ثبّته لتتحكم بالمايك من أزرار 3DL ABO ZAHRA."));
        add(new HBox(
                new Btn(() -> t("Mute mic", "كتم المايك"), () -> Actions.exec("@voice_mute")),
                new Btn(() -> t("Disable voice", "تعطيل الصوت"), () -> Actions.exec("@voice_disable")),
                new Btn(() -> t("Hide icons", "إخفاء الأيقونات"), () -> Actions.exec("@voice_hide"))));
        sec(t("About", "حول"));
        note("3DL ABO ZAHRA 1.0.0 — Minecraft 1.21.11 Fabric");
    }

    // ================================================================== layout & drawing

    private void layoutPanel() {
        ps = Math.max(0.6f, Math.min(2f, c.panelScale));
        lw = Math.max(200, (int) (width / ps));
        lh = Math.max(150, (int) (height / ps));
        switch (c.layout) {
            case "FULLSCREEN" -> {
                px = 0;
                py = 0;
                pw = lw;
                ph = lh;
            }
            case "SIDEBAR" -> {
                pw = Math.min(310, lw);
                ph = lh;
                px = rtl() ? lw - pw : 0;
                py = 0;
            }
            case "COMPACT" -> {
                pw = Math.min(300, lw - 8);
                ph = Math.min(210, lh - 8);
                px = c.panelX >= 0 ? c.panelX : (lw - pw) / 2;
                py = c.panelY >= 0 ? c.panelY : (lh - ph) / 2;
            }
            default -> {
                pw = Math.max(260, Math.min(c.panelW, lw - 8));
                ph = Math.max(180, Math.min(c.panelH, lh - 8));
                px = c.panelX >= 0 ? c.panelX : (lw - pw) / 2;
                py = c.panelY >= 0 ? c.panelY : (lh - ph) / 2;
            }
        }
        px = Math.max(0, Math.min(px, lw - pw));
        py = Math.max(0, Math.min(py, lh - ph));
        hh = fh() + 10;
        String[] names = pageNames();
        int m = 0;
        for (String n : names) m = Math.max(m, tw(n));
        nw = Math.min(m + 16, pw / 3);
        bx = rtl() ? px : px + nw;
        by = py + hh;
        bw = pw - nw;
        bh = ph - hh;
    }

    private int navIh(int n) {
        int fit = (ph - hh - 8) / Math.max(1, n) - 2;
        return Math.max(fh() + 2, Math.min(rh() + 4, fit));
    }

    private int contentLeft() {
        return bx + PAD + (rtl() ? SB + 2 : 0);
    }

    @Override
    protected void init() {
        rebuild();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        for (W w : ws) {
            if (w instanceof TextBox tb) tb.blur();
        }
        lastPage = page;
        Config.save();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float pt) {
        layoutPanel();
        cwid = Math.max(80, bw - 2 * PAD - SB - 2);
        if (!key().equals(builtKey)) rebuild();
        if (c.shardBg) ShardBg.render(g, width, height, true);
        else g.fill(0, 0, width, height, 0x99000000);
        var p = g.pose();
        p.pushMatrix();
        p.scale(ps, ps);
        int mx = (int) (mouseX / ps), my = (int) (mouseY / ps);

        // panel + header
        rfill(g, px - 1, py - 1, pw + 2, ph + 2, Theme.argb(c.cAccent, 0.9f));
        grad(g, px, py, pw, ph, c.cPanel, c.cPanel2, c.opacity);
        grad(g, px, py, pw, hh, c.cHeader, c.cHeader2, Math.min(1f, c.opacity + 0.05f));
        String title = "3DL ABO ZAHRA";
        txt(g, title, rtl() ? px + pw - tw(title) - 8 : px + 8, py + (hh - fh()) / 2, cAcc());
        int cs = hh - 6;
        int cx = rtl() ? px + 3 : px + pw - cs - 3;
        boolean hvClose = mx >= cx && mx < cx + cs && my >= py + 3 && my < py + 3 + cs;
        rfill(g, cx, py + 3, cs, cs, hvClose ? 0xFFD03A3A : cBtn(false));
        txtCenter(g, "x", cx, cs, py + 3 + (cs - fh()) / 2, 0xFFFFFFFF);

        // navigation
        String[] names = pageNames();
        int navX = rtl() ? px + pw - nw : px;
        g.fill(navX, by, navX + nw, py + ph, Theme.argb(c.cBg, 0.5f));
        int ih = navIh(names.length);
        for (int i = 0; i < names.length; i++) {
            int iy = by + 4 + i * (ih + 2);
            boolean sel = i == page;
            boolean hv = mx >= navX && mx < navX + nw && my >= iy && my < iy + ih;
            if (sel) grad(g, navX + 3, iy, nw - 6, ih, c.cAccent, c.cAccent2, 1f);
            else if (hv) rfill(g, navX + 3, iy, nw - 6, ih, Theme.argb(c.cButton, 0.9f));
            txtCenter(g, names[i], navX, nw, iy + (ih - fh()) / 2, sel ? onColor(c.cAccent) : cText());
        }

        // body
        int cl = contentLeft();
        int top = by + PAD;
        g.enableScissor(bx, by, bx + bw, by + bh);
        p.pushMatrix();
        p.translate(cl, top - scroll);
        int lmx = mx - cl, lmy = my - top + scroll;
        boolean inBody = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        for (W w : ws) {
            if (w.y + w.h < scroll - PAD || w.y > scroll + bh) continue;
            w.draw(g, inBody ? lmx : -9999, inBody ? lmy : -9999);
        }
        p.popMatrix();
        g.disableScissor();

        // scrollbar
        if (contentH > bh) {
            int tx = rtl() ? bx + 2 : bx + bw - SB - 2;
            g.fill(tx, by + 2, tx + SB, by + bh - 2, Theme.argb(c.cBg, 0.7f));
            int thumb = Math.max(18, (int) ((long) bh * bh / contentH));
            int ty = by + 2 + (int) ((bh - 4 - thumb) * (scroll / (float) (contentH - bh)));
            rfill(g, tx, ty, SB, thumb, draggingBar ? 0xFFFFFFFF : cAcc());
        }

        // resize grip
        if ("WINDOW".equals(c.layout)) {
            int gx = px + pw - 10, gy = py + ph - 10;
            g.fill(gx + 2, gy + 8, gx + 9, gy + 9, Theme.argb(c.cText, 0.5f));
            g.fill(gx + 5, gy + 5, gx + 9, gy + 6, Theme.argb(c.cText, 0.5f));
            g.fill(gx + 8, gy + 2, gx + 9, gy + 9, Theme.argb(c.cText, 0.5f));
        }
        p.popMatrix();
    }

    // ================================================================== input

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        int mx = (int) (e.x() / ps), my = (int) (e.y() / ps);
        int b = e.button();

        if (capturing != null) {
            KeyBtn kb = capturing;
            capturing = null;
            if (b == 1) kb.apply(-1);
            else if (b >= 2) kb.apply(1000 + b);
            return true;
        }
        if (focus instanceof TextBox tb) {
            tb.blur();
        }
        focus = null;

        // header
        if (my >= py && my < py + hh && mx >= px && mx < px + pw) {
            int cs = hh - 6;
            int cx = rtl() ? px + 3 : px + pw - cs - 3;
            if (mx >= cx && mx < cx + cs) {
                onClose();
                return true;
            }
            if ("WINDOW".equals(c.layout) || "COMPACT".equals(c.layout)) {
                draggingPanel = true;
                dragDX = mx - px;
                dragDY = my - py;
                return true;
            }
            return true;
        }
        // resize
        if ("WINDOW".equals(c.layout) && mx >= px + pw - 12 && mx < px + pw + 2 && my >= py + ph - 12 && my < py + ph + 2) {
            resizing = true;
            return true;
        }
        // navigation
        String[] names = pageNames();
        int navX = rtl() ? px + pw - nw : px;
        int ih = navIh(names.length);
        if (mx >= navX && mx < navX + nw) {
            for (int i = 0; i < names.length; i++) {
                int iy = by + 4 + i * (ih + 2);
                if (my >= iy && my < iy + ih) {
                    page = i;
                    scroll = 0;
                    rebuild();
                    return true;
                }
            }
        }
        // scrollbar
        if (contentH > bh) {
            int tx = rtl() ? bx + 2 : bx + bw - SB - 2;
            if (mx >= tx - 3 && mx < tx + SB + 3 && my >= by && my < by + bh) {
                draggingBar = true;
                dragBar(my);
                return true;
            }
        }
        // body widgets
        if (mx >= bx && mx < bx + bw && my >= by && my < by + bh) {
            int lmx = mx - contentLeft(), lmy = my - (by + PAD) + scroll;
            for (int i = ws.size() - 1; i >= 0; i--) {
                if (ws.get(i).click(lmx, lmy, b)) return true;
            }
        }
        return true;
    }

    private void dragBar(int my) {
        int thumb = Math.max(18, (int) ((long) bh * bh / contentH));
        float t = (my - by - thumb / 2f) / Math.max(1f, bh - thumb);
        scroll = Math.max(0, Math.min(contentH - bh, Math.round(t * (contentH - bh))));
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        int mx = (int) (e.x() / ps), my = (int) (e.y() / ps);
        if (draggingPanel) {
            c.panelX = Math.max(0, Math.min(lw - pw, mx - dragDX));
            c.panelY = Math.max(0, Math.min(lh - ph, my - dragDY));
            return true;
        }
        if (resizing) {
            c.panelW = Math.max(300, Math.min(900, mx - px));
            c.panelH = Math.max(200, Math.min(700, my - py));
            return true;
        }
        if (draggingBar) {
            dragBar(my);
            return true;
        }
        if (dragW != null) {
            dragW.drag(mx - contentLeft(), my - (by + PAD) + scroll);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        if (dragW != null) {
            dragW.release();
            dragW = null;
        }
        draggingPanel = false;
        resizing = false;
        draggingBar = false;
        Config.save();
        return true;
    }

    @Override
    public boolean mouseScrolled(double x, double y, double sx, double sy) {
        int mx = (int) (x / ps), my = (int) (y / ps);
        if (mx >= bx && mx < bx + bw && my >= by && my < by + bh && focus == null) {
            int lmx = mx - contentLeft(), lmy = my - (by + PAD) + scroll;
            for (int i = ws.size() - 1; i >= 0; i--) {
                W u = ws.get(i).under(lmx, lmy);
                if (u != null) {
                    if (u.wheel(sy > 0 ? 1 : -1)) return true;
                    break;
                }
            }
        }
        scroll = Math.max(0, Math.min(Math.max(0, contentH - bh), scroll - (int) (sy * 24)));
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (capturing != null) {
            KeyBtn kb = capturing;
            capturing = null;
            if (k != 256) kb.apply(k); // Esc cancels
            return true;
        }
        if (focus != null) {
            if (k == 256) {
                if (focus instanceof TextBox tb) tb.blur();
                focus = null;
                Config.save();
                return true;
            }
            focus.key(k, e.modifiers());
            return true;
        }
        if (k == AboClient.boundKey(AboClient.OPEN)) {
            onClose();
            return true;
        }
        int max = Math.max(0, contentH - bh);
        switch (k) {
            case 265 -> scroll = Math.max(0, scroll - 24);          // up
            case 264 -> scroll = Math.min(max, scroll + 24);        // down
            case 266 -> scroll = Math.max(0, scroll - bh + 20);     // page up
            case 267 -> scroll = Math.min(max, scroll + bh - 20);   // page down
            case 268 -> scroll = 0;                                 // home
            case 269 -> scroll = max;                               // end
            case 258 -> {                                           // tab / shift+tab: next / previous page
                int n = pageNames().length;
                page = Math.floorMod(page + ((e.modifiers() & 1) != 0 ? -1 : 1), n);
                scroll = 0;
                rebuild();
            }
            default -> {
                return super.keyPressed(e);
            }
        }
        return true;
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (focus != null) {
            return focus.chr(new String(Character.toChars(e.codepoint())));
        }
        return false;
    }
}
