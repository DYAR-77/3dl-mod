package com.n3dl.gui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;

/** A plain player-name list shown while TAB is held, used when the real tab list is hidden. */
public final class NamesTab {
    private NamesTab() {
    }

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) return;
        if (!mc.options.keyPlayerList.isDown()) return;
        List<String> names = new ArrayList<>();
        for (PlayerInfo pi : mc.getConnection().getOnlinePlayers()) {
            String n = pi.getProfile().name();
            if (n != null && !n.isEmpty()) names.add(n);
        }
        if (names.isEmpty()) return;
        names.sort(String.CASE_INSENSITIVE_ORDER);
        int sw = mc.getWindow().getGuiScaledWidth();
        int perCol = 20;
        int cols = Math.max(1, (names.size() + perCol - 1) / perCol);
        int rows = Math.min(perCol, names.size());
        int cw = 0;
        for (String n : names) cw = Math.max(cw, mc.font.width(n));
        cw += 10;
        int boxW = cols * cw;
        int x0 = (sw - boxW) / 2;
        int y0 = 10;
        g.fill(x0 - 2, y0 - 2, x0 + boxW + 2, y0 + rows * 10 + 2, 0x80000000);
        for (int i = 0; i < names.size(); i++) {
            int col = i / perCol, row = i % perCol;
            int x = x0 + col * cw + (cw - mc.font.width(names.get(i))) / 2;
            g.drawString(mc.font, names.get(i), x, y0 + row * 10, 0xFFFFFFFF, true);
        }
    }
}
