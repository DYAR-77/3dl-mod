package com.n3dl.gui;

import java.util.Random;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Animated purple crystal-shard background. Everything is drawn with flat fills (scanlines), so it needs no textures
 * and costs very little: about a dozen shards plus a few soft glows.
 */
public final class ShardBg {
    private ShardBg() {
    }

    private static final int N = 13;
    private static final float[] CX = new float[N], CY = new float[N], LEN = new float[N], WID = new float[N],
            ANG = new float[N], SPIN = new float[N], ORB = new float[N], PH = new float[N], SK = new float[N];
    private static final long T0 = System.nanoTime();

    static {
        Random r = new Random(30303);
        for (int i = 0; i < N; i++) {
            CX[i] = r.nextFloat();
            CY[i] = r.nextFloat();
            LEN[i] = 0.10f + r.nextFloat() * 0.22f;
            WID[i] = 0.30f + r.nextFloat() * 0.25f;
            ANG[i] = r.nextFloat() * 6.2832f;
            SPIN[i] = (r.nextFloat() - 0.5f) * 0.35f;
            ORB[i] = 0.01f + r.nextFloat() * 0.035f;
            PH[i] = r.nextFloat() * 6.2832f;
            SK[i] = 0.25f + r.nextFloat() * 0.5f;
        }
    }

    private static int argb(int a, int r, int g, int b) {
        return (Math.max(0, Math.min(255, a)) << 24) | (Math.max(0, Math.min(255, r)) << 16)
                | (Math.max(0, Math.min(255, g)) << 8) | Math.max(0, Math.min(255, b));
    }

    /** Purple ramp: k 0..1 goes from deep violet to near white. */
    private static int tone(float k, int a) {
        k = Math.max(0f, Math.min(1f, k));
        int r, g, b;
        if (k < 0.6f) {
            float u = k / 0.6f;
            r = (int) (40 + u * 110);
            g = (int) (10 + u * 40);
            b = (int) (110 + u * 130);
        } else {
            float u = (k - 0.6f) / 0.4f;
            r = (int) (150 + u * 90);
            g = (int) (50 + u * 150);
            b = (int) (240 + u * 15);
        }
        return argb(a, r, g, b);
    }

    public static void render(GuiGraphics g, int w, int h, boolean dim) {
        float t = (System.nanoTime() - T0) / 1.0e9f;
        // base: dark grey to deep violet
        g.fillGradient(0, 0, w, h, 0xFF17151f, 0xFF0e0a1c);
        // soft glows (concentric translucent discs)
        glow(g, w * (0.88f + 0.04f * (float) Math.sin(t * 0.21f)), h * (0.10f + 0.04f * (float) Math.cos(t * 0.17f)), Math.max(w, h) * 0.55f, 120, 40, 230);
        glow(g, w * (0.08f + 0.04f * (float) Math.cos(t * 0.19f)), h * (0.92f + 0.03f * (float) Math.sin(t * 0.23f)), Math.max(w, h) * 0.45f, 100, 30, 200);
        int step = Math.max(2, Math.round(Math.max(w, h) / 420f));
        float m = Math.min(w, h);
        for (int i = 0; i < N; i++) {
            float ox = (float) Math.cos(t * ORB[i] * 6f + PH[i]) * 0.05f;
            float oy = (float) Math.sin(t * ORB[i] * 5f + PH[i] * 1.7f) * 0.05f;
            float cx = (CX[i] + ox) * w, cy = (CY[i] + oy) * h;
            float a = ANG[i] + t * SPIN[i];
            float len = LEN[i] * m * (1f + 0.06f * (float) Math.sin(t * 0.7f + PH[i]));
            float wid = WID[i] * len;
            float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
            // kite: tip A, side P, tail B, side Q
            float ax = cx + ca * len, ay = cy + sa * len;
            float bx = cx - ca * len * 0.7f, by = cy - sa * len * 0.7f;
            float px = cx - ca * len * (SK[i] - 0.2f) - sa * wid, py = cy - sa * len * (SK[i] - 0.2f) + ca * wid;
            float qx = cx - ca * len * (SK[i] - 0.2f) + sa * wid, qy = cy - sa * len * (SK[i] - 0.2f) - ca * wid;
            float sh = 0.5f + 0.5f * (float) Math.sin(t * 1.3f + PH[i]);
            int al = dim ? 215 : 255;
            tri(g, w, h, step, ax, ay, px, py, qx, qy, tone(0.35f + 0.5f * sh, al));
            tri(g, w, h, step, bx, by, px, py, qx, qy, tone(0.12f + 0.35f * (1f - sh), al));
            // bright sliver facet that moves along the shard
            float mx = (px + qx) * 0.5f, my = (py + qy) * 0.5f;
            tri(g, w, h, step, ax, ay, px, py, mx, my, tone(0.55f + 0.45f * (float) Math.abs(Math.sin(t * 0.9f + PH[i] * 2f)), (int) (al * 0.8f)));
        }
        // thin drifting streaks
        for (int i = 0; i < 7; i++) {
            float ph = PH[i] * 3f;
            float x0 = ((CX[i] + t * 0.004f * (i + 1)) % 1.2f - 0.1f) * w;
            float y0 = ((CY[(i + 3) % N] + t * 0.003f * (i + 2)) % 1.2f - 0.1f) * h;
            float a = 0.8f + (i % 3) * 0.6f + 0.1f * (float) Math.sin(t * 0.3f + ph);
            float L = (0.18f + 0.04f * i) * m;
            float dx = (float) Math.cos(a), dy = (float) Math.sin(a);
            tri(g, w, h, step, x0, y0, x0 + dx * L - dy * 1.5f, y0 + dy * L + dx * 1.5f, x0 + dx * L + dy * 1.5f, y0 + dy * L - dx * 1.5f,
                    argb(70, 190, 150, 255));
        }
        if (dim) g.fill(0, 0, w, h, 0x40000000);
    }

    private static void glow(GuiGraphics g, float cx, float cy, float rad, int r, int gr, int b) {
        for (int ring = 0; ring < 6; ring++) {
            float rr = rad * (1f - ring / 6f);
            int a = 10;
            int y0 = (int) Math.max(0, cy - rr), y1 = (int) (cy + rr);
            for (int y = y0; y < y1; y += 4) {
                float dy = y - cy;
                float s = rr * rr - dy * dy;
                if (s <= 0) continue;
                float dx = (float) Math.sqrt(s);
                int xl = (int) Math.max(0, cx - dx), xr = (int) (cx + dx);
                if (xr > xl) g.fill(xl, y, xr, y + 4, argb(a, r, gr, b));
            }
        }
    }

    /** Fills a triangle with horizontal strips, clipped to the screen. */
    private static void tri(GuiGraphics g, int w, int h, int step, float x1, float y1, float x2, float y2, float x3, float y3, int col) {
        float ymin = Math.min(y1, Math.min(y2, y3)), ymax = Math.max(y1, Math.max(y2, y3));
        int ys = (int) Math.max(0, Math.floor(ymin)), ye = (int) Math.min(h, Math.ceil(ymax));
        for (int y = ys; y < ye; y += step) {
            float yc = y + step * 0.5f;
            float lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
            float[] ex = {x1, x2, x3, x1};
            float[] ey = {y1, y2, y3, y1};
            for (int e = 0; e < 3; e++) {
                float ya = ey[e], yb = ey[e + 1];
                if ((yc >= ya && yc < yb) || (yc >= yb && yc < ya)) {
                    float u = (yc - ya) / (yb - ya);
                    float x = ex[e] + u * (ex[e + 1] - ex[e]);
                    if (x < lo) lo = x;
                    if (x > hi) hi = x;
                }
            }
            if (hi <= lo) continue;
            int xl = (int) Math.max(0, Math.floor(lo)), xr = (int) Math.min(w, Math.ceil(hi));
            if (xr > xl) g.fill(xl, y, xr, Math.min(h, y + step), col);
        }
    }
}
