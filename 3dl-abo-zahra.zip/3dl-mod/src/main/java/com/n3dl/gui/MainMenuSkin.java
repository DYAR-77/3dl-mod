package com.n3dl.gui;

import com.n3dl.core.Config;
import com.n3dl.cosmetics.CosmeticsManager;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/**
 * Shows your skin on the main menu (left or right side) with a button under it that opens the cosmetics menu.
 * The skin is a flat front view of the skin texture (so no 3D model is needed on the title screen).
 */
public final class MainMenuSkin {
    private MainMenuSkin() {
    }

    private static int scale(int h) {
        return Math.max(2, Math.min(5, (h - 90) / 34));
    }

    private static float yaw = 25f;
    private static boolean dragging, wasDown;
    private static int lastMx;
    private static long lastNs = System.nanoTime();

    public static void init() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof TitleScreen)) return;
            Config c = Config.get();
            if (!c.enabled || !c.menuSkinOn) return;
            int cx = centerX(w, c);
            int S = scale(h);
            int top = Math.max(8, h / 2 - 12 * S - 8);
            int bx = cx - 50;
            int by = top + 32 * S + 14;
            Screens.getButtons(screen).add(Button.builder(Component.literal(c.lang.equals("ar") ? "الإكسسوارات" : "Cosmetics"),
                    b -> AboScreen.openCosmetics()).bounds(bx, by, 100, 20).build());
            Screens.getButtons(screen).add(Button.builder(Component.literal(c.menuSide == 0 ? ">" : "<"), b -> {
                c.menuSide = c.menuSide == 0 ? 1 : 0;
                Config.save();
                Minecraft mc = Minecraft.getInstance();
                mc.setScreen(new TitleScreen());
            }).bounds(bx + 104, by, 20, 20).build());
            ScreenEvents.afterRender(screen).register((s, g, mx, my, dt) -> draw(g, s.width, s.height, mx, my));
        });
    }

    private static int centerX(int w, Config c) {
        int margin = Math.max(40, Math.min(w / 6, 90));
        return c.menuSide == 0 ? margin : w - margin;
    }

    private static void blit(GuiGraphics g, Identifier tex, int dx, int dy, int dw, int dh, float u, float v, int rw, int rh, int tw, int th) {
        g.blit(RenderPipelines.GUI_TEXTURED, tex, dx, dy, u, v, dw, dh, rw, rh, tw, th);
    }

    /** One face: its two horizontal screen edges, top y and height, plus the texture rectangle. */
    private static void face(GuiGraphics g, Identifier tp, int tw, int th, float k, float xs0, float xs1, int dy, int dh,
                             int u, int v, int uw, int vh) {
        float wdt = Math.abs(xs1 - xs0);
        if (wdt < 0.5f) return;
        int dx = Math.round(Math.min(xs0, xs1));
        int dw = Math.max(1, Math.round(wdt));
        blit(g, tp, dx, dy, dw, dh, u * k, v * k, Math.round(uw * k), Math.round(vh * k), tw, th);
    }

    /**
     * A textured box rotated around the vertical axis (orthographic): front/back and the visible side are drawn as
     * horizontally scaled rectangles, so the doll turns smoothly with only flat texture blits.
     * bw/bh/bd are the texture sizes (x, y, z); grow expands the box for the outer skin layer.
     */
    private static void box(GuiGraphics g, Identifier tp, int tw, int th, float k, float cx, float yTop, int bw, int bh, int bd,
                            int u0, int v0, float grow, int ox, int oy, int S, float sn, float cs) {
        float hx = bw / 2f + grow, hz = bd / 2f + grow;
        int dy = oy + Math.round((yTop - grow) * S);
        int dh = Math.round((bh + 2 * grow) * S);
        if (cs > 0.001f) {
            face(g, tp, tw, th, k, ox + ((cx - hx) * cs + -hz * sn) * S, ox + ((cx + hx) * cs + -hz * sn) * S, dy, dh,
                    u0 + bd, v0 + bd, bw, bh);
        } else if (cs < -0.001f) {
            face(g, tp, tw, th, k, ox + ((cx + hx) * cs + hz * sn) * S, ox + ((cx - hx) * cs + hz * sn) * S, dy, dh,
                    u0 + 2 * bd + bw, v0 + bd, bw, bh);
        }
        if (sn > 0.001f) { // the player's left side (x = +hx)
            face(g, tp, tw, th, k, ox + ((cx + hx) * cs + -hz * sn) * S, ox + ((cx + hx) * cs + hz * sn) * S, dy, dh,
                    u0 + bd + bw, v0 + bd, bd, bh);
        } else if (sn < -0.001f) { // the player's right side (x = -hx)
            face(g, tp, tw, th, k, ox + ((cx - hx) * cs + hz * sn) * S, ox + ((cx - hx) * cs + -hz * sn) * S, dy, dh,
                    u0, v0 + bd, bd, bh);
        }
    }

    private static void draw(GuiGraphics g, int w, int h, int mx, int my) {
        Config c = Config.get();
        try {
            Minecraft mc = Minecraft.getInstance();
            int S = scale(h);
            String name = !c.menuSkin.isEmpty() ? c.menuSkin : c.outfit;
            int cx = centerX(w, c);
            int top = Math.max(8, h / 2 - 12 * S - 8);
            int x0 = cx - 11 * S, x1 = cx + 11 * S, y0 = top - 8, y1 = top + 32 * S + 8;
            g.fill(x0 - 6, y0, x1 + 6, y1, 0x66000000);
            // drag with the mouse (or a finger) to turn the skin
            long now = System.nanoTime();
            float dtS = Math.min(0.1f, (now - lastNs) / 1e9f);
            lastNs = now;
            boolean down = mc.mouseHandler.isLeftPressed();
            boolean inside = mx >= x0 - 6 && mx <= x1 + 6 && my >= y0 && my <= y1;
            if (down) {
                if (!wasDown && inside) dragging = true;
                if (dragging) yaw += (mx - lastMx) * 1.6f;
            } else {
                dragging = false;
            }
            wasDown = down;
            lastMx = mx;
            if (!dragging) yaw += dtS * 10f; // slow spin while you are not holding it
            yaw = ((yaw % 360f) + 360f) % 360f;

            CosmeticsManager.Tex sk = name.isEmpty() ? null : CosmeticsManager.previewOutfit(name);
            if (sk == null || sk.frames.isEmpty()) {
                String m = c.lang.equals("ar") ? "اختر سكن" : "Pick a skin";
                g.drawString(mc.font, Component.literal(m), cx - mc.font.width(m) / 2, top + 16 * S, 0xFFAAAAAA, false);
                return;
            }
            Identifier tp = CosmeticsManager.texturePath(sk.frames.get(0));
            float k = sk.width / 64f;
            int tw = sk.width, th = sk.height;
            boolean slim = sk.slim;
            int aw = slim ? 3 : 4;
            float armX = slim ? 5.5f : 6f;
            float rad = (float) Math.toRadians(yaw);
            float sn = (float) Math.sin(rad), cs = (float) Math.cos(rad);
            int ox = cx, oy = top;
            // parts: centre x, top y, texture size, base uv, overlay uv
            float[][] parts = {
                    {0f, 0f, 8, 8, 8, 0, 0, 32, 0},                    // head
                    {0f, 8f, 8, 12, 4, 16, 16, 16, 32},                // body
                    {-armX, 8f, aw, 12, 4, 40, 16, 40, 32},            // right arm (viewer-left at yaw 0)
                    {armX, 8f, aw, 12, 4, 32, 48, 48, 48},             // left arm
                    {-2f, 20f, 4, 12, 4, 0, 16, 0, 32},                // right leg
                    {2f, 20f, 4, 12, 4, 16, 48, 0, 48},                // left leg
            };
            Integer[] order = {0, 1, 2, 3, 4, 5};
            java.util.Arrays.sort(order, (a, b) -> Float.compare(-parts[b][0] * sn, -parts[a][0] * sn)); // far first
            for (int i : order) {
                float[] p = parts[i];
                box(g, tp, tw, th, k, p[0], p[1], (int) p[2], (int) p[3], (int) p[4], (int) p[5], (int) p[6], 0f, ox, oy, S, sn, cs);
                box(g, tp, tw, th, k, p[0], p[1], (int) p[2], (int) p[3], (int) p[4], (int) p[7], (int) p[8], 0.5f, ox, oy, S, sn, cs);
            }
        } catch (Throwable ignored) {
        }
    }
}
