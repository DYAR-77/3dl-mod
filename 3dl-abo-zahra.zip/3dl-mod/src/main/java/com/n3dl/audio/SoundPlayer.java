package com.n3dl.audio;

import com.n3dl.core.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import org.lwjgl.openal.AL10;
import org.lwjgl.system.MemoryUtil;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import java.io.InputStream;
import java.nio.ShortBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

/**
 * Plays sounds so volume can go above 100% (up to 300%) and pitch is free.
 * Sources:  builtin:NAME      (shipped inside the mod)
 *           file:NAME.mp3     (your own files in config/n3dl/sounds: mp3, ogg, wav, aiff, au)
 *           vanilla:ID        (any Minecraft sound event, volume capped at 100% by the game)
 * Playback uses Java Sound; if the device has none (some phones / launchers) it uses OpenAL, the same
 * sound system Minecraft uses.
 */
public final class SoundPlayer {
    private SoundPlayer() {
    }

    private static final Map<String, AudioDecoder.Pcm> CACHE = new ConcurrentHashMap<>();
    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "3DL ABO ZAHRA-Sound");
        t.setDaemon(true);
        return t;
    });
    private static final List<int[]> AL_ACTIVE = new ArrayList<>();
    private static boolean javaSoundBroken = false;
    private static final List<Clip> CLIPS = new java.util.concurrent.CopyOnWriteArrayList<>();

    public static final String[] BUILTIN = {"hitmarker", "ding", "tick", "coin", "levelup", "boom", "laser", "descend", "pop", "airhorn"};
    public static final String[] VANILLA = {
            "minecraft:entity.experience_orb.pickup",
            "minecraft:entity.player.levelup",
            "minecraft:block.anvil.land",
            "minecraft:entity.arrow.hit_player",
            "minecraft:block.note_block.bell",
            "minecraft:entity.ender_dragon.growl",
            "minecraft:ui.toast.challenge_complete",
            "minecraft:entity.lightning_bolt.thunder",
            "minecraft:block.amethyst_block.chime",
            "minecraft:entity.generic.explode"
    };

    public static Path soundsDir() {
        Path p = Config.dir().resolve("sounds");
        try {
            Files.createDirectories(p);
        } catch (Exception ignored) {
        }
        return p;
    }

    public static void init() {
        soundsDir();
    }

    /** All selectable sources, in menu order. */
    public static List<String> sources() {
        List<String> l = new ArrayList<>();
        for (String b : BUILTIN) l.add("builtin:" + b);
        try (Stream<Path> s = Files.list(soundsDir())) {
            s.filter(f -> AudioDecoder.supported(f.getFileName().toString()))
                    .sorted()
                    .forEach(f -> l.add("file:" + f.getFileName()));
        } catch (Exception ignored) {
        }
        for (String v : VANILLA) l.add("vanilla:" + v);
        return l;
    }

    public static String display(String src) {
        boolean ar = Config.get().ar();
        if (src == null) return "-";
        if (src.startsWith("builtin:")) return (ar ? "3DL ABO ZAHRA: " : "3DL ABO ZAHRA: ") + src.substring(8);
        if (src.startsWith("file:")) return (ar ? "ملفي: " : "File: ") + src.substring(5);
        if (src.startsWith("vanilla:")) {
            String s = src.substring(8).replace("minecraft:", "");
            return (ar ? "ماين كرافت: " : "MC: ") + s;
        }
        return src;
    }

    /** Copies a sound file into the sounds folder. Returns the source id ("file:NAME") or null. */
    public static String importFile(Path src) {
        try {
            String name = src.getFileName().toString().replaceAll("[^A-Za-z0-9._ -]", "_");
            if (!AudioDecoder.supported(name)) return null;
            Path dst = soundsDir().resolve(name);
            if (!src.toAbsolutePath().normalize().equals(dst.toAbsolutePath().normalize())) {
                int i = 1;
                while (Files.exists(dst)) {
                    int dot = name.lastIndexOf('.');
                    dst = soundsDir().resolve(name.substring(0, dot) + "_" + (i++) + name.substring(dot));
                }
                Files.copy(src, dst);
            }
            clearCache();
            return "file:" + dst.getFileName();
        } catch (Exception e) {
            System.err.println("[3DL ABO ZAHRA] Could not import sound: " + e);
            return null;
        }
    }

    public static void play(Config.SoundCfg cfg) {
        if (cfg == null) return;
        String src = cfg.source;
        if (cfg.more != null && !cfg.more.isEmpty()) {
            List<String> pool = new java.util.ArrayList<>();
            if (src != null && !src.isEmpty()) pool.add(src);
            pool.addAll(cfg.more);
            src = pool.get(java.util.concurrent.ThreadLocalRandom.current().nextInt(pool.size()));
        }
        play(src, cfg.volume, cfg.pitch);
    }

    public static void play(String source, float volume, float pitch) {
        if (source == null) return;
        float master = Config.get().soundMaster;
        if (source.startsWith("vanilla:")) {
            playVanilla(source.substring(8), Math.min(1f, volume * master), pitch);
            return;
        }
        POOL.execute(() -> {
            try {
                AudioDecoder.Pcm d = CACHE.get(source);
                if (d == null) {
                    d = decode(source);
                    if (d != null) CACHE.put(source, d);
                }
                if (d == null) {
                    playVanilla("minecraft:entity.experience_orb.pickup", Math.min(1f, volume), pitch);
                    return;
                }
                byte[] amp = amplify(d.pcm(), volume * master);
                if (!javaSoundBroken) {
                    try {
                        playJavaSound(amp, d.channels(), d.rate() * Math.max(0.25f, Math.min(4f, pitch)));
                        return;
                    } catch (Throwable t) {
                        javaSoundBroken = true;
                    }
                }
                playOpenAl(amp, d.channels(), d.rate(), pitch);
            } catch (Throwable t) {
                System.err.println("[3DL ABO ZAHRA] Sound failed: " + t);
                playVanilla("minecraft:entity.experience_orb.pickup", Math.min(1f, volume), pitch);
            }
        });
    }

    private static void playVanilla(String id, float volume, float pitch) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            try {
                SoundEvent ev = SoundEvent.createVariableRangeEvent(Identifier.parse(id));
                mc.getSoundManager().play(SimpleSoundInstance.forUI(ev, pitch, Math.max(0.01f, volume)));
            } catch (Throwable ignored) {
            }
        });
    }

    private static AudioDecoder.Pcm decode(String source) {
        try {
            if (source.startsWith("builtin:")) {
                try (InputStream in = SoundPlayer.class.getResourceAsStream("/assets/n3dl/sfx/" + source.substring(8) + ".wav")) {
                    if (in == null) return null;
                    return AudioDecoder.decode("x.wav", in.readAllBytes());
                }
            }
            if (source.startsWith("file:")) {
                Path p = soundsDir().resolve(source.substring(5)).normalize();
                if (!p.startsWith(soundsDir().normalize()) || !Files.isRegularFile(p)) return null;
                return AudioDecoder.decode(p);
            }
        } catch (Throwable t) {
            System.err.println("[3DL ABO ZAHRA] Could not decode sound " + source + ": " + t);
        }
        return null;
    }

    private static byte[] amplify(byte[] pcm, float gain) {
        byte[] out = pcm.clone();
        for (int i = 0; i + 1 < out.length; i += 2) {
            int s = (short) ((out[i] & 0xFF) | (out[i + 1] << 8));
            int v = Math.round(s * gain);
            if (v > 32767) v = 32767;
            if (v < -32768) v = -32768;
            out[i] = (byte) (v & 0xFF);
            out[i + 1] = (byte) ((v >> 8) & 0xFF);
        }
        return out;
    }

    private static void playJavaSound(byte[] pcm, int channels, float rate) throws Exception {
        AudioFormat f = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, rate, 16, channels, channels * 2, rate, false);
        Clip clip = AudioSystem.getClip();
        clip.open(f, pcm, 0, pcm.length);
        CLIPS.add(clip);
        clip.addLineListener(e -> {
            if (e.getType() == LineEvent.Type.STOP) {
                CLIPS.remove(clip);
                clip.close();
            }
        });
        clip.start();
    }

    /** Fallback: plays through Minecraft's own OpenAL device (not positional). */
    private static void playOpenAl(byte[] pcm, int channels, int rate, float pitch) {
        if (channels < 1 || channels > 2) return;
        Minecraft.getInstance().execute(() -> {
            ShortBuffer sb = null;
            try {
                int n = pcm.length / 2;
                sb = MemoryUtil.memAllocShort(n);
                for (int i = 0; i < n; i++) sb.put((short) ((pcm[i * 2] & 0xFF) | (pcm[i * 2 + 1] << 8)));
                sb.flip();
                int buf = AL10.alGenBuffers();
                AL10.alBufferData(buf, channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, sb, rate);
                int src = AL10.alGenSources();
                AL10.alSourcei(src, AL10.AL_BUFFER, buf);
                AL10.alSourcei(src, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
                AL10.alSource3f(src, AL10.AL_POSITION, 0f, 0f, 0f);
                AL10.alSourcef(src, AL10.AL_GAIN, 1f);
                AL10.alSourcef(src, AL10.AL_PITCH, Math.max(0.25f, Math.min(4f, pitch)));
                AL10.alSourcePlay(src);
                AL_ACTIVE.add(new int[]{src, buf});
            } catch (Throwable t) {
                System.err.println("[3DL ABO ZAHRA] OpenAL playback failed: " + t);
            } finally {
                if (sb != null) MemoryUtil.memFree(sb);
            }
        });
    }

    /** Called every client tick: frees finished OpenAL sources. */
    public static void tick() {
        if (AL_ACTIVE.isEmpty()) return;
        try {
            for (Iterator<int[]> it = AL_ACTIVE.iterator(); it.hasNext(); ) {
                int[] a = it.next();
                if (AL10.alGetSourcei(a[0], AL10.AL_SOURCE_STATE) != AL10.AL_PLAYING) {
                    AL10.alDeleteSources(a[0]);
                    AL10.alDeleteBuffers(a[1]);
                    it.remove();
                }
            }
        } catch (Throwable t) {
            AL_ACTIVE.clear();
        }
    }

    /** Stops every sound effect that is playing right now (the Stop button). */
    public static void stopAll() {
        for (Clip cl : CLIPS) {
            try {
                cl.stop();
            } catch (Throwable ignored) {
            }
        }
        Minecraft.getInstance().execute(() -> {
            try {
                for (int[] a : AL_ACTIVE) {
                    AL10.alSourceStop(a[0]);
                }
            } catch (Throwable ignored) {
            }
        });
    }

    public static void clearCache() {
        CACHE.clear();
    }
}
