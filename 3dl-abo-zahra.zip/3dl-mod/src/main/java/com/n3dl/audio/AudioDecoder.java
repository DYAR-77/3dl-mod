package com.n3dl.audio;

import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.system.libc.LibCStdlib;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Decodes MP3 / OGG / WAV / AIFF / AU into 16-bit little-endian PCM. */
public final class AudioDecoder {
    private AudioDecoder() {
    }

    /** pcm = interleaved 16-bit little-endian samples. */
    public record Pcm(byte[] pcm, int channels, int rate) {
    }

    /** Longest clip we keep in memory (seconds). Longer files are cut. */
    private static final int MAX_SECONDS = 60;

    public static final String[] EXTENSIONS = {"mp3", "ogg", "wav", "aif", "aiff", "au"};

    public static boolean supported(String fileName) {
        String n = fileName.toLowerCase();
        for (String e : EXTENSIONS) if (n.endsWith("." + e)) return true;
        return false;
    }

    public static Pcm decode(String fileName, byte[] data) throws Exception {
        String n = fileName.toLowerCase();
        if (n.endsWith(".mp3")) return mp3(data);
        if (n.endsWith(".ogg")) return ogg(data);
        return javaSound(data);
    }

    public static Pcm decode(Path file) throws Exception {
        return decode(file.getFileName().toString(), Files.readAllBytes(file));
    }

    private static Pcm clip(byte[] pcm, int channels, int rate) {
        int max = MAX_SECONDS * rate * channels * 2;
        if (pcm.length > max) {
            byte[] c = new byte[max];
            System.arraycopy(pcm, 0, c, 0, max);
            pcm = c;
        }
        return new Pcm(pcm, channels, rate);
    }

    private static Pcm mp3(byte[] data) throws Exception {
        Bitstream bs = new Bitstream(new ByteArrayInputStream(data));
        Decoder dec = new Decoder();
        ByteArrayOutputStream out = new ByteArrayOutputStream(data.length * 8);
        int rate = 44100, ch = 2;
        long limit = (long) MAX_SECONDS * 44100 * 2 * 2 + 1;
        try {
            while (out.size() < limit) {
                Header h = bs.readFrame();
                if (h == null) break;
                SampleBuffer sb = (SampleBuffer) dec.decodeFrame(h, bs);
                rate = sb.getSampleFrequency();
                ch = sb.getChannelCount();
                short[] buf = sb.getBuffer();
                int len = sb.getBufferLength();
                for (int i = 0; i < len; i++) {
                    out.write(buf[i] & 0xFF);
                    out.write((buf[i] >> 8) & 0xFF);
                }
                bs.closeFrame();
            }
        } finally {
            try {
                bs.close();
            } catch (Exception ignored) {
            }
        }
        if (out.size() == 0) throw new IllegalStateException("empty mp3");
        return clip(out.toByteArray(), ch, rate);
    }

    private static Pcm ogg(byte[] data) {
        ByteBuffer in = MemoryUtil.memAlloc(data.length);
        IntBuffer ch = MemoryUtil.memAllocInt(1);
        IntBuffer rate = MemoryUtil.memAllocInt(1);
        ShortBuffer pcm = null;
        try {
            in.put(data).flip();
            pcm = STBVorbis.stb_vorbis_decode_memory(in, ch, rate);
            if (pcm == null) throw new IllegalStateException("bad ogg");
            int n = pcm.remaining();
            byte[] out = new byte[n * 2];
            for (int i = 0; i < n; i++) {
                short s = pcm.get(i);
                out[i * 2] = (byte) (s & 0xFF);
                out[i * 2 + 1] = (byte) ((s >> 8) & 0xFF);
            }
            return clip(out, ch.get(0), rate.get(0));
        } finally {
            if (pcm != null) LibCStdlib.free(pcm);
            MemoryUtil.memFree(in);
            MemoryUtil.memFree(ch);
            MemoryUtil.memFree(rate);
        }
    }

    private static Pcm javaSound(byte[] data) throws Exception {
        try (AudioInputStream in = AudioSystem.getAudioInputStream(new BufferedInputStream(new ByteArrayInputStream(data)))) {
            AudioFormat src = in.getFormat();
            AudioFormat target = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, src.getSampleRate(), 16,
                    src.getChannels(), src.getChannels() * 2, src.getSampleRate(), false);
            try (AudioInputStream pcm = AudioSystem.getAudioInputStream(target, in)) {
                return clip(pcm.readAllBytes(), src.getChannels(), Math.round(src.getSampleRate()));
            }
        }
    }
}
