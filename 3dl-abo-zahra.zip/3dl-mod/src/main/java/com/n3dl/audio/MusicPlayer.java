package com.n3dl.audio;

import com.n3dl.core.Config;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.ByteBuffer;
import java.nio.ShortBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;
import net.minecraft.client.Minecraft;
import org.lwjgl.openal.AL10;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.stb.STBVorbisInfo;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

/**
 * Built-in music player (a small "Spotify"): a playlist made of files in config/n3dl/music (mp3, ogg, wav).
 * Songs are streamed (decoded a little at a time on a background thread), so a 2 hour song costs almost no memory and
 * never lags the game. When a song ends the next one starts; after the last one the first starts again.
 * Output goes through Java Sound; where the device has none (some phones) it uses Minecraft's OpenAL.
 */
public final class MusicPlayer {
    private MusicPlayer() {
    }

    /** Longest song we play (seconds). */
    public static final int MAX_SECONDS = 2 * 60 * 60;

    private record Chunk(byte[] data, int channels, int rate) {
    }

    private static final Object LOCK = new Object();
    private static volatile int gen = 0;
    private static volatile boolean playing, paused;
    private static volatile String current = "";
    private static volatile long posFrames;
    private static volatile int posRate = 44100;
    private static volatile String status = "";
    private static volatile boolean alMode;
    private static final LinkedBlockingQueue<Chunk> AL_QUEUE = new LinkedBlockingQueue<>(10);
    private static volatile boolean alFlush;
    private static int alSrc = 0, alCh = 0, alRate = 0;
    private static boolean javaSoundBroken;

    public static Path dir() {
        Path p = Config.dir().resolve("music");
        try {
            Files.createDirectories(p);
        } catch (Exception ignored) {
        }
        return p;
    }

    public static List<String> tracks() {
        List<String> l = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir())) {
            s.filter(f -> AudioDecoder.supported(f.getFileName().toString())).sorted()
                    .forEach(f -> l.add(f.getFileName().toString()));
        } catch (Exception ignored) {
        }
        return l;
    }

    public static boolean isPlaying() {
        return playing;
    }

    public static boolean isPaused() {
        return paused;
    }

    public static String nowPlaying() {
        return current;
    }

    public static String status() {
        return status;
    }

    public static long positionSeconds() {
        return posFrames / Math.max(1, posRate);
    }

    // ------------------------------------------------------------------ controls

    public static void play(String name) {
        if (name == null || name.isEmpty()) return;
        Path p = dir().resolve(name).normalize();
        if (!p.startsWith(dir().normalize()) || !Files.isRegularFile(p)) {
            status = "File not found: " + name;
            return;
        }
        final int my;
        synchronized (LOCK) {
            my = ++gen;
            current = name;
            paused = false;
            playing = true;
            posFrames = 0;
            status = "";
            AL_QUEUE.clear();
            alFlush = true;
        }
        Thread t = new Thread(() -> run(p, name, my), "3DL ABO ZAHRA-Music");
        t.setDaemon(true);
        t.setPriority(Thread.NORM_PRIORITY - 1);
        t.start();
    }

    public static void playFirst() {
        List<String> l = tracks();
        if (!l.isEmpty()) play(l.get(0));
    }

    public static void togglePause() {
        if (!playing) {
            if (!current.isEmpty() && tracks().contains(current)) play(current);
            else playFirst();
            return;
        }
        paused = !paused;
    }

    public static void stop() {
        synchronized (LOCK) {
            gen++;
            playing = false;
            paused = false;
            AL_QUEUE.clear();
            alFlush = true;
        }
    }

    public static void next() {
        step(1);
    }

    public static void prev() {
        step(-1);
    }

    private static void step(int d) {
        List<String> l = tracks();
        if (l.isEmpty()) {
            stop();
            return;
        }
        int i = l.indexOf(current);
        int n = i < 0 ? 0 : (i + d + l.size()) % l.size();
        play(l.get(n)); // with one song this plays it again
    }

    public static boolean delete(String name) {
        try {
            Path p = dir().resolve(name).normalize();
            if (!p.startsWith(dir().normalize())) return false;
            if (name.equals(current)) stop();
            return Files.deleteIfExists(p);
        } catch (Exception e) {
            return false;
        }
    }

    /** Copies a file into the music folder. */
    public static String addFile(Path src) {
        try {
            String name = src.getFileName().toString().replaceAll("[^A-Za-z0-9._ -]", "_");
            if (!AudioDecoder.supported(name)) return null;
            Path dst = dir().resolve(name);
            if (!src.toAbsolutePath().normalize().equals(dst.toAbsolutePath().normalize())) {
                int i = 1;
                while (Files.exists(dst)) {
                    int dot = name.lastIndexOf('.');
                    dst = dir().resolve(name.substring(0, dot) + "_" + (i++) + name.substring(dot));
                }
                Files.copy(src, dst);
            }
            return dst.getFileName().toString();
        } catch (Exception e) {
            return null;
        }
    }

    /** Downloads a direct link to an mp3 / ogg / wav into the music folder (runs on its own thread). */
    public static void addUrl(String url, java.util.function.Consumer<String> done) {
        Thread t = new Thread(() -> {
            try {
                if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
                    done.accept(null);
                    return;
                }
                HttpClient hc = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.ALWAYS)
                        .connectTimeout(Duration.ofSeconds(15)).build();
                HttpResponse<InputStream> r = hc.send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(30))
                        .header("User-Agent", "Mozilla/5.0").GET().build(), HttpResponse.BodyHandlers.ofInputStream());
                if (r.statusCode() / 100 != 2) {
                    done.accept(null);
                    return;
                }
                String path = URI.create(url).getPath();
                String name = path == null || path.isEmpty() ? "song" : path.substring(path.lastIndexOf('/') + 1);
                try {
                    name = java.net.URLDecoder.decode(name, "UTF-8");
                } catch (Exception ignored) {
                }
                name = name.replaceAll("[^A-Za-z0-9._ -]", "_");
                if (name.isEmpty()) name = "song";
                if (!AudioDecoder.supported(name)) {
                    String ct = r.headers().firstValue("content-type").orElse("").toLowerCase();
                    String ext = ct.contains("mpeg") || ct.contains("mp3") ? ".mp3" : ct.contains("ogg") ? ".ogg"
                            : ct.contains("wav") ? ".wav" : "";
                    if (ext.isEmpty()) {
                        done.accept(null);
                        return;
                    }
                    name = name + ext;
                }
                Path dst = dir().resolve(name);
                int i = 1;
                while (Files.exists(dst)) {
                    int dot = name.lastIndexOf('.');
                    dst = dir().resolve(name.substring(0, dot) + "_" + (i++) + name.substring(dot));
                }
                Path tmp = dir().resolve(dst.getFileName() + ".part");
                long max = 400L * 1024 * 1024;
                try (InputStream in = r.body(); java.io.OutputStream out = Files.newOutputStream(tmp)) {
                    byte[] buf = new byte[65536];
                    long total = 0;
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        total += n;
                        if (total > max) throw new java.io.IOException("too big");
                        out.write(buf, 0, n);
                    }
                }
                Files.move(tmp, dst, StandardCopyOption.REPLACE_EXISTING);
                done.accept(dst.getFileName().toString());
            } catch (Throwable e) {
                done.accept(null);
            }
        }, "3DL ABO ZAHRA-Music-Download");
        t.setDaemon(true);
        t.start();
    }

    // ------------------------------------------------------------------ streaming decode

    private interface Src extends AutoCloseable {
        int channels();

        int rate();

        /** Fills buf with 16-bit little-endian PCM. Returns the byte count, or -1 at the end. */
        int read(byte[] buf) throws Exception;

        @Override
        void close();
    }

    private static Src open(Path p) throws Exception {
        String n = p.getFileName().toString().toLowerCase();
        if (n.endsWith(".mp3")) return new Mp3Src(p);
        if (n.endsWith(".ogg")) return new OggSrc(p);
        return new JsSrc(p);
    }

    private static final class Mp3Src implements Src {
        private final Bitstream bs;
        private final Decoder dec = new Decoder();
        private byte[] pend = new byte[0];
        private int pi = 0, ch = 2, rate = 44100;
        private boolean eof;

        Mp3Src(Path p) throws Exception {
            bs = new Bitstream(new BufferedInputStream(Files.newInputStream(p), 1 << 16));
            fill(); // learn the format from the first frame
        }

        private void fill() throws Exception {
            Header h = bs.readFrame();
            if (h == null) {
                eof = true;
                return;
            }
            SampleBuffer sb = (SampleBuffer) dec.decodeFrame(h, bs);
            rate = sb.getSampleFrequency();
            ch = sb.getChannelCount();
            short[] b = sb.getBuffer();
            int len = sb.getBufferLength();
            byte[] o = new byte[len * 2];
            for (int i = 0; i < len; i++) {
                o[i * 2] = (byte) (b[i] & 0xFF);
                o[i * 2 + 1] = (byte) ((b[i] >> 8) & 0xFF);
            }
            bs.closeFrame();
            pend = o;
            pi = 0;
        }

        public int channels() {
            return ch;
        }

        public int rate() {
            return rate;
        }

        public int read(byte[] buf) throws Exception {
            int w = 0;
            while (w < buf.length) {
                if (pi >= pend.length) {
                    if (eof) break;
                    fill();
                    if (eof) break;
                }
                int c = Math.min(buf.length - w, pend.length - pi);
                System.arraycopy(pend, pi, buf, w, c);
                pi += c;
                w += c;
            }
            return w == 0 ? -1 : w;
        }

        public void close() {
            try {
                bs.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static final class JsSrc implements Src {
        private final AudioInputStream pcm;
        private final int ch, rate;

        JsSrc(Path p) throws Exception {
            AudioInputStream in = AudioSystem.getAudioInputStream(new BufferedInputStream(Files.newInputStream(p), 1 << 16));
            AudioFormat src = in.getFormat();
            AudioFormat target = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, src.getSampleRate(), 16,
                    src.getChannels(), src.getChannels() * 2, src.getSampleRate(), false);
            pcm = AudioSystem.getAudioInputStream(target, in);
            ch = src.getChannels();
            rate = Math.round(src.getSampleRate());
        }

        public int channels() {
            return ch;
        }

        public int rate() {
            return rate;
        }

        public int read(byte[] buf) throws Exception {
            int n = pcm.read(buf, 0, buf.length);
            return n <= 0 ? -1 : n;
        }

        public void close() {
            try {
                pcm.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static final class OggSrc implements Src {
        private final ByteBuffer mem;
        private final long h;
        private final int ch, rate;
        private final ShortBuffer sb;

        OggSrc(Path p) throws Exception {
            byte[] data = Files.readAllBytes(p);
            mem = MemoryUtil.memAlloc(data.length);
            mem.put(data).flip();
            java.nio.IntBuffer err = MemoryUtil.memAllocInt(1);
            long hh;
            try {
                hh = STBVorbis.stb_vorbis_open_memory(mem, err, null);
            } finally {
                MemoryUtil.memFree(err);
            }
            if (hh == 0L) {
                MemoryUtil.memFree(mem);
                throw new IllegalStateException("bad ogg");
            }
            h = hh;
            try (MemoryStack st = MemoryStack.stackPush()) {
                STBVorbisInfo info = STBVorbisInfo.malloc(st);
                STBVorbis.stb_vorbis_get_info(h, info);
                ch = Math.max(1, info.channels());
                rate = info.sample_rate();
            }
            sb = MemoryUtil.memAllocShort(4096 * ch);
        }

        public int channels() {
            return ch;
        }

        public int rate() {
            return rate;
        }

        public int read(byte[] buf) {
            int w = 0;
            while (w + ch * 2 <= buf.length) {
                int want = Math.min(4096, (buf.length - w) / (ch * 2));
                sb.clear();
                sb.limit(want * ch);
                int n = STBVorbis.stb_vorbis_get_samples_short_interleaved(h, ch, sb);
                if (n <= 0) break;
                for (int i = 0; i < n * ch; i++) {
                    short s = sb.get(i);
                    buf[w++] = (byte) (s & 0xFF);
                    buf[w++] = (byte) ((s >> 8) & 0xFF);
                }
            }
            return w == 0 ? -1 : w;
        }

        public void close() {
            try {
                STBVorbis.stb_vorbis_close(h);
                MemoryUtil.memFree(sb);
                MemoryUtil.memFree(mem);
            } catch (Throwable ignored) {
            }
        }
    }

    // ------------------------------------------------------------------ playback thread

    private static void gain(byte[] b, int len, float g) {
        if (Math.abs(g - 1f) < 0.01f) return;
        for (int i = 0; i + 1 < len; i += 2) {
            int s = (short) ((b[i] & 0xFF) | (b[i + 1] << 8));
            int v = Math.round(s * g);
            if (v > 32767) v = 32767;
            if (v < -32768) v = -32768;
            b[i] = (byte) (v & 0xFF);
            b[i + 1] = (byte) ((v >> 8) & 0xFF);
        }
    }

    private static float vol() {
        return Math.max(0f, Math.min(2f, Config.get().musicVolume));
    }

    private static void run(Path file, String name, int my) {
        Src src = null;
        SourceDataLine line = null;
        boolean finished = false;
        try {
            src = open(file);
            final int ch = src.channels(), rate = src.rate();
            posRate = rate;
            boolean useAl = alMode;
            if (!useAl && !javaSoundBroken) {
                try {
                    AudioFormat f = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, rate, 16, ch, ch * 2, rate, false);
                    line = AudioSystem.getSourceDataLine(f);
                    line.open(f, Math.max(16384, rate * ch * 2 / 3));
                    line.start();
                } catch (Throwable t) {
                    javaSoundBroken = true;
                    line = null;
                }
            }
            if (line == null) {
                alMode = true;
                useAl = true;
            }
            byte[] buf = new byte[ch * 2 * 2048];
            long limit = (long) MAX_SECONDS * rate;
            long frames = 0;
            while (gen == my) {
                if (paused) {
                    Thread.sleep(40);
                    continue;
                }
                int n = src.read(buf);
                if (n < 0) {
                    finished = true;
                    break;
                }
                float g = vol();
                if (useAl) {
                    byte[] c = java.util.Arrays.copyOf(buf, n);
                    while (gen == my && !AL_QUEUE.offer(new Chunk(c, ch, rate), 100, TimeUnit.MILLISECONDS)) {
                        // wait for the OpenAL side to catch up
                    }
                } else {
                    gain(buf, n, g);
                    line.write(buf, 0, n);
                }
                frames += n / (ch * 2);
                posFrames = frames;
                if (frames >= limit) {
                    finished = true; // 2 hour cap
                    break;
                }
            }
            if (finished && gen == my) {
                if (line != null) line.drain();
                else Thread.sleep(1200);
            }
        } catch (InterruptedException ignored) {
            // replaced by another song
        } catch (Throwable t) {
            if (gen == my) {
                status = "Cannot play " + name;
                finished = true;
            }
        } finally {
            if (line != null) {
                try {
                    if (gen != my) line.stop();
                    line.close();
                } catch (Throwable ignored) {
                }
            }
            if (src != null) src.close();
        }
        if (finished && gen == my) {
            List<String> l = tracks();
            if (l.isEmpty()) {
                stop();
            } else if (status.startsWith("Cannot play") && l.size() == 1) {
                stop();
            } else {
                next(); // next song, or the first one again when this was the last
            }
        }
    }

    // ------------------------------------------------------------------ OpenAL fallback (game thread)

    public static void tick() {
        if (!alMode) return;
        try {
            if (alFlush) {
                alFlush = false;
                alClear();
            }
            if (!playing) return;
            if (alSrc == 0) {
                if (AL_QUEUE.isEmpty()) return;
                alSrc = AL10.alGenSources();
                AL10.alSourcei(alSrc, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
            }
            int processed = AL10.alGetSourcei(alSrc, AL10.AL_BUFFERS_PROCESSED);
            while (processed-- > 0) AL10.alDeleteBuffers(AL10.alSourceUnqueueBuffers(alSrc));
            int queued = AL10.alGetSourcei(alSrc, AL10.AL_BUFFERS_QUEUED);
            while (queued < 6) {
                Chunk c = AL_QUEUE.peek();
                if (c == null) break;
                if (queued > 0 && (c.channels() != alCh || c.rate() != alRate)) break; // format changes: let the queue drain
                AL_QUEUE.poll();
                alCh = c.channels();
                alRate = c.rate();
                byte[] d = c.data();
                gain(d, d.length, 1f);
                ShortBuffer s = MemoryUtil.memAllocShort(d.length / 2);
                try {
                    for (int i = 0; i + 1 < d.length; i += 2) s.put((short) ((d[i] & 0xFF) | (d[i + 1] << 8)));
                    s.flip();
                    int b = AL10.alGenBuffers();
                    AL10.alBufferData(b, alCh == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, s, alRate);
                    AL10.alSourceQueueBuffers(alSrc, b);
                    queued++;
                } finally {
                    MemoryUtil.memFree(s);
                }
            }
            AL10.alSourcef(alSrc, AL10.AL_GAIN, Math.min(1f, vol()));
            int state = AL10.alGetSourcei(alSrc, AL10.AL_SOURCE_STATE);
            if (paused) {
                if (state == AL10.AL_PLAYING) AL10.alSourcePause(alSrc);
            } else if (queued > 0 && state != AL10.AL_PLAYING) {
                AL10.alSourcePlay(alSrc);
            }
        } catch (Throwable t) {
            alSrc = 0;
        }
    }

    private static void alClear() {
        if (alSrc == 0) return;
        AL10.alSourceStop(alSrc);
        int q = AL10.alGetSourcei(alSrc, AL10.AL_BUFFERS_QUEUED);
        while (q-- > 0) AL10.alDeleteBuffers(AL10.alSourceUnqueueBuffers(alSrc));
        AL10.alDeleteSources(alSrc);
        alSrc = 0;
    }
}
