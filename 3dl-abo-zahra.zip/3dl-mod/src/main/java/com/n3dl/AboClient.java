package com.n3dl;

import com.mojang.blaze3d.platform.InputConstants;
import com.n3dl.audio.SoundPlayer;
import com.n3dl.core.Actions;
import com.n3dl.core.Config;
import com.n3dl.core.Hide;
import com.n3dl.core.Tr;
import com.n3dl.cosmetics.CosmeticsManager;
import com.n3dl.gui.AboScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;

public class AboClient implements ClientModInitializer {
    public static KeyMapping OPEN, STREAMER, TOGGLE, ZOOM;

    private static final Map<Integer, Boolean> HELD = new HashMap<>();
    private static int lastTargetId = -1;
    private static long lastHitMs = 0;
    private static boolean killFired = false;
    private static long lastKillSoundMs = 0;
    private static String lastWeapon = "hand";

    /** Registry id of the item in the main hand, or "hand" when it is empty. */
    private static String heldId() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return "hand";
        var st = mc.player.getMainHandItem();
        return st.isEmpty() ? "hand" : net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(st.getItem()).toString();
    }

    /** Sound set for this weapon, or null when the weapon has none (then the normal sound is used). */
    private static Config.SoundCfg weaponCfg(String id, boolean kill) {
        Config c = Config.get();
        if (!c.weaponSounds) return null;
        for (Config.WeaponSound w : c.weaponList) {
            if (id.equals(w.item) || ("minecraft:" + id).equals(w.item)) {
                Config.SoundCfg s = kill ? w.kill : w.hit;
                if (s.enabled) return s;
            }
        }
        return null;
    }
    private static boolean wasDead = false;
    private static boolean zooming = false;
    private static int savedFov = 70;
    private static boolean wasLeftDown = false;
    private static final List<Long> CLICKS = new ArrayList<>();
    private static int fpsFrames = 0, fpsShown = 0;
    private static long fpsStamp = 0;

    @Override
    public void onInitializeClient() {
        com.n3dl.gui.MainMenuSkin.init();
        Config.load();
        CosmeticsManager.init();
        SoundPlayer.init();
        registerKeys();
        registerHud();
        registerEvents();
        com.n3dl.cosmetics.LookPacks.register();
    }

    // ------------------------------------------------------------------ keys

    private static KeyMapping key(String name, int code, KeyMapping.Category cat) {
        return KeyBindingHelper.registerKeyBinding(new KeyMapping("key.n3dl." + name, InputConstants.Type.KEYSYM, code, cat));
    }

    private void registerKeys() {
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("n3dl", "main"));
        OPEN = key("open", GLFW.GLFW_KEY_RIGHT_SHIFT, cat);
        STREAMER = key("streamer", GLFW.GLFW_KEY_UNKNOWN, cat);
        TOGGLE = key("toggle", GLFW.GLFW_KEY_UNKNOWN, cat);
        ZOOM = key("zoom", GLFW.GLFW_KEY_C, cat);
    }

    /** GLFW code of the key a mapping is currently bound to (or -1). */
    public static int boundKey(KeyMapping km) {
        try {
            return InputConstants.getKey(km.saveString()).getValue();
        } catch (Throwable t) {
            return -1;
        }
    }

    // ------------------------------------------------------------------ HUD

    private static void hide(String path, BooleanSupplier hidden) {
        try {
            HudElementRegistry.replaceElement(Identifier.fromNamespaceAndPath("minecraft", path),
                    original -> (graphics, delta) -> {
                        if (!hidden.getAsBoolean()) original.render(graphics, delta);
                    });
        } catch (Throwable t) {
            System.err.println("[3DL ABO ZAHRA] Could not hook HUD element '" + path + "': " + t);
        }
    }

    private void registerHud() {
        hide("chat", Hide::chat);
        try {
            HudElementRegistry.replaceElement(Identifier.fromNamespaceAndPath("minecraft", "player_list"),
                    original -> (graphics, delta) -> {
                        if (!Hide.tab()) original.render(graphics, delta);
                        else if (Config.get().tabNamesOnly) com.n3dl.gui.NamesTab.render(graphics);
                    });
        } catch (Throwable ex) {
            System.err.println("[3DL ABO ZAHRA] Could not hook the tab list: " + ex);
        }
        hide("scoreboard", Hide::scoreboard);
        hide("boss_bar", Hide::bossBar);
        hide("title_and_subtitle", Hide::title);
        try {
            HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                    Identifier.fromNamespaceAndPath("n3dl", "overlay"), (graphics, delta) -> drawOverlay(graphics));
        } catch (Throwable t) {
            System.err.println("[3DL ABO ZAHRA] Could not attach overlay: " + t);
        }
    }

    private static void drawOverlay(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        Config c = Config.get();
        if (!c.enabled || mc.player == null) return;

        long now = System.currentTimeMillis();
        fpsFrames++;
        if (now - fpsStamp >= 1000) {
            fpsShown = fpsFrames;
            fpsFrames = 0;
            fpsStamp = now;
        }
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        if (c.infoHud) {
            List<String> lines = new ArrayList<>();
            if (c.infoFps) lines.add("FPS: " + fpsShown);
            if (c.infoXyz) lines.add(String.format("XYZ: %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()));
            if (c.infoFacing) lines.add(Tr.t("Facing: ", "الاتجاه: ") + mc.player.getDirection().getName());
            if (c.infoPing && mc.getConnection() != null) {
                PlayerInfo pi = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (pi != null) lines.add("Ping: " + pi.getLatency() + " ms");
            }
            if (c.infoCps) {
                CLICKS.removeIf(t -> now - t > 1000);
                lines.add("CPS: " + CLICKS.size());
            }
            if (c.infoTime) lines.add(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
            int lh = mc.font.lineHeight + 2;
            int maxW = 0;
            for (String l : lines) maxW = Math.max(maxW, mc.font.width(l));
            int boxW = maxW + 8, boxH = lines.size() * lh + 6;
            int x = (c.infoCorner == 1 || c.infoCorner == 3) ? sw - boxW - 4 : 4;
            int y = (c.infoCorner >= 2) ? sh - boxH - 4 : 4;
            if (!lines.isEmpty()) {
                g.fill(x, y, x + boxW, y + boxH, com.n3dl.core.Theme.argb(c.cBg, 0.55f));
                g.fill(x, y, x + 2, y + boxH, 0xFF000000 | c.cAccent);
                for (int i = 0; i < lines.size(); i++) {
                    g.drawString(mc.font, Component.literal(lines.get(i)), x + 5, y + 4 + i * lh, 0xFF000000 | c.cText, true);
                }
            }
        }

    }

    // ------------------------------------------------------------------ events

    private void registerEvents() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.BEFORE_TRANSLUCENT.register(com.n3dl.cosmetics.FirstPerson::render);
        ClientTickEvents.START_CLIENT_TICK.register(com.n3dl.combat.Combat::startTick);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world instanceof ClientLevel && entity instanceof LivingEntity) {
                lastTargetId = entity.getId();
                lastHitMs = System.currentTimeMillis();
                killFired = false;
                lastWeapon = heldId();
                Config c = Config.get();
                Config.SoundCfg ws = weaponCfg(lastWeapon, false);
                if (c.enabled && ws != null) SoundPlayer.play(ws);
                else if (c.enabled && c.hit.enabled) SoundPlayer.play(c.hit);
            }
            return InteractionResult.PASS;
        });

        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) onChatLine(message.getString());
        });
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, ts) -> onChatLine(message.getString()));
    }

    private static void onChatLine(String line) {
        Config c = Config.get();
        Minecraft mc = Minecraft.getInstance();
        if (!c.enabled || mc.player == null || line == null) return;
        String me = mc.player.getName().getString();
        String lower = line.toLowerCase();
        String meLower = me.toLowerCase();

        String pat = c.killChatPattern == null ? "" : c.killChatPattern.trim();
        if (!pat.isEmpty() && (c.kill.enabled || c.weaponSounds) && lower.contains(pat.replace("{me}", me).toLowerCase())) {
            playKill();
            return;
        }
        if (c.mention.enabled && lower.contains(meLower) && !lower.startsWith("<" + meLower + ">")
                && !lower.startsWith(meLower + ":")) {
            SoundPlayer.play(c.mention);
        }
    }

    private static void playKill() {
        long now = System.currentTimeMillis();
        if (now - lastKillSoundMs < 800) return; // do not double-play (chat + entity detection)
        lastKillSoundMs = now;
        Config c = Config.get();
        String w = now - lastHitMs < 6000 ? lastWeapon : heldId();
        Config.SoundCfg ws = weaponCfg(w, true);
        if (ws != null) SoundPlayer.play(ws);
        else if (c.kill.enabled) SoundPlayer.play(c.kill);
    }

    private void onTick(Minecraft mc) {
        Config c = Config.get();
        Actions.tick();
        SoundPlayer.tick();
        com.n3dl.audio.MusicPlayer.tick();
        com.n3dl.cosmetics.PetState.tick(mc);
        com.n3dl.emote.EmoteManager.tick(mc);
        com.n3dl.net.SyncClient.tick(mc);
        com.n3dl.combat.Combat.tick(mc);

        // vanilla-style keys
        while (OPEN.consumeClick()) mc.setScreen(new AboScreen());
        while (STREAMER.consumeClick()) Actions.exec("@streamer");
        while (TOGGLE.consumeClick()) Actions.exec("@toggle_mod");

        if (mc.player == null || mc.level == null) return;
        long win = GLFW.glfwGetCurrentContext();

        // zoom
        if (c.enabled && c.zoomEnabled && mc.screen == null && ZOOM.isDown()) {
            if (!zooming) {
                zooming = true;
                savedFov = mc.options.fov().get();
            }
            mc.options.fov().set(Math.max(10, Math.min(110, c.zoomFov)));
        } else if (zooming) {
            zooming = false;
            mc.options.fov().set(savedFov);
        }

        // CPS (left mouse button)
        boolean left = win != 0 && GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (left && !wasLeftDown && mc.screen == null) CLICKS.add(System.currentTimeMillis());
        wasLeftDown = left;

        // custom keybinds
        if (c.enabled && mc.screen == null && win != 0) {
            for (Config.BindEntry b : c.binds) {
                if (!b.enabled) continue;
                boolean down = false;
                for (int k : b.keys) {
                    if (k == -1) continue;
                    boolean pressed = k >= 1000
                            ? GLFW.glfwGetMouseButton(win, k - 1000) == GLFW.GLFW_PRESS
                            : GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
                    if (pressed) down = true;
                }
                int id = System.identityHashCode(b);
                boolean was = HELD.getOrDefault(id, false);
                HELD.put(id, down);
                if (down && !was) Actions.run(b.commands);
            }
        }

        // kill detection through the entity we hit last
        if (c.enabled && (c.kill.enabled || c.weaponSounds) && lastTargetId != -1) {
            if (System.currentTimeMillis() - lastHitMs > 6000) {
                lastTargetId = -1;
            } else if (!killFired) {
                Entity e = mc.level.getEntity(lastTargetId);
                if (e instanceof LivingEntity le && le.isDeadOrDying()) {
                    killFired = true;
                    playKill();
                }
            }
        }

        // my death
        boolean dead = mc.player.isDeadOrDying();
        if (dead && !wasDead && c.enabled && c.death.enabled) SoundPlayer.play(c.death);
        wasDead = dead;
    }
}
