package com.n3dl.net;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.n3dl.core.Config;
import com.n3dl.cosmetics.CosmeticsManager;
import com.n3dl.cosmetics.CosmeticsRender;
import com.n3dl.cosmetics.model.Cosmetic;
import com.n3dl.cosmetics.model.Designs;
import com.n3dl.emote.EmoteManager;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;

/**
 * Shares your cosmetics / emote with other 3DL ABO ZAHRA users through a tiny sync server (see /server),
 * and fetches theirs. Works on any Minecraft server because it does not use the game connection.
 */
public final class SyncClient {
    private SyncClient() {
    }

    /** What another player shares. */
    public static final class Remote {
        public boolean enabled = true;
        public Config.CosSlot[] slots = new Config.CosSlot[6];
        public String cape = "";
        public String emote = "";
        public float speed = 1f;
        double elapsed0;
        long recvNs;
    }

    private static final class Wire {
        String name;
        boolean enabled = true;
        Config.CosSlot[] slots;
        String cape = "";
        String emote = "";
        float speed = 1f;
        long emoteAt;
    }

    private static final Gson GSON = new Gson();
    private static final Pattern CAPE_NAME = Pattern.compile("^[0-9a-f]{40}\\.(png|gif|jpg|jpeg|bmp)$");
    private static final Map<UUID, Remote> REMOTES = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> ASKED = new ConcurrentHashMap<>();
    private static final Set<String> DOWNLOADING = ConcurrentHashMap.newKeySet();
    private static final Set<String> UPLOADED = ConcurrentHashMap.newKeySet();
    private static final ExecutorService EX = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "n3dl-sync");
        t.setDaemon(true);
        return t;
    });

    private static volatile String status = "";
    private static volatile boolean ok;
    private static volatile boolean polling, putting;
    private static String lastSent = "";
    private static long lastPutMs, lastPollMs, tickN;
    private static String capeKey = "", capeHash = "";
    private static boolean sentEmpty;

    // ------------------------------------------------------------------ public api

    public static String status() {
        return status;
    }

    public static boolean connected() {
        return ok;
    }

    public static int nearbyCount() {
        int n = 0;
        for (Remote r : REMOTES.values()) if (r.enabled) n++;
        return n;
    }

    public static Remote remote(UUID id) {
        return REMOTES.get(id);
    }

    public static float emoteElapsed(Remote r) {
        return (float) (r.elapsed0 + (System.nanoTime() - r.recvNs) / 1e9);
    }

    /** The player whose model is being drawn at this (interpolated) position, or null. */
    public static AbstractClientPlayer playerAt(double x, double y, double z, float partial) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return null;
        AbstractClientPlayer best = null;
        double bd = 0.04;
        for (AbstractClientPlayer p : mc.level.players()) {
            double px = p.xOld + (p.getX() - p.xOld) * partial;
            double py = p.yOld + (p.getY() - p.yOld) * partial;
            double pz = p.zOld + (p.getZ() - p.zOld) * partial;
            double d = (px - x) * (px - x) + (py - y) * (py - y) + (pz - z) * (pz - z);
            if (d < bd) {
                bd = d;
                best = p;
            }
        }
        return best;
    }

    public static Path capeFile(String name) {
        if (name == null || !CAPE_NAME.matcher(name).matches()) return null;
        Path d = Config.dir().resolve("remote");
        try {
            Files.createDirectories(d);
        } catch (Exception ignored) {
        }
        return d.resolve(name);
    }

    /** Starts downloading a remote cape file (once). */
    public static void requestCape(String name) {
        Path f = capeFile(name);
        String base = base();
        if (f == null || base == null || Files.exists(f) || !DOWNLOADING.add(name)) return;
        EX.execute(() -> {
            try {
                byte[] b = http("GET", base + "/cape/" + name.substring(0, 40), null);
                if (b != null && b.length > 8) Files.write(f, b);
            } catch (Throwable t) {
                // try again later
            } finally {
                DOWNLOADING.remove(name);
            }
        });
    }

    /** Button "test connection". */
    public static void test() {
        String base = base();
        if (base == null) {
            status = "No server address";
            ok = false;
            return;
        }
        status = "...";
        EX.execute(() -> {
            try {
                byte[] b = http("GET", base + "/", null);
                String s = b == null ? "" : new String(b, StandardCharsets.UTF_8);
                ok = s.contains("n3dl");
                status = ok ? "OK" : "Not a 3DL ABO ZAHRA server";
            } catch (Throwable t) {
                ok = false;
                status = "Error: " + t.getClass().getSimpleName();
            }
        });
    }

    // ------------------------------------------------------------------ tick

    public static void tick(Minecraft mc) {
        try {
            tick0(mc);
        } catch (Throwable t) {
            status = "Error: " + t.getClass().getSimpleName();
        }
    }

    private static void tick0(Minecraft mc) {
        Config c = Config.get();
        String base = base();
        if (!c.syncEnabled || base == null || mc.player == null || mc.level == null) return;
        tickN++;
        long now = System.currentTimeMillis();
        UUID me = mc.player.getUUID();

        // ---- send my profile when it changed
        if (tickN % 10 == 0 && !putting && now - lastPutMs > 800) {
            String json = buildProfile(c, mc);
            if (!json.equals(lastSent)) {
                lastSent = json;
                lastPutMs = now;
                putting = true;
                uploadCapeIfNeeded(base);
                EX.execute(() -> {
                    try {
                        http("POST", base + "/put?id=" + me, json.getBytes(StandardCharsets.UTF_8));
                        ok = true;
                        status = "OK";
                    } catch (Throwable t) {
                        ok = false;
                        status = "Error: " + t.getMessage();
                        lastSent = ""; // retry
                    } finally {
                        putting = false;
                    }
                });
            }
        }

        // ---- fetch the others
        if (!polling && now - lastPollMs > 3000) {
            List<UUID> ids = new ArrayList<>();
            for (AbstractClientPlayer p : mc.level.players()) {
                UUID id = p.getUUID();
                if (id.equals(me) || ids.size() >= 30) continue;
                boolean known = REMOTES.containsKey(id);
                Long asked = ASKED.get(id);
                if (known || asked == null || now - asked > 30000) ids.add(id);
            }
            if (!ids.isEmpty()) {
                lastPollMs = now;
                polling = true;
                StringBuilder sb = new StringBuilder();
                for (UUID id : ids) {
                    if (sb.length() > 0) sb.append(',');
                    sb.append(id);
                    ASKED.put(id, now);
                }
                String q = sb.toString();
                EX.execute(() -> {
                    try {
                        byte[] b = http("GET", base + "/get?ids=" + q, null);
                        parse(new String(b, StandardCharsets.UTF_8), ids);
                        ok = true;
                        status = "OK";
                    } catch (Throwable t) {
                        ok = false;
                        status = "Error: " + t.getMessage();
                    } finally {
                        polling = false;
                    }
                });
            }
        }
    }

    private static void parse(String text, List<UUID> asked) {
        JsonObject root = GSON.fromJson(text, JsonObject.class);
        long serverNow = root.get("now").getAsLong();
        JsonObject p = root.getAsJsonObject("p");
        Set<UUID> got = new HashSet<>();
        for (Map.Entry<String, JsonElement> en : p.entrySet()) {
            try {
                UUID id = UUID.fromString(en.getKey().length() == 32
                        ? en.getKey().replaceFirst("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})", "$1-$2-$3-$4-$5") : en.getKey());
                Wire w = GSON.fromJson(en.getValue(), Wire.class);
                Remote r = new Remote();
                r.enabled = w.enabled;
                r.cape = w.cape == null ? "" : w.cape;
                r.emote = w.emote == null ? "" : w.emote;
                r.speed = Math.max(0.2f, Math.min(3f, w.speed));
                r.elapsed0 = r.emote.isEmpty() ? 0 : Math.max(0, (serverNow - w.emoteAt) / 1000.0);
                r.recvNs = System.nanoTime();
                for (int i = 0; i < 6; i++) {
                    Config.CosSlot s = w.slots != null && i < w.slots.length && w.slots[i] != null ? w.slots[i] : new Config.CosSlot();
                    if (s.id == null) s.id = "";
                    s.mode = Math.max(0, Math.min(3, s.mode));
                    s.scale = Math.max(0.3f, Math.min(3f, s.scale));
                    // drop designs this version does not know
                    if (!s.id.isEmpty() && Designs.find(Cosmetic.Slot.values()[i], s.id) == null) s.id = "";
                    r.slots[i] = s;
                }
                REMOTES.put(id, r);
                got.add(id);
                if (!r.cape.isEmpty()) requestCape(r.cape);
            } catch (Throwable ignored) {
            }
        }
        for (UUID id : asked) if (!got.contains(id)) REMOTES.remove(id);
    }

    // ------------------------------------------------------------------ profile

    private static String buildProfile(Config c, Minecraft mc) {
        JsonObject o = new JsonObject();
        boolean share = c.syncShare;
        o.addProperty("name", mc.player.getName().getString());
        o.addProperty("enabled", share && c.cosEnabled);
        List<Config.CosSlot> slots = new ArrayList<>();
        for (Cosmetic.Slot s : Cosmetic.Slot.values()) slots.add(CosmeticsRender.cfgOf(s));
        o.add("slots", GSON.toJsonTree(share ? slots : new ArrayList<>()));
        o.addProperty("cape", share ? capeName(c) : "");
        var em = EmoteManager.current();
        o.addProperty("emote", share && em != null ? em.id() : "");
        o.addProperty("speed", c.emoteSpeed);
        return GSON.toJson(o);
    }

    /** "sha1.ext" of the cape file when it is small enough to share, else "". */
    private static String capeName(Config c) {
        if (c.cape == null || c.cape.isEmpty()) return "";
        try {
            Path f = CosmeticsManager.capesDir().resolve(c.cape).normalize();
            if (!f.startsWith(CosmeticsManager.capesDir().normalize()) || !Files.isRegularFile(f)) return "";
            String key = c.cape + "|" + Files.getLastModifiedTime(f).toMillis();
            if (key.equals(capeKey)) return capeHash;
            capeKey = key;
            capeHash = "";
            if (Files.size(f) > 300 * 1024) return "";
            String n = c.cape.toLowerCase();
            String ext = n.endsWith(".png") ? "png" : n.endsWith(".gif") ? "gif" : n.endsWith(".jpeg") ? "jpeg"
                    : n.endsWith(".jpg") ? "jpg" : n.endsWith(".bmp") ? "bmp" : null;
            if (ext == null) return "";
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest(Files.readAllBytes(f))) sb.append(String.format("%02x", b));
            capeHash = sb + "." + ext;
        } catch (Throwable t) {
            capeHash = "";
        }
        return capeHash;
    }

    private static void uploadCapeIfNeeded(String base) {
        Config c = Config.get();
        String name = c.syncShare ? capeName(c) : "";
        if (name.isEmpty() || !UPLOADED.add(name)) return;
        try {
            Path f = CosmeticsManager.capesDir().resolve(c.cape).normalize();
            byte[] data = Files.readAllBytes(f);
            EX.execute(() -> {
                try {
                    http("POST", base + "/cape?h=" + name.substring(0, 40), data);
                } catch (Throwable t) {
                    UPLOADED.remove(name);
                }
            });
        } catch (Throwable t) {
            UPLOADED.remove(name);
        }
    }

    // ------------------------------------------------------------------ http

    private static String base() {
        String u = Config.get().syncUrl;
        if (u == null) return null;
        u = u.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u.startsWith("http://") || u.startsWith("https://") ? u : null;
    }

    private static byte[] http(String method, String url, byte[] body) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setRequestMethod(method);
        con.setConnectTimeout(6000);
        con.setReadTimeout(8000);
        con.setRequestProperty("User-Agent", "AboMod");
        if (body != null) {
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/octet-stream");
            try (OutputStream os = con.getOutputStream()) {
                os.write(body);
            }
        }
        int code = con.getResponseCode();
        if (code >= 400) throw new IllegalStateException("HTTP " + code);
        try (InputStream in = con.getInputStream()) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
                if (bos.size() > 2_000_000) throw new IllegalStateException("too big");
            }
            return bos.toByteArray();
        } finally {
            con.disconnect();
        }
    }
}
