package com.n3dl.emote;

import static com.n3dl.cosmetics.model.M.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Dance / gesture library. Every emote is a function: given the time in seconds it fills a Pose
 * (rotations in radians for head, body, arms, legs, plus a vertical hip offset in pixels).
 * These are original animations made for 3DL ABO ZAHRA.
 */
public final class Emotes {
    private Emotes() {
    }

    /** Rotations (x, y, z) in radians for each body part. hipY pushes the whole body down (px). */
    public static final class Pose {
        public final float[] head = new float[3], body = new float[3], rArm = new float[3], lArm = new float[3],
                rLeg = new float[3], lLeg = new float[3];
        public float hipY;

        void arms(float x, float y, float z) {
            set(rArm, x, y, z);
            set(lArm, x, -y, -z);
        }

        static void set(float[] a, float x, float y, float z) {
            a[0] = x;
            a[1] = y;
            a[2] = z;
        }

        void clear() {
            for (float[] a : new float[][]{head, body, rArm, lArm, rLeg, lLeg}) a[0] = a[1] = a[2] = 0;
            hipY = 0;
        }
    }

    @FunctionalInterface
    public interface Fn {
        void pose(float t, Pose p);
    }

    /** duration 0 = repeats until you stop it. */
    public record Emote(String id, String en, String ar, float duration, Fn fn) {
    }

    private static final List<Emote> ALL = new ArrayList<>();

    public static List<Emote> all() {
        return Collections.unmodifiableList(ALL);
    }

    public static Emote find(String id) {
        for (Emote e : ALL) if (e.id.equals(id)) return e;
        return null;
    }

    private static void add(String id, String en, String ar, float dur, Fn f) {
        ALL.add(new Emote(id, en, ar, dur, f));
    }

    static {
        add("wave", "Wave", "تلويح", 0, (t, p) -> {
            Pose.set(p.rArm, 0, 0, 2.5f + 0.35f * sin(t * 10));
            p.head[1] = 0.25f;
            p.body[1] = 0.1f;
        });
        add("clap", "Clap", "تصفيق", 0, (t, p) -> {
            float a = 0.15f + 0.75f * abs(sin(t * 7));
            Pose.set(p.rArm, -1.35f, -a, 0);
            Pose.set(p.lArm, -1.35f, a, 0);
            p.hipY = abs(sin(t * 7)) * 0.6f;
        });
        add("dab", "Dab", "داب", 0, (t, p) -> {
            float k = ease(t * 4f);
            Pose.set(p.head, 0.75f * k, 0.5f * k, 0.25f * k);
            Pose.set(p.lArm, -1.45f * k, 1.0f * k, 0);
            Pose.set(p.rArm, -0.1f * k, 0, 2.2f * k);
            p.body[1] = 0.25f * k;
        });
        add("floss", "Floss", "فلوس", 0, (t, p) -> {
            float s = sin(t * 8);
            p.arms(-0.4f - 0.5f * s, 0, 0.2f);
            p.rArm[0] = 0.9f * s;
            p.lArm[0] = 0.9f * s;
            p.rArm[2] = 0.35f;
            p.lArm[2] = 0.35f;
            p.body[2] = 0.25f * s;
            p.rLeg[2] = -0.2f * s;
            p.lLeg[2] = -0.2f * s;
            p.hipY = 1.2f + abs(s) * 0.6f;
            p.rLeg[0] = -0.25f;
            p.lLeg[0] = -0.25f;
        });
        add("disco", "Disco", "ديسكو", 0, (t, p) -> {
            boolean a = ((int) Math.floor(t * 2.2f)) % 2 == 0;
            float[] up = a ? p.rArm : p.lArm, down = a ? p.lArm : p.rArm;
            Pose.set(up, -2.6f, 0, a ? 0.35f : -0.35f);
            Pose.set(down, 0.15f, 0, a ? -0.6f : 0.6f);
            p.body[2] = a ? -0.15f : 0.15f;
            p.hipY = abs(sin(t * 4.4f)) * 1.2f;
            p.head[2] = a ? 0.2f : -0.2f;
        });
        add("robot", "Robot", "روبوت", 0, (t, p) -> {
            float q = (float) Math.floor(t * 4f) * 0.6f;
            float s = ((int) Math.floor(t * 4f)) % 2 == 0 ? 1 : -1;
            Pose.set(p.rArm, -1.57f, 0, 0);
            Pose.set(p.lArm, 0, 0, 0.1f);
            p.rArm[0] = -1.57f + s * 0.5f;
            p.lArm[0] = -0.4f - s * 0.5f;
            p.head[1] = s * 0.6f;
            p.body[1] = s * 0.25f;
            p.rLeg[0] = s * 0.3f;
            p.lLeg[0] = -s * 0.3f;
        });
        add("headbang", "Head bang", "هز الرأس", 0, (t, p) -> {
            float s = sin(t * 10);
            p.head[0] = 0.55f * s + 0.2f;
            p.body[0] = 0.12f * s;
            p.arms(0.3f, 0, 0.25f);
            p.rArm[0] = -1.2f;
            p.lArm[0] = -0.3f;
            p.hipY = abs(s) * 1.3f;
            p.rLeg[0] = -0.2f;
            p.lLeg[0] = -0.2f;
        });
        add("twirl", "Twirl", "دوران", 0, (t, p) -> {
            p.arms(0, 0, 1.45f);
            p.body[1] = t * 9f;
            p.head[1] = -t * 9f * 0.0f;
            p.rLeg[2] = 0.15f;
            p.lLeg[2] = -0.15f;
            p.hipY = abs(sin(t * 4)) * 1.0f;
        });
        add("jumping_jacks", "Jumping jacks", "قفز", 0, (t, p) -> {
            float s = abs(sin(t * 6));
            float open = sin(t * 6) > 0 ? 1 : 0;
            p.arms(0, 0, 0.1f + 2.9f * s);
            p.rLeg[2] = 0.05f + 0.4f * s;
            p.lLeg[2] = -(0.05f + 0.4f * s);
            p.hipY = -0.0f;
        });
        add("breakdance", "Breakdance", "بريك دانس", 0, (t, p) -> {
            p.body[0] = 1.2f;
            p.body[1] = t * 10f;
            p.hipY = 5f;
            p.head[0] = -0.7f;
            p.rArm[0] = -1.0f + sin(t * 10) * 0.8f;
            p.lArm[0] = -1.0f - sin(t * 10) * 0.8f;
            p.rLeg[0] = -1.7f + sin(t * 10) * 0.7f;
            p.lLeg[0] = -1.7f - sin(t * 10) * 0.7f;
            p.rLeg[2] = 0.5f;
            p.lLeg[2] = -0.5f;
        });
        add("zombie", "Zombie", "زومبي", 0, (t, p) -> {
            p.arms(-1.5f, 0, 0.05f);
            p.rArm[0] += sin(t * 3) * 0.12f;
            p.lArm[0] += sin(t * 3 + 1) * 0.12f;
            p.head[0] = 0.35f;
            p.head[2] = sin(t * 1.5f) * 0.25f;
            p.body[0] = 0.15f;
            p.rLeg[0] = sin(t * 3) * 0.4f;
            p.lLeg[0] = -sin(t * 3) * 0.4f;
        });
        add("chicken", "Chicken dance", "رقصة الدجاجة", 0, (t, p) -> {
            float s = sin(t * 12);
            p.rArm[2] = 1.1f + 0.5f * s;
            p.lArm[2] = -(1.1f - 0.5f * s);
            p.rArm[0] = 0.1f;
            p.lArm[0] = 0.1f;
            p.head[0] = 0.3f * abs(s);
            p.hipY = 4f + abs(s) * 0.5f;
            p.rLeg[0] = -1.0f;
            p.lLeg[0] = -1.0f;
            p.body[0] = 0.15f;
        });
        add("salute", "Salute", "تحية", 3f, (t, p) -> {
            float k = ease(t * 5f);
            Pose.set(p.rArm, -2.3f * k, -0.25f * k, 0.55f * k);
            p.head[0] = -0.05f * k;
        });
        add("bow", "Bow", "انحناء", 3f, (t, p) -> {
            float k = sin(clamp(t / 3f, 0, 1) * PI);
            p.body[0] = 1.15f * k;
            p.head[0] = 0.25f * k;
            p.arms(0.2f * k, 0, 0.05f);
        });
        add("cheer", "Cheer", "هتاف", 0, (t, p) -> {
            float s = abs(sin(t * 6));
            p.arms(-3.0f, 0, 0.35f + 0.25f * sin(t * 6));
            p.hipY = 0;
            p.head[0] = -0.3f;
            p.rLeg[0] = -s * 0.4f;
            p.lLeg[0] = -(1 - s) * 0.4f;
        });
        add("sit", "Sit down", "جلوس", 0, (t, p) -> {
            float k = ease(t * 3f);
            p.hipY = 10f * k;
            p.rLeg[0] = -1.57f * k;
            p.lLeg[0] = -1.57f * k;
            p.rLeg[1] = -0.15f * k;
            p.lLeg[1] = 0.15f * k;
            p.arms(-0.7f * k, 0, 0.12f * k);
        });
        add("facepalm", "Facepalm", "ضربة الوجه", 4f, (t, p) -> {
            float k = ease(t * 4f) * (1 - ease((t - 3.4f) * 4f));
            Pose.set(p.rArm, -2.05f * k, -0.35f * k, 0.1f * k);
            p.head[0] = 0.45f * k;
            p.body[0] = 0.1f * k;
        });
        add("shrug", "Shrug", "ما أدري", 3f, (t, p) -> {
            float k = ease(t * 5f) * (1 - ease((t - 2.5f) * 5f));
            p.arms(-0.2f * k, 0, 0.75f * k);
            p.head[2] = 0.2f * k;
            p.hipY = 0;
        });
        add("think", "Thinking", "تفكير", 0, (t, p) -> {
            float k = ease(t * 3f);
            Pose.set(p.rArm, -1.95f * k, -0.55f * k, 0);
            Pose.set(p.lArm, -0.7f * k, 0.5f * k, 0);
            p.head[0] = 0.15f * k;
            p.head[1] = 0.35f * k * sin(t * 0.9f);
            p.head[2] = 0.2f * k;
        });
        add("run", "Run in place", "جري", 0, (t, p) -> {
            float s = sin(t * 14);
            p.rArm[0] = -s * 1.2f;
            p.lArm[0] = s * 1.2f;
            p.rLeg[0] = s * 1.1f;
            p.lLeg[0] = -s * 1.1f;
            p.body[0] = 0.2f;
            p.hipY = abs(s) * 1.4f;
        });
        add("boxing", "Boxing", "ملاكمة", 0, (t, p) -> {
            float s = sin(t * 9);
            Pose.set(p.rArm, -1.45f - 0.2f * s, -0.25f, 0);
            Pose.set(p.lArm, -1.45f + 0.2f * s, 0.25f, 0);
            p.body[1] = -0.35f * s;
            p.head[0] = 0.1f;
            p.hipY = 2f;
            p.rLeg[0] = -0.5f;
            p.lLeg[0] = 0.35f;
            p.rLeg[2] = 0.15f;
            p.lLeg[2] = -0.15f;
        });
        add("karate", "Karate", "كاراتيه", 0, (t, p) -> {
            float c = ((int) Math.floor(t * 1.8f)) % 2 == 0 ? 1 : 0;
            p.hipY = 5f;
            p.rLeg[2] = 0.7f;
            p.lLeg[2] = -0.7f;
            p.rLeg[0] = -0.4f;
            p.lLeg[0] = -0.4f;
            Pose.set(p.rArm, -1.57f, c > 0 ? -0.2f : 0, c > 0 ? 0.1f : 0);
            Pose.set(p.lArm, -1.2f * (1 - c) - 0.3f, 0.5f, 0.2f);
            if (c > 0) Pose.set(p.lArm, -0.4f, 0.2f, -0.2f);
            p.body[1] = c > 0 ? -0.3f : 0.3f;
        });
        add("twist", "The twist", "التويست", 0, (t, p) -> {
            float s = sin(t * 7);
            p.body[1] = 0.55f * s;
            p.rLeg[1] = -0.35f * s;
            p.lLeg[1] = -0.35f * s;
            p.arms(-0.6f, 0, 0.2f);
            p.rArm[0] = -0.6f + 0.5f * s;
            p.lArm[0] = -0.6f - 0.5f * s;
            p.hipY = 3f + abs(s) * 0.8f;
            p.rLeg[0] = -0.35f;
            p.lLeg[0] = -0.35f;
        });
        add("shuffle", "Shuffle", "شفل", 0, (t, p) -> {
            float s = sin(t * 12);
            p.rLeg[2] = 0.35f * s;
            p.lLeg[2] = 0.35f * s;
            p.rLeg[0] = s > 0 ? -0.35f : 0;
            p.lLeg[0] = s > 0 ? 0 : -0.35f;
            Pose.set(p.rArm, -0.9f - s * 0.4f, 0, 0.2f);
            Pose.set(p.lArm, -0.9f + s * 0.4f, 0, -0.2f);
            p.hipY = 1.5f;
            p.body[2] = 0.1f * s;
        });
        add("moonwalk", "Moonwalk", "مشي القمر", 0, (t, p) -> {
            float s = sin(t * 7);
            p.rLeg[0] = 0.5f * s;
            p.lLeg[0] = -0.5f * s;
            p.rLeg[2] = 0.05f;
            p.lLeg[2] = -0.05f;
            p.body[0] = -0.12f;
            p.arms(-0.4f, 0, 0.15f);
            p.rArm[0] = -0.4f + 0.3f * s;
            p.lArm[0] = -0.4f - 0.3f * s;
            p.head[0] = -0.15f;
        });
        add("victory", "Victory", "نصر", 0, (t, p) -> {
            float s = abs(sin(t * 5));
            Pose.set(p.rArm, -2.9f, 0, 0.6f);
            Pose.set(p.lArm, -2.9f, 0, -0.6f);
            p.head[0] = -0.35f;
            p.rLeg[2] = 0.2f;
            p.lLeg[2] = -0.2f;
            p.hipY = 0.5f * s;
        });
        add("laugh", "Laugh", "ضحك", 0, (t, p) -> {
            float s = sin(t * 18);
            p.head[0] = -0.5f + 0.1f * s;
            p.body[0] = -0.12f + 0.06f * s;
            p.arms(-0.75f, 0.3f, 0.15f);
            p.rArm[1] = -0.5f;
            p.lArm[1] = 0.5f;
            p.hipY = abs(s) * 0.8f;
        });
        add("cry", "Cry", "بكاء", 0, (t, p) -> {
            float s = sin(t * 14);
            p.head[0] = 0.5f;
            Pose.set(p.rArm, -2.0f, -0.5f, 0);
            Pose.set(p.lArm, -2.0f, 0.5f, 0);
            p.body[0] = 0.2f + 0.04f * s;
            p.hipY = abs(s) * 0.4f;
        });
        add("point", "Point", "إشارة", 0, (t, p) -> {
            float k = ease(t * 5f);
            Pose.set(p.rArm, -1.57f * k, 0, 0);
            p.head[1] = 0.2f * k * sin(t * 1.4f);
            p.body[1] = -0.15f * k;
        });
        add("heart", "Heart hands", "قلب", 0, (t, p) -> {
            float k = ease(t * 4f);
            float b = 1f + 0.08f * sin(t * 7);
            Pose.set(p.rArm, -2.85f * k, -0.75f * k * b, 0.5f * k);
            Pose.set(p.lArm, -2.85f * k, 0.75f * k * b, -0.5f * k);
            p.head[2] = 0.15f * sin(t * 3);
            p.hipY = abs(sin(t * 3.5f)) * 0.8f;
        });
        add("superhero", "Superhero", "بطل خارق", 0, (t, p) -> {
            float k = ease(t * 4f);
            Pose.set(p.rArm, -3.1f * k, 0, 0.05f);
            Pose.set(p.lArm, -0.3f * k, 0, -0.3f * k);
            p.body[0] = 0.25f * k;
            p.head[0] = -0.2f * k;
            p.rLeg[0] = 0.25f * k;
            p.lLeg[0] = -0.2f * k;
            p.hipY = sin(t * 3) * 0.5f;
        });
        add("salsa", "Salsa", "سالسا", 0, (t, p) -> {
            float s = sin(t * 6);
            p.body[2] = 0.18f * s;
            p.rArm[0] = -1.3f;
            p.lArm[0] = -1.3f;
            p.rArm[2] = 0.5f + 0.4f * s;
            p.lArm[2] = -0.5f + 0.4f * s;
            p.rLeg[0] = s > 0 ? -0.5f : 0;
            p.lLeg[0] = s > 0 ? 0 : -0.5f;
            p.hipY = 1.5f + abs(s);
            p.head[2] = -0.12f * s;
        });
        add("sprinkler", "Sprinkler", "رشاش", 0, (t, p) -> {
            float st = (float) Math.floor(t * 6f);
            float k = (st % 6) / 6f;
            p.head[1] = -0.6f + k * 1.2f;
            Pose.set(p.rArm, -1.57f, -0.2f - k * 0.0f, 0);
            Pose.set(p.lArm, -2.0f, 0.5f, 0.2f);
            p.body[1] = 0.2f - k * 0.2f;
        });
        add("yoga", "Tree pose", "يوغا", 0, (t, p) -> {
            float k = ease(t * 2f);
            p.arms(-3.05f * k, 0, 0.12f * k);
            p.rLeg[0] = 0;
            p.lLeg[0] = -1.1f * k;
            p.lLeg[2] = -0.7f * k;
            p.head[0] = -0.2f * k;
            p.body[2] = sin(t * 1.3f) * 0.03f;
        });
        add("stretch", "Stretch", "تمدد", 0, (t, p) -> {
            float s = sin(t * 1.6f);
            p.arms(-3.1f, 0.0f, 0.15f);
            p.body[2] = 0.35f * s;
            p.head[2] = 0.2f * s;
            p.rLeg[2] = 0.1f;
            p.lLeg[2] = -0.1f;
        });
        add("flex", "Flex", "عضلات", 0, (t, p) -> {
            float s = abs(sin(t * 5));
            Pose.set(p.rArm, -0.2f, 0, 1.65f + 0.15f * s);
            Pose.set(p.lArm, -0.2f, 0, -(1.65f + 0.15f * s));
            p.head[0] = -0.1f;
            p.rLeg[2] = 0.18f;
            p.lLeg[2] = -0.18f;
            p.hipY = s * 0.6f;
        });
        add("macarena", "Hip swing", "هز الوسط", 0, (t, p) -> {
            float s = sin(t * 5);
            int step = ((int) Math.floor(t * 1.25f)) % 4;
            if (step == 0) p.arms(-1.57f, 0, 0.0f);
            else if (step == 1) p.arms(-1.57f, 0.0f, 0.9f);
            else if (step == 2) p.arms(-0.4f, -0.5f, 0.0f);
            else p.arms(-1.2f, 0.3f, 0.5f);
            p.body[2] = 0.15f * s;
            p.hipY = 1f + abs(s) * 0.8f;
            p.rLeg[2] = 0.1f * s;
            p.lLeg[2] = 0.1f * s;
        });
    }
}
