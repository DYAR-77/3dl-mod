package com.n3dl.emote;

import com.n3dl.core.Config;
import java.util.List;
import java.util.Map;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import org.lwjgl.glfw.GLFW;

/** Plays emotes on the local player and applies the pose to the player model. */
public final class EmoteManager {
    private EmoteManager() {
    }

    private static Emotes.Emote current;
    private static long startNs;
    private static CameraType savedCamera;
    private static boolean cameraChanged;
    private static final Emotes.Pose POSE = new Emotes.Pose();
    private static final java.util.Map<String, Boolean> HELD = new java.util.HashMap<>();

    public static Emotes.Emote current() {
        return current;
    }

    public static boolean playing() {
        return current != null;
    }

    public static void play(String id) {
        Emotes.Emote e = Emotes.find(id);
        if (e == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        current = e;
        startNs = System.nanoTime();
        Config c = Config.get();
        if (c.emoteThirdPerson && !cameraChanged) {
            savedCamera = mc.options.getCameraType();
            if (savedCamera.isFirstPerson()) {
                mc.options.setCameraType(CameraType.THIRD_PERSON_FRONT);
                cameraChanged = true;
            }
        }
    }

    public static void toggle(String id) {
        if (current != null && current.id().equals(id)) stop();
        else play(id);
    }

    public static void random() {
        List<Emotes.Emote> all = Emotes.all();
        play(all.get((int) (Math.random() * all.size())).id());
    }

    public static void stop() {
        current = null;
        Minecraft mc = Minecraft.getInstance();
        if (cameraChanged && savedCamera != null) mc.options.setCameraType(savedCamera);
        cameraChanged = false;
    }

    /** Called every client tick: stop conditions and per-emote key binds. */
    public static void tick(Minecraft mc) {
        Config c = Config.get();
        if (mc.player == null) {
            current = null;
            cameraChanged = false;
            return;
        }
        if (current != null) {
            float t = (System.nanoTime() - startNs) / 1e9f;
            if (current.duration() > 0 && t * Math.max(0.2f, c.emoteSpeed) > current.duration()) stop();
            else if (c.emoteStopOnMove && mc.screen == null) {
                var o = mc.options;
                if (o.keyUp.isDown() || o.keyDown.isDown() || o.keyLeft.isDown() || o.keyRight.isDown()
                        || o.keyJump.isDown() || o.keyShift.isDown() || mc.player.isSwimming()
                        || mc.player.getDeltaMovement().horizontalDistanceSqr() > 0.01) {
                    stop();
                }
            }
        }
        long win = GLFW.glfwGetCurrentContext();
        if (!c.enabled || mc.screen != null || win == 0 || c.emoteKeys == null) return;
        for (Map.Entry<String, Integer> en : c.emoteKeys.entrySet()) {
            int k = en.getValue() == null ? -1 : en.getValue();
            if (k <= 0) continue;
            boolean down = k >= 1000 ? GLFW.glfwGetMouseButton(win, k - 1000) == GLFW.GLFW_PRESS
                    : GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
            boolean was = HELD.getOrDefault(en.getKey(), false);
            HELD.put(en.getKey(), down);
            if (down && !was) toggle(en.getKey());
        }
    }

    /** Called from the player model mixin after vanilla animation. x/y/z = the entity being animated. */
    public static void apply(HumanoidModel<?> m, double x, double y, double z) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        float partial = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        var pl = com.n3dl.net.SyncClient.playerAt(x, y, z, partial);
        if (pl == null) return;
        Emotes.Emote e;
        float t;
        if (pl == mc.player) {
            if (current == null) return;
            e = current;
            t = (System.nanoTime() - startNs) / 1e9f * Math.max(0.2f, Config.get().emoteSpeed);
        } else {
            var r = com.n3dl.net.SyncClient.remote(pl.getUUID());
            if (r == null || !r.enabled || r.emote.isEmpty()) return;
            e = Emotes.find(r.emote);
            if (e == null) return;
            t = com.n3dl.net.SyncClient.emoteElapsed(r) * r.speed;
            if (e.duration() > 0 && t > e.duration()) return;
        }
        POSE.clear();
        try {
            e.fn().pose(t, POSE);
        } catch (Throwable ex) {
            return;
        }
        set(m.head, POSE.head, POSE.hipY);
        set(m.body, POSE.body, POSE.hipY);
        set(m.rightArm, POSE.rArm, POSE.hipY);
        set(m.leftArm, POSE.lArm, POSE.hipY);
        set(m.rightLeg, POSE.rLeg, POSE.hipY);
        set(m.leftLeg, POSE.lLeg, POSE.hipY);
    }

    private static void set(ModelPart p, float[] r, float hipY) {
        p.resetPose();
        p.xRot = r[0];
        p.yRot = r[1];
        p.zRot = r[2];
        p.y += hipY;
    }
}
