package com.n3dl.mixin;

import com.mojang.blaze3d.opengl.GlDevice;
import com.n3dl.core.Config;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Fake graphics card strings for the F3 screen (optional). */
@Mixin(GlDevice.class)
public abstract class GlDeviceMixin {
    @Inject(method = "getRenderer", at = @At("RETURN"), cancellable = true)
    private void n3dl$renderer(CallbackInfoReturnable<String> cir) {
        if (Config.get().enabled && Config.get().fakeGpu) cir.setReturnValue("NVIDIA GeForce RTX 5090/PCIe/SSE2");
    }

    @Inject(method = "getVendor", at = @At("RETURN"), cancellable = true)
    private void n3dl$vendor(CallbackInfoReturnable<String> cir) {
        if (Config.get().enabled && Config.get().fakeGpu) cir.setReturnValue("NVIDIA Corporation");
    }

    @Inject(method = "getVersion", at = @At("RETURN"), cancellable = true)
    private void n3dl$version(CallbackInfoReturnable<String> cir) {
        if (Config.get().enabled && Config.get().fakeGpu) cir.setReturnValue("4.6.0 NVIDIA 580.97");
    }
}
