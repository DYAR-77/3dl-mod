package com.n3dl.mixin;

import com.n3dl.cosmetics.CosmeticsManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Replaces the local player's cape / elytra / skin with the ones chosen in 3DL ABO ZAHRA. */
@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void n3dl$applyCosmetics(CallbackInfoReturnable<PlayerSkin> cir) {
        AbstractClientPlayer self = (AbstractClientPlayer) (Object) this;
        PlayerSkin replaced;
        if (self == Minecraft.getInstance().player) {
            replaced = CosmeticsManager.apply(cir.getReturnValue());
        } else {
            var r = com.n3dl.net.SyncClient.remote(self.getUUID());
            if (r == null || !r.enabled || r.cape.isEmpty()) return;
            replaced = CosmeticsManager.applyRemote(cir.getReturnValue(), r.cape);
        }
        if (replaced != null) cir.setReturnValue(replaced);
    }
}
