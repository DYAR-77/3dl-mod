package com.n3dl.mixin;

import com.n3dl.core.Hide;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Removes name tags (all, or only for chosen players). */
@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin<T extends Entity, S extends EntityRenderState> {
    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void n3dl$hideNameTag(T entity, S state, float partialTick, CallbackInfo ci) {
        if (state.nameTag == null) return;
        if (Hide.nametags() || Hide.playerNametagHidden(entity.getName().getString())) {
            state.nameTag = null;
        }
    }
}
