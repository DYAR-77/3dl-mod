package com.n3dl.mixin;

import com.n3dl.core.Config;
import net.minecraft.client.gui.components.debug.DebugEntrySystemSpecs;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Makes the memory lines of F3 look like a big PC: 16 GB heap, with a believable amount allocated.
 * Used memory stays the real value, so the numbers move naturally.
 */
@Mixin(DebugEntrySystemSpecs.class)
public abstract class SpecsMixin {
    private static final long MAX = 16384L * 1024 * 1024;
    private static final long TOTAL = 8192L * 1024 * 1024;

    private static boolean on() {
        return Config.get().enabled && Config.get().fakeGpu;
    }

    @Redirect(method = "display", at = @At(value = "INVOKE", target = "Ljava/lang/Runtime;maxMemory()J"), require = 0)
    private long n3dl$max(Runtime rt) {
        return on() ? MAX : rt.maxMemory();
    }

    @Redirect(method = "display", at = @At(value = "INVOKE", target = "Ljava/lang/Runtime;totalMemory()J"), require = 0)
    private long n3dl$total(Runtime rt) {
        return on() ? Math.max(TOTAL, rt.totalMemory()) : rt.totalMemory();
    }

    @Redirect(method = "display", at = @At(value = "INVOKE", target = "Ljava/lang/Runtime;freeMemory()J"), require = 0)
    private long n3dl$free(Runtime rt) {
        if (!on()) return rt.freeMemory();
        long used = rt.totalMemory() - rt.freeMemory();
        return Math.max(TOTAL, rt.totalMemory()) - used;
    }
}
