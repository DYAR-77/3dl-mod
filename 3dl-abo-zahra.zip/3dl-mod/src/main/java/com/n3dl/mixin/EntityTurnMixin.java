package com.n3dl.mixin;

import com.n3dl.combat.Combat;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Freezes the camera (mouse and touch look) while the wind combo is running. */
@Mixin(Entity.class)
public abstract class EntityTurnMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true)
    private void n3dl$lockView(double yRot, double xRot, CallbackInfo ci) {
        if (Combat.viewLocked() && (Object) this instanceof LocalPlayer) ci.cancel();
    }
}
