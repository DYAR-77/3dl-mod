package com.n3dl.mixin;

import com.mojang.blaze3d.platform.GLX;
import com.n3dl.core.Config;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Fake CPU name for the F3 screen (optional). */
@Mixin(GLX.class)
public abstract class CpuInfoMixin {
    @Inject(method = "_getCpuInfo", at = @At("RETURN"), cancellable = true)
    private static void n3dl$cpu(CallbackInfoReturnable<String> cir) {
        if (Config.get().enabled && Config.get().fakeGpu) cir.setReturnValue("32x AMD Ryzen 9 9950X3D 16-Core Processor ");
    }
}
