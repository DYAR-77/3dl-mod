package com.n3dl.mixin;

import com.n3dl.combat.Combat;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lets the mace swap choose the mace right before an attack starts. */
@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @Inject(method = "startAttack", at = @At("HEAD"))
    private void n3dl$beforeAttack(CallbackInfoReturnable<Boolean> cir) {
        Combat.beforeAttack((Minecraft) (Object) this);
    }

    @Inject(method = "startAttack", at = @At("RETURN"))
    private void n3dl$afterAttack(CallbackInfoReturnable<Boolean> cir) {
        Combat.afterAttack((Minecraft) (Object) this);
    }
}
