package com.n3dl.mixin;

import com.n3dl.emote.EmoteManager;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Lets the emote system override the player's limb rotations after vanilla animation. */
@Mixin(PlayerModel.class)
public abstract class PlayerModelMixin {
    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)V", at = @At("TAIL"))
    private void n3dl$emote(AvatarRenderState state, CallbackInfo ci) {
        EmoteManager.apply((HumanoidModel<?>) (Object) this, state.x, state.y, state.z);
    }
}
