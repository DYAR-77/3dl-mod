package com.n3dl.mixin;

import com.n3dl.core.Config;
import com.n3dl.gui.ShardBg;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Replaces the main menu panorama with the animated shard background. */
@Mixin(Screen.class)
public abstract class ScreenBgMixin {
    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void n3dl$shards(GuiGraphics g, int mouseX, int mouseY, float partial, CallbackInfo ci) {
        if (!((Object) this instanceof TitleScreen)) return;
        Config c = Config.get();
        if (!c.enabled || !c.shardBg) return;
        Screen s = (Screen) (Object) this;
        ShardBg.render(g, s.width, s.height, false);
        ci.cancel();
    }
}
