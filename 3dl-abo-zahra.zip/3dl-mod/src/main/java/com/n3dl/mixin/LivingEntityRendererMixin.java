package com.n3dl.mixin;

import com.n3dl.cosmetics.CosmeticLayer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds the 3DL ABO ZAHRA cosmetics layer to every player renderer (it only draws for the local player). */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin<S extends LivingEntityRenderState, M extends EntityModel<? super S>> {
    @Shadow
    protected abstract boolean addLayer(RenderLayer<S, M> layer);

    @Shadow
    public abstract M getModel();

    @Inject(method = "<init>", at = @At("TAIL"))
    private void n3dl$addLayer(CallbackInfo ci) {
        if (getModel() instanceof PlayerModel) {
            addLayer(new CosmeticLayer<S, M>((LivingEntityRenderer<?, S, M>) (Object) this));
        }
    }
}
