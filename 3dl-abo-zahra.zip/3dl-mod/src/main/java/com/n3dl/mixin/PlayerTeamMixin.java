package com.n3dl.mixin;

import com.n3dl.core.Hide;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Team;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Hides rank look: team prefix / suffix / colour on names (tab list, name tags, chat). */
@Mixin(PlayerTeam.class)
public abstract class PlayerTeamMixin {
    @Inject(method = "formatNameForTeam", at = @At("HEAD"), cancellable = true)
    private static void n3dl$noRank(Team team, Component name, CallbackInfoReturnable<MutableComponent> cir) {
        if (Hide.ranks()) {
            cir.setReturnValue(name.copy());
        }
    }
}
