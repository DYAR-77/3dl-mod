package com.n3dl.core;

/** Tiny bilingual helper: Tr.t("English", "العربية"). */
public final class Tr {
    private Tr() {
    }

    public static String t(String en, String ar) {
        return Config.get().ar() ? ar : en;
    }
}
