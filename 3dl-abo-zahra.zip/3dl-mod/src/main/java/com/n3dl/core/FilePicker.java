package com.n3dl.core;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;

/**
 * Native "choose a file" dialog. Tries LWJGL tinyfd (reflection, so a missing class is not fatal),
 * then Swing. On phones (Pojav/Zalith) no dialog exists: the callback gets null and the screen
 * tells the user to drag a file in or copy it into the folder.
 */
public final class FilePicker {
    private FilePicker() {
    }

    private static volatile boolean busy;

    public static boolean busy() {
        return busy;
    }

    /** patterns like "*.png". Result is delivered on the main thread; null = cancelled/unavailable. */
    public static void pick(String title, String desc, String[] patterns, Consumer<Path> done) {
        if (busy) return;
        busy = true;
        Thread t = new Thread(() -> {
            Path result = null;
            try {
                result = viaTinyFd(title, desc, patterns);
                if (result == null && !tinyWorked) result = viaSwing(desc, patterns);
            } catch (Throwable ignored) {
            }
            Path r = result;
            busy = false;
            Minecraft.getInstance().execute(() -> done.accept(r));
        }, "n3dl-file-picker");
        t.setDaemon(true);
        t.start();
    }

    private static boolean tinyWorked;

    private static Path viaTinyFd(String title, String desc, String[] patterns) {
        try (MemoryStack st = MemoryStack.stackPush()) {
            Class<?> c = Class.forName("org.lwjgl.util.tinyfd.TinyFileDialogs");
            PointerBuffer pb = st.mallocPointer(patterns.length);
            for (String p : patterns) pb.put(st.UTF8(p));
            pb.flip();
            var m = c.getMethod("tinyfd_openFileDialog", CharSequence.class, CharSequence.class, PointerBuffer.class,
                    CharSequence.class, boolean.class);
            Object r = m.invoke(null, title, "", pb, desc, false);
            tinyWorked = true;
            if (r == null) return null;
            Path p = Path.of(r.toString().split("\\|")[0]);
            return Files.isRegularFile(p) ? p : null;
        } catch (Throwable t) {
            return null;
        }
    }

    private static Path viaSwing(String desc, String[] patterns) {
        try {
            if (java.awt.GraphicsEnvironment.isHeadless()) return null;
            String os = System.getProperty("os.name", "").toLowerCase();
            if (os.contains("mac")) return null;
            javax.swing.JFileChooser fc = new javax.swing.JFileChooser();
            java.util.List<String> ext = new java.util.ArrayList<>();
            for (String p : patterns) ext.add(p.replace("*.", "").toLowerCase());
            fc.setFileFilter(new javax.swing.filechooser.FileFilter() {
                public boolean accept(java.io.File f) {
                    if (f.isDirectory()) return true;
                    String n = f.getName().toLowerCase();
                    for (String e : ext) if (n.endsWith("." + e)) return true;
                    return false;
                }

                public String getDescription() {
                    return desc;
                }
            });
            if (fc.showOpenDialog(null) == javax.swing.JFileChooser.APPROVE_OPTION) return fc.getSelectedFile().toPath();
        } catch (Throwable ignored) {
        }
        return null;
    }
}
