package com.n3dl.core;

/** Colour presets. Order: bg, panel, header, button, accent, text (RGB). */
public final class Theme {
    private Theme() {
    }

    public static final String[] NAMES = {"Midnight", "Emerald", "Royal", "Sunset", "Ice", "Rose", "Gold", "Mono"};
    public static final String[] NAMES_AR = {"منتصف الليل", "زمردي", "ملكي", "غروب", "جليدي", "وردي", "ذهبي", "أحادي"};

    private static final int[][] COLORS = {
            {0x0B0F1A, 0x141B2D, 0x1B2540, 0x25304F, 0x4F8CFF, 0xE8EEFF},
            {0x07140F, 0x0E2219, 0x143226, 0x1D4434, 0x2ECC71, 0xE6FFF1},
            {0x120A1F, 0x1D1233, 0x2A1B4A, 0x3A2766, 0xA66BFF, 0xF1E8FF},
            {0x1A0B0B, 0x2A1414, 0x3D1D1B, 0x55291F, 0xFF7A3D, 0xFFEFE6},
            {0x0A1418, 0x102228, 0x17343D, 0x214A56, 0x4FE3FF, 0xE6FBFF},
            {0x1A0A12, 0x2A1220, 0x3C1A2E, 0x55263F, 0xFF5FA2, 0xFFE8F2},
            {0x15110A, 0x241C0E, 0x362A14, 0x4B3A1B, 0xFFC247, 0xFFF4DA},
            {0x101010, 0x1A1A1A, 0x262626, 0x363636, 0xDDDDDD, 0xFFFFFF}
    };

    /** End colours for gradients. Order: panel, header, button, accent. */
    private static final int[][] END = {
            {0x1A1F45, 0x2B2F6B, 0x34407A, 0x8E6BFF},
            {0x0E2A2A, 0x14403F, 0x1D5654, 0x2EC9D8},
            {0x2A1433, 0x472260, 0x5A2E80, 0xFF6BD0},
            {0x33121F, 0x55202F, 0x6E2C3C, 0xFFC23D},
            {0x14203A, 0x1E3560, 0x294A80, 0x6B8CFF},
            {0x2A1233, 0x42205A, 0x5A2E7A, 0xFF8A5F},
            {0x2A1A0E, 0x45280F, 0x5E3A14, 0xFF7A3D},
            {0x262626, 0x363636, 0x484848, 0x8899AA}
    };

    public static int index(String name) {
        for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equals(name)) return i;
        return 0;
    }

    public static void apply(Config c, int i) {
        i = Math.floorMod(i, NAMES.length);
        int[] k = COLORS[i];
        c.theme = NAMES[i];
        c.cBg = k[0];
        c.cPanel = k[1];
        c.cHeader = k[2];
        c.cButton = k[3];
        c.cAccent = k[4];
        c.cText = k[5];
        int[] e = END[i];
        c.cPanel2 = e[0];
        c.cHeader2 = e[1];
        c.cButton2 = e[2];
        c.cAccent2 = e[3];
    }

    public static String display(int i) {
        return Config.get().ar() ? NAMES_AR[i] : NAMES[i];
    }

    public static int argb(int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255f)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    public static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }
}
