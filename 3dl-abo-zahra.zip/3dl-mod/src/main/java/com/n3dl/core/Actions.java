package com.n3dl.core;

import com.mojang.blaze3d.platform.InputConstants;
import com.n3dl.audio.SoundPlayer;
import com.n3dl.gui.AboScreen;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Things a keybind can do. A command is either:
 *   /something      -> runs a command            (sent as if typed in chat)
 *   plain text      -> sends a chat message
 *   @action[:arg]   -> a 3DL ABO ZAHRA action (see QUICK)
 * Several commands in one bind run in order; "@wait:500" pauses the rest by 500 ms.
 */
public final class Actions {
    private Actions() {
    }

    public static final List<String> QUICK = List.of(
            "@hide_chat", "@hide_tab", "@hide_score", "@hide_ranks", "@hide_nametags", "@streamer",
            "@menu", "@toggle_mod", "@voice_mute", "@voice_disable", "@voice_hide",
            "@test_kill", "@emote_stop", "@emote_random", "@wait:500");

    public static String label(String a) {
        return switch (a) {
            case "@hide_chat" -> Tr.t("Toggle chat", "إخفاء/إظهار الشات");
            case "@hide_tab" -> Tr.t("Toggle tab list", "إخفاء/إظهار التاب");
            case "@hide_score" -> Tr.t("Toggle scoreboard", "إخفاء/إظهار السكور بورد");
            case "@hide_ranks" -> Tr.t("Toggle rank look", "إخفاء/إظهار شكل الرتبة");
            case "@hide_nametags" -> Tr.t("Toggle name tags", "إخفاء/إظهار النيم تاج");
            case "@streamer" -> Tr.t("Streamer mode", "وضع البث");
            case "@menu" -> Tr.t("Open 3DL ABO ZAHRA menu", "فتح قائمة 3DL ABO ZAHRA");
            case "@toggle_mod" -> Tr.t("3DL ABO ZAHRA on/off", "تشغيل/إيقاف 3DL ABO ZAHRA");
            case "@voice_mute" -> Tr.t("Voice chat: mute mic", "الفويس شات: كتم المايك");
            case "@voice_disable" -> Tr.t("Voice chat: disable", "الفويس شات: تعطيل");
            case "@voice_hide" -> Tr.t("Voice chat: hide icons", "الفويس شات: إخفاء الأيقونات");
            case "@test_kill" -> Tr.t("Play kill sound", "تشغيل صوت القتل");
            case "@emote_stop" -> Tr.t("Stop emote", "إيقاف الرقصة");
            case "@emote_random" -> Tr.t("Random emote", "رقصة عشوائية");
            case "@wait:500" -> Tr.t("Wait 0.5 second", "انتظار نصف ثانية");
            default -> a;
        };
    }

    private record Pending(long due, String cmd) {
    }

    private static final List<Pending> QUEUE = new ArrayList<>();

    public static void run(List<String> commands) {
        long t = System.currentTimeMillis();
        for (String raw : commands) {
            String s = raw == null ? "" : raw.trim();
            if (s.isEmpty()) continue;
            if (s.startsWith("@wait:")) {
                try {
                    t += Long.parseLong(s.substring(6).trim());
                } catch (NumberFormatException ignored) {
                }
                continue;
            }
            if (t <= System.currentTimeMillis()) exec(s);
            else QUEUE.add(new Pending(t, s));
        }
    }

    public static void tick() {
        if (QUEUE.isEmpty()) return;
        long now = System.currentTimeMillis();
        for (Iterator<Pending> it = QUEUE.iterator(); it.hasNext(); ) {
            Pending p = it.next();
            if (p.due() <= now) {
                it.remove();
                exec(p.cmd());
            }
        }
    }

    public static void exec(String s) {
        Minecraft mc = Minecraft.getInstance();
        Config c = Config.get();
        try {
            if (s.startsWith("/")) {
                if (mc.player != null) mc.player.connection.sendCommand(s.substring(1));
                return;
            }
            if (!s.startsWith("@")) {
                if (mc.player != null) mc.player.connection.sendChat(s);
                return;
            }
            if (s.startsWith("@emote:")) {
                com.n3dl.emote.EmoteManager.toggle(s.substring(7));
                return;
            }
            switch (s) {
                case "@hide_chat" -> flip(Tr.t("Chat hidden", "الشات مخفي"), Tr.t("Chat shown", "الشات ظاهر"), c.hideChat = !c.hideChat, true);
                case "@hide_tab" -> flip(Tr.t("Tab hidden", "التاب مخفي"), Tr.t("Tab shown", "التاب ظاهر"), c.hideTab = !c.hideTab, true);
                case "@hide_score" -> flip(Tr.t("Scoreboard hidden", "السكور بورد مخفي"), Tr.t("Scoreboard shown", "السكور بورد ظاهر"), c.hideScoreboard = !c.hideScoreboard, true);
                case "@hide_ranks" -> flip(Tr.t("Ranks hidden", "الرتب مخفية"), Tr.t("Ranks shown", "الرتب ظاهرة"), c.hideRanks = !c.hideRanks, true);
                case "@hide_nametags" -> flip(Tr.t("Name tags hidden", "النيم تاج مخفي"), Tr.t("Name tags shown", "النيم تاج ظاهر"), c.hideNametags = !c.hideNametags, true);
                case "@streamer" -> flip(Tr.t("Streamer mode ON", "وضع البث مفعّل"), Tr.t("Streamer mode OFF", "وضع البث متوقف"), c.streamer = !c.streamer, true);
                case "@toggle_mod" -> flip(Tr.t("3DL ABO ZAHRA ON", "3DL ABO ZAHRA يعمل"), Tr.t("3DL ABO ZAHRA OFF", "3DL ABO ZAHRA متوقف"), c.enabled = !c.enabled, true);
                        case "@menu" -> mc.setScreen(new AboScreen());
                case "@test_kill" -> SoundPlayer.play(c.kill);
                case "@emote_stop" -> com.n3dl.emote.EmoteManager.stop();
                case "@emote_random" -> com.n3dl.emote.EmoteManager.random();
                case "@voice_mute" -> voice("mute_microphone");
                case "@voice_disable" -> voice("disable_voice_chat");
                case "@voice_hide" -> voice("hide_icons");
                default -> {
                }
            }
        } catch (Throwable t) {
            System.err.println("[3DL ABO ZAHRA] Action failed (" + s + "): " + t);
        }
    }

    private static void flip(String on, String off, boolean state, boolean save) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("[3DL ABO ZAHRA] " + (state ? on : off)), true);
        if (save) Config.save();
    }

    /** Presses a key of the Simple Voice Chat mod (if it is installed and the key is bound). */
    private static void voice(String suffix) {
        Minecraft mc = Minecraft.getInstance();
        for (KeyMapping km : mc.options.keyMappings) {
            String n = km.getName();
            if (n.endsWith(suffix) && !n.startsWith("key.n3dl")) {
                InputConstants.Key k = InputConstants.getKey(km.saveString());
                if (k != InputConstants.UNKNOWN) {
                    KeyMapping.click(k);
                    return;
                }
                if (mc.player != null) {
                    mc.player.displayClientMessage(Component.literal("[3DL ABO ZAHRA] " + Tr.t(
                            "Bind that key in Voice Chat settings first", "اربط هذا الزر في إعدادات الفويس شات أولاً")), true);
                }
                return;
            }
        }
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.literal("[3DL ABO ZAHRA] " + Tr.t(
                    "Simple Voice Chat not found", "مود Simple Voice Chat غير موجود")), true);
        }
    }

    public static boolean voiceInstalled() {
        return net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("voicechat");
    }
}
