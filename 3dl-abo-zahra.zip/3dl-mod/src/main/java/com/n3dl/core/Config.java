package com.n3dl.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** All user settings. Saved as JSON in .minecraft/config/n3dl/config.json */
public class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config INSTANCE = new Config();

    public static class BindEntry {
        public String name = "Bind";
        public boolean enabled = true;
        /** GLFW key codes; mouse buttons are stored as 1000 + button. */
        public List<Integer> keys = new ArrayList<>();
        public List<String> commands = new ArrayList<>();
    }

    public static class SoundCfg {
        public boolean enabled;
        public String source;
        public float volume = 1f;
        public float pitch = 1f;
        /** Extra sounds. When there is more than one sound (this list + source) one is picked at random. */
        public List<String> more = new ArrayList<>();

        public SoundCfg(boolean enabled, String source) {
            this.enabled = enabled;
            this.source = source;
        }
    }

    /** Sounds for one weapon (item id like minecraft:mace, or "hand"). */
    public static class WeaponSound {
        public String item = "minecraft:mace";
        public SoundCfg kill = new SoundCfg(true, "builtin:boom");
        public SoundCfg hit = new SoundCfg(false, "builtin:tick");
    }

    /** One 3D cosmetic slot: which design, how it is coloured, how big. mode: 0 default, 1 solid, 2 gradient, 3 rainbow. */
    public static class CosSlot {
        public String id = "";
        public int mode = 0;
        public int c1 = 0xFFFFFF, c2 = 0x7A5CFF;
        public float scale = 1f;
    }

    // ---- weapon sounds ----
    public boolean weaponSounds = true;
    public List<WeaponSound> weaponList = new ArrayList<>();

    // ---- combat helpers ----
    public boolean maceSwap = false, maceSwapPlayersOnly = true, maceSwapReturn = false;
    public int spearKey = -1, spearReturnTicks = 5;
    /** Mace swap: ticks to wait after the hit before going back (0 = instantly inside the hit). */
    public int maceReturnTicks = 0;
    /** Jump together with the spear swap (goes further). */
    public boolean spearJump = false;
    // ---- trigger bot
    public boolean tbOn = false;
    public int tbKey = -1;
    public boolean tbPlayers = true, tbMobs = true, tbAnimals = true, tbCrystal = true, tbVillagers = false, tbStands = false, tbOthers = false;
    /** 0 always, 1 only crits, 2 crit when falling else normal. */
    public int tbHitMode = 1;
    /** Max distance (0 = the game default). */
    public float tbReach = 0f, tbMiss = 0f;
    public boolean tbPauseUse = false, tbSimulate = false, tbOnlyWeapon = false, tbAntiBot = false, tbSkipBlocking = false, tbFocus = false, tbInGui = false;
    /** 0 = wait for the weapon cooldown, 1 = clicks per second. */
    public int tbMode = 0;
    public float tbCps = 12f, tbDouble = 0f;
    /** Wind + ender pearl combo: key, ticks between steps, wind charge cooldown to wait, direction of the last charge (0 down, 1 up, 2 as I look). */
    public int windKey = -1, windFinalDir = 0;
    /** Milliseconds: jump after the first charge, pearl after the first charge, last charge after the pearl. */
    public int windJumpMs = 50, windPearlMs = 100, windFinalMs = 400;
    public boolean windRestoreView = true, windReturn = true;

    // ---- music player ----
    public float musicVolume = 0.7f;

    // ---- general ----
    public boolean enabled = true;
    public String lang = "ar";

    // ---- hiding ----
    public boolean streamer = false;
    public boolean hideChat, hideTab, hideScoreboard, hideRanks, hideNametags, hideBossBar, hideTitle;
    public List<String> hiddenPlayers = new ArrayList<>();
    /** When the tab list is hidden, still show a plain list of player names (like a server without a tab plugin). */
    public boolean tabNamesOnly = true;
    /** Animated purple shard background for the menu and the main menu. */
    public boolean shardBg = true;
    /** Show a fake RTX 5090 + strong PC specs on the F3 screen. */
    public boolean fakeGpu = false;

    // ---- keybinds ----
    public List<BindEntry> binds = new ArrayList<>();

    // ---- sounds ----
    public float soundMaster = 1f;
    public String killChatPattern = "by {me}";
    public SoundCfg kill = new SoundCfg(true, "builtin:hitmarker");
    public SoundCfg hit = new SoundCfg(false, "builtin:tick");
    public SoundCfg death = new SoundCfg(false, "builtin:descend");
    public SoundCfg mention = new SoundCfg(true, "builtin:ding");

    // ---- cosmetics ----
    public String cape = "";
    public String outfit = "";
    /** Main menu skin panel: on/off, side (0 left, 1 right), skin file in the outfits folder (empty = use the outfit). */
    public boolean menuSkinOn = true;
    public int menuSide = 0;
    public String menuSkin = "";
    public int capeFrameMs = 100;
    public boolean capeElytra = true;
    /** How a normal picture is placed on the cape: STRETCH, COVER (crop) or CONTAIN (letterbox). */
    public String capeFit = "COVER";

    // ---- 3D cosmetics ----
    public boolean cosEnabled = true;
    /** Cosmetics react to motion (sway, flapping) and auras/pets show in first person. */
    public boolean cosPhysics = true, cosFirstPerson = true;
    // online sync with other 3DL ABO ZAHRA users
    public boolean syncEnabled = true, syncShare = true;
    public String syncUrl = "";
    public CosSlot cosWings = new CosSlot(), cosHead = new CosSlot(), cosBody = new CosSlot(),
            cosPet = new CosSlot(), cosComp = new CosSlot(), cosAura = new CosSlot();

    // ---- emotes ----
    public Map<String, Integer> emoteKeys = new HashMap<>();
    public boolean emoteStopOnMove = true;
    public boolean emoteThirdPerson = true;
    public float emoteSpeed = 1f;

    // ---- recorder ----
    public int recFps = 20;          // 10 or 20
    public int recStep = 2;          // 1 = full, 2 = half, 3 = third, 4 = quarter resolution
    public float recQuality = 0.8f;
    public boolean recSwapRB = false;
    public boolean recIndicator = true;
    public boolean recMp4 = false;
    public boolean replayEnabled = false;
    public int replaySeconds = 30;

    // ---- extras ----
    public boolean infoHud = false;
    public boolean infoFps = true, infoXyz = true, infoFacing = true, infoPing = true, infoCps = true, infoTime = false;
    public int infoCorner = 0; // 0 TL, 1 TR, 2 BL, 3 BR
    public boolean zoomEnabled = true;
    public int zoomFov = 30;

    // ---- look & layout ----
    public String layout = "WINDOW"; // WINDOW, FULLSCREEN, SIDEBAR, COMPACT
    public float panelScale = 1f;
    public float textScale = 1f;
    public float opacity = 0.94f;
    public boolean round = true;
    public int panelX = -1, panelY = -1, panelW = 440, panelH = 300;
    public String theme = "Midnight";
    public int cBg = 0x0B0F1A, cPanel = 0x141B2D, cHeader = 0x1B2540, cButton = 0x25304F, cAccent = 0x4F8CFF, cText = 0xE8EEFF;
    // gradients: when on, each surface blends from its colour to its "end" colour
    public boolean gradient = false;
    public int gradDir = 0;          // 0 = top to bottom, 1 = left to right
    public boolean gradAnim = false; // slowly drifting accent
    public int cPanel2 = 0x24193F, cHeader2 = 0x3A2160, cButton2 = 0x3A2A66, cAccent2 = 0xB06BFF;

    public static Config get() {
        return INSTANCE;
    }

    public static Path dir() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("n3dl");
        try {
            Files.createDirectories(p);
        } catch (Exception ignored) {
        }
        return p;
    }

    public static void load() {
        Path f = dir().resolve("config.json");
        if (Files.exists(f)) {
            try (Reader r = Files.newBufferedReader(f)) {
                Config c = GSON.fromJson(r, Config.class);
                if (c != null) INSTANCE = c;
            } catch (Exception e) {
                System.err.println("[3DL ABO ZAHRA] Could not read config, using defaults: " + e);
            }
        }
        INSTANCE.fix();
        if (INSTANCE.binds.isEmpty()) INSTANCE.addExampleBind();
        save();
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(dir().resolve("config.json"))) {
            GSON.toJson(INSTANCE, w);
        } catch (Exception e) {
            System.err.println("[3DL ABO ZAHRA] Could not save config: " + e);
        }
    }

    private void fix() {
        if (hiddenPlayers == null) hiddenPlayers = new ArrayList<>();
        if (binds == null) binds = new ArrayList<>();
        for (BindEntry b : binds) {
            if (b.keys == null) b.keys = new ArrayList<>();
            if (b.commands == null) b.commands = new ArrayList<>();
        }
        if (kill == null) kill = new SoundCfg(true, "builtin:hitmarker");
        if (hit == null) hit = new SoundCfg(false, "builtin:tick");
        if (death == null) death = new SoundCfg(false, "builtin:descend");
        if (mention == null) mention = new SoundCfg(true, "builtin:ding");
        if (weaponList == null) weaponList = new ArrayList<>();
        for (SoundCfg sc : new SoundCfg[]{kill, hit, death, mention}) fixSound(sc);
        for (WeaponSound w : weaponList) {
            if (w.item == null || w.item.isEmpty()) w.item = "hand";
            if (w.kill == null) w.kill = new SoundCfg(true, "builtin:boom");
            if (w.hit == null) w.hit = new SoundCfg(false, "builtin:tick");
            fixSound(w.kill);
            fixSound(w.hit);
        }
        spearReturnTicks = Math.max(2, Math.min(30, spearReturnTicks));
        maceReturnTicks = Math.max(0, Math.min(20, maceReturnTicks));
        tbHitMode = Math.max(0, Math.min(2, tbHitMode));
        tbMode = Math.max(0, Math.min(1, tbMode));
        tbCps = Math.max(1f, Math.min(20f, tbCps));
        tbMiss = Math.max(0f, Math.min(100f, tbMiss));
        tbDouble = Math.max(0f, Math.min(100f, tbDouble));
        tbReach = Math.max(0f, Math.min(6f, tbReach));
        windJumpMs = Math.max(0, Math.min(1500, windJumpMs));
        windPearlMs = Math.max(0, Math.min(1500, windPearlMs));
        windFinalMs = Math.max(0, Math.min(2000, windFinalMs));
        windFinalDir = Math.max(0, Math.min(2, windFinalDir));
        musicVolume = Math.max(0f, Math.min(2f, musicVolume));
        if (lang == null || !(lang.equals("ar") || lang.equals("en"))) lang = "ar";
        if (layout == null) layout = "WINDOW";
        if (cape == null) cape = "";
        if (capeFit == null || !(capeFit.equals("STRETCH") || capeFit.equals("COVER") || capeFit.equals("CONTAIN"))) capeFit = "COVER";
        if (syncUrl == null) syncUrl = "";
        if (cosWings == null) cosWings = new CosSlot();
        if (cosHead == null) cosHead = new CosSlot();
        if (cosBody == null) cosBody = new CosSlot();
        if (cosPet == null) cosPet = new CosSlot();
        if (cosComp == null) cosComp = new CosSlot();
        if (cosAura == null) cosAura = new CosSlot();
        for (CosSlot cs : new CosSlot[]{cosWings, cosHead, cosBody, cosPet, cosComp, cosAura}) {
            if (cs.id == null) cs.id = "";
            cs.mode = Math.max(0, Math.min(3, cs.mode));
            cs.scale = Math.max(0.4f, Math.min(2.5f, cs.scale));
        }
        if (emoteKeys == null) emoteKeys = new HashMap<>();
        emoteSpeed = Math.max(0.4f, Math.min(2.5f, emoteSpeed));
        gradDir = gradDir == 1 ? 1 : 0;
        if (outfit == null) outfit = "";
        if (menuSkin == null) menuSkin = "";
        menuSide = Math.max(0, Math.min(1, menuSide));
        panelScale = Math.max(0.6f, Math.min(2.0f, panelScale));
        textScale = Math.max(0.7f, Math.min(2.0f, textScale));
    }

    private static void fixSound(SoundCfg s) {
        if (s.more == null) s.more = new ArrayList<>();
        if (s.source == null) s.source = "builtin:ding";
        s.more.removeIf(x -> x == null || x.isEmpty());
    }

    private void addExampleBind() {
        BindEntry b = new BindEntry();
        b.name = "Example / مثال";
        b.keys.add(-1);
        b.commands.add("@streamer");
        binds.add(b);
    }

    public boolean ar() {
        return "ar".equals(lang);
    }
}
