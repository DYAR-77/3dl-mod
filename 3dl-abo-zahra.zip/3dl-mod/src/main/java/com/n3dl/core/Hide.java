package com.n3dl.core;

/** Central answers to "should X be hidden right now?". Streamer mode hides everything. */
public final class Hide {
    private Hide() {
    }

    private static boolean on() {
        return Config.get().enabled;
    }

    public static boolean chat() {
        Config c = Config.get();
        return on() && (c.hideChat || c.streamer);
    }

    public static boolean tab() {
        Config c = Config.get();
        return on() && (c.hideTab || c.streamer);
    }

    public static boolean scoreboard() {
        Config c = Config.get();
        return on() && (c.hideScoreboard || c.streamer);
    }

    public static boolean ranks() {
        Config c = Config.get();
        return on() && (c.hideRanks || c.streamer);
    }

    public static boolean nametags() {
        Config c = Config.get();
        return on() && (c.hideNametags || c.streamer);
    }

    public static boolean bossBar() {
        Config c = Config.get();
        return on() && c.hideBossBar;
    }

    public static boolean title() {
        Config c = Config.get();
        return on() && c.hideTitle;
    }

    public static boolean playerNametagHidden(String name) {
        if (!on() || name == null) return false;
        for (String p : Config.get().hiddenPlayers) {
            if (p.equalsIgnoreCase(name)) return true;
        }
        return false;
    }
}
