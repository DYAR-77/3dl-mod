// 3DL ABO ZAHRA sync server - Cloudflare Worker (free plan).
// Needs ONE KV namespace bound to this Worker with the variable name:  SYNC
// Stores each player's cosmetics choice + current emote, and (small) cape pictures.

const HEX_ID = /^[0-9a-f-]{32,36}$/;
const CAPE_NAME = /^[0-9a-f]{40}\.(png|gif|jpg|jpeg|bmp)$/;
const DAY = 86400;

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json", "access-control-allow-origin": "*" },
  });
}

function cleanSlot(s) {
  s = s && typeof s === "object" ? s : {};
  const num = (v, d, lo, hi) => (typeof v === "number" && isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d);
  return {
    id: typeof s.id === "string" ? s.id.slice(0, 40) : "",
    mode: Math.round(num(s.mode, 0, 0, 3)),
    c1: Math.round(num(s.c1, 0xffffff, 0, 0xffffff)),
    c2: Math.round(num(s.c2, 0x7a5cff, 0, 0xffffff)),
    scale: num(s.scale, 1, 0.3, 3),
  };
}

function cleanProfile(p) {
  const slots = Array.isArray(p.slots) ? p.slots.slice(0, 6).map(cleanSlot) : [];
  while (slots.length < 6) slots.push(cleanSlot(null));
  return {
    name: typeof p.name === "string" ? p.name.slice(0, 32) : "",
    enabled: p.enabled !== false,
    slots,
    cape: typeof p.cape === "string" && CAPE_NAME.test(p.cape) ? p.cape : "",
    emote: typeof p.emote === "string" ? p.emote.replace(/[^a-z_]/g, "").slice(0, 30) : "",
    speed: typeof p.speed === "number" && isFinite(p.speed) ? Math.min(3, Math.max(0.2, p.speed)) : 1,
  };
}

function sniff(b) {
  const u = new Uint8Array(b);
  if (u[0] === 0x89 && u[1] === 0x50 && u[2] === 0x4e && u[3] === 0x47) return true; // png
  if (u[0] === 0x47 && u[1] === 0x49 && u[2] === 0x46) return true; // gif
  if (u[0] === 0xff && u[1] === 0xd8) return true; // jpeg
  if (u[0] === 0x42 && u[1] === 0x4d) return true; // bmp
  return false;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (req.method === "OPTIONS") {
      return new Response(null, { headers: { "access-control-allow-origin": "*", "access-control-allow-headers": "*" } });
    }
    if (!env.SYNC) return json({ error: "KV binding SYNC is missing" }, 500);

    // POST /put?id=<uuid>   body: profile json
    if (url.pathname === "/put" && req.method === "POST") {
      const id = (url.searchParams.get("id") || "").toLowerCase();
      if (!HEX_ID.test(id)) return json({ error: "bad id" }, 400);
      const text = await req.text();
      if (text.length > 4000) return json({ error: "too big" }, 413);
      let body;
      try { body = JSON.parse(text); } catch { return json({ error: "bad json" }, 400); }
      const prof = cleanProfile(body);
      const key = "p:" + id;
      const old = await env.SYNC.get(key, "json");
      const now = Date.now();
      if (old) {
        const same = JSON.stringify({ ...old.profile }) === JSON.stringify(prof);
        if (same) return json({ ok: true, unchanged: true, now });
      }
      const emoteAt = old && old.profile.emote === prof.emote ? old.emoteAt : now;
      await env.SYNC.put(key, JSON.stringify({ profile: prof, emoteAt }), { expirationTtl: 7 * DAY });
      return json({ ok: true, now });
    }

    // GET /get?ids=a,b,c
    if (url.pathname === "/get" && req.method === "GET") {
      const ids = (url.searchParams.get("ids") || "").toLowerCase().split(",").filter((x) => HEX_ID.test(x)).slice(0, 30);
      const out = {};
      await Promise.all(ids.map(async (id) => {
        const v = await env.SYNC.get("p:" + id, "json");
        if (v) out[id] = { ...v.profile, emoteAt: v.emoteAt };
      }));
      return json({ now: Date.now(), p: out });
    }

    // POST /cape?h=<sha1 of the file>   body: the picture (max 300 KB)
    if (url.pathname === "/cape" && req.method === "POST") {
      const h = (url.searchParams.get("h") || "").toLowerCase();
      if (!/^[0-9a-f]{40}$/.test(h)) return json({ error: "bad hash" }, 400);
      const buf = await req.arrayBuffer();
      if (buf.byteLength > 300 * 1024 || buf.byteLength < 16) return json({ error: "size" }, 413);
      if (!sniff(buf)) return json({ error: "not a picture" }, 400);
      const dig = await crypto.subtle.digest("SHA-1", buf);
      const hex = [...new Uint8Array(dig)].map((b) => b.toString(16).padStart(2, "0")).join("");
      if (hex !== h) return json({ error: "hash mismatch" }, 400);
      const key = "c:" + h;
      if (!(await env.SYNC.get(key, "arrayBuffer"))) await env.SYNC.put(key, buf, { expirationTtl: 30 * DAY });
      return json({ ok: true });
    }

    // GET /cape/<sha1>
    if (url.pathname.startsWith("/cape/") && req.method === "GET") {
      const h = url.pathname.slice(6).toLowerCase();
      if (!/^[0-9a-f]{40}$/.test(h)) return json({ error: "bad hash" }, 400);
      const buf = await env.SYNC.get("c:" + h, "arrayBuffer");
      if (!buf) return json({ error: "not found" }, 404);
      return new Response(buf, { headers: { "content-type": "application/octet-stream", "cache-control": "public, max-age=86400", "access-control-allow-origin": "*" } });
    }

    if (url.pathname === "/" ) return json({ n3dl: "sync server", ok: true });
    return json({ error: "not found" }, 404);
  },
};
