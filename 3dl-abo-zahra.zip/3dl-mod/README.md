# 3DL ABO ZAHRA — Fabric mod for Minecraft 1.21.11

![banner](docs/banner.png)

Client-side assistant mod. Press **Right Shift** to open the menu (changeable). Arabic (فصحى) and English.

## Build the jar with GitHub (no setup on your PC)

1. Create a new GitHub repository and upload **everything in this folder** (keep the `.github` folder).
2. Open the **Actions** tab → the `build` workflow runs by itself (or press *Run workflow*).
3. When it turns green, open the run → **Artifacts → 3DL ABO ZAHRA-mod** → download → inside is `n3dl-1.0.0.jar`.
4. Put the jar in `.minecraft/mods` with **Fabric Loader 0.18.x** and **Fabric API for 1.21.11**.

If the build fails, copy the red error text and send it to Claude.

Local build (optional): Java 21 + Gradle 9.2 → `gradle build` → `build/libs/n3dl-1.0.0.jar`.

## Features

| Page | What you get |
|---|---|
| General | On/off, Arabic/English, rebind all 3DL ABO ZAHRA keys |
| Hide | chat, tab, scoreboard, rank look, all name tags, one player's name tag, boss bars, titles, **Streamer mode** |
| Keybinds | Unlimited binds. Each bind: many keys (keyboard or mouse buttons) + many commands. `/cmd`, chat text, `@actions`, `@wait:500` |
| Sounds | Kill / hit / death / chat-mention sounds. 10 built-in, **any mp3 / ogg / wav you choose from your files** (button or drag & drop), or vanilla sounds. Volume up to 300%, pitch |
| Cape & Looks | **Any picture or GIF becomes a cape** (choose a file; fit modes Fill / Fit / Stretch), 17 ready capes, elytra, 13 outfit skins, neon tools pack |
| Cosmetics | 3D wings, headwear, bodywear, pets, companions and auras (about 70 designs), 9 bundles, solid / gradient / rainbow colours, size |
| General > Online sync | See other 3DL ABO ZAHRA users' cosmetics, capes and dances on **any server** through a free sync server (`server/worker.js`, steps in `server/SETUP_AR.md`) |
| Combat | Mace swap (hit with the mace automatically), spear quick-swap key, wind charge + ender pearl combo. Per-weapon kill/hit sounds are in the Sounds page |
| Emotes | 35 original dances and gestures, a key per emote, stop-on-move, auto third-person, speed |
| Recorder | In-game recording to `.avi`, instant replay (save last seconds), optional MP4 via ffmpeg |
| Menu style | Window / full screen / side panel / compact; menu size, text size, opacity, rounded corners, 8 colour presets, full RGB + hue strip + swatches, **gradient colours** (direction, animated, second colours); drag to move, drag corner to resize, scroll bar |
| Extras | FPS / XYZ / direction / ping / CPS / clock panel, hold-to-zoom, Simple Voice Chat key control |

Folders: `.minecraft/config/n3dl/` (`capes`, `outfits`, `sounds`, `config.json`) and `.minecraft/n3dl/recordings`.

## Notes

* Capes, outfits, 3D cosmetics and emotes are client-side: only you see them.
* Emotes are original animations (Essential's own assets are not copied).
* Menu keys: wheel changes sliders/lists, arrows / PgUp / PgDn / Home / End scroll, Tab switches page.
* On phones (Pojav/Zalith) the file window may not open: copy the file into the sounds / capes folder instead.
* Voice chat link: 3DL ABO ZAHRA presses Simple Voice Chat's own keys (mute mic, disable, hide icons) from your binds. Bind those keys inside Voice Chat settings first.
* Recording has no sound (video only).
